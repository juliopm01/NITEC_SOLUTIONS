# Sistema Multi-Agente NITEC - Clasificación, Normativa BOJA y Empaquetado Urbanístico

Bienvenido al repositorio central del **Sistema Multi-Agente NITEC**. Este sistema automatiza la lectura, extracción de metadatos, verificación de normativa urbanística autonómica (BOJA) y municipal, compresión inteligente de planos y empaquetado estructurado de expedientes técnicos de arquitectura e ingeniería.

El proyecto está organizado en **2 versiones independientes** y una carpeta de **estudios comparativos**, manteniendo el código y la documentación claramente separados.

---

## 📁 Estructura del Repositorio

```text
sistema_nitec_ocr_v1/
│
├── README.md                                          # Guía general de uso y mapa del proyecto
├── lanzador.py                                        # Menú interactivo central para ejecutar V1 o V2
│
├── estudios_comparativos/                             # Estudios analíticos y modelos de costes energéticos
│   ├── consumo_computacional_modelos_hardware.xlsx    # Comparativa de rendimiento entre arquitecturas
│   └── consumo_energetico_costes_electricos.xlsx      # Costes eléctricos anuales según tarifa
│
├── version_1_ocr/                                     # VERSIÓN 1: OCR Clásico (ONNX) + LLM Texto
│   ├── codigo/                                        # Scripts Python y dependencias
│   │   ├── main.py                                    # Orquestador interactivo de la V1
│   │   ├── agente_1_extractor.py                      # Extractor de metadatos y clasificador
│   │   ├── agente_2_normativo_local.py                # Gestor de base normativa BOJA y límites municipales
│   │   ├── agente_3_procesador.py                     # Compresor sin pérdida, divisor y empaquetador
│   │   ├── creador_base_datos.py                      # Inicializador de base de datos JSON
│   │   ├── creador_base_vectores.py                   # Indexador vectorial con embeddings locales
│   │   ├── geo_localizador.py                         # Detección de INE y municipio con caché local
│   │   ├── lector_ocr_pdf.py                          # Motor de extracción de texto y OCR de imágenes
│   │   └── requirements.txt                           # Dependencias de Python para la V1
│   │
│   └── documentacion/                                 # Documentación técnica y memorias de la V1
│       ├── GUIA_INSTALACION_Y_REQUISITOS.md           # Guía paso a paso de instalación y Ollama
│       ├── INFORME_TECNICO_SISTEMA.md                 # Documento técnico detallado de cada módulo
│       ├── Informe Técnico - Sistema Multi-Agente.pdf # Memoria formal del sistema en PDF
│       ├── REQUISITOS_HARDWARE.md                     # Requisitos mínimos y recomendados de hardware
│       ├── Requisitos de Hardware - V1 Local.pdf      # Ficha técnica de hardware en PDF
│       ├── REQUISITOS_COMPUTACIONALES_Y_CONSUMO.md    # Estudio de tiempos, potencia y consumo
│       └── REQUISITOS_COMPUTACIONALES_Y_CONSUMO.xlsx  # Hoja de cálculo con fórmulas dinámicas
│
├── material_comercial/                                # MATERIAL COMERCIAL, WEB Y ACTIVOS DE MARCA
│   ├── presentacion_comercial_nitec.html              # Pitch comercial interactivo + Simulador total BOJA
│   ├── web_alternativa_nitecsolutions.html            # Web corporativa alternativa (orientada a ingeniería)
│   ├── mockup_sistema_nitec.html                      # Panel de control de escritorio simulado
│   ├── mockup_preview.html                            # Vista previa compacta del mockup
│   ├── infografias/                                   # Infografías del pipeline multi-agente
│   │   ├── nitec_workflow_spanish_vibrant.jpg         # Diagrama visual de flujo en español
│   │   └── nitec_agentes_workflow_find_flow_transit.jpg # Tríada de agentes: FIND, FLOW y TRANSIT
│   └── logos/                                         # Identidad visual oficial
│       ├── logo_nitec_one.png                         # Logotipo oficial del producto Nitec ONE
│       ├── logo_nitec_solutions.png                   # Logotipo oficial completo de NITEC Solutions
│       └── logo_nitec_solutions_sphere.png            # Icono oficial de la esfera de red
│
└── version_2_vlm/                                     # VERSIÓN 2: Visión Multimodal VLM Local + OCR
    ├── codigo/                                        # Scripts Python, configuración y dependencias
    │   ├── main.py                                    # Orquestador interactivo de la V2
    │   ├── motor_vision_local.py                      # Interfaz con modelos VLM (Qwen2-VL / Llama-3.2-Vision)
    │   ├── agente_1_extractor.py                      # Extractor multimodal asistido por VLM
    │   ├── agente_2_normativo_local.py                # Gestor normativo BOJA
    │   ├── agente_3_procesador.py                     # Compresor y empaquetador según BOJA
    │   ├── creador_base_datos.py                      # Inicializador de base de datos JSON
    │   ├── creador_base_vectores.py                   # Indexador vectorial
    │   ├── geo_localizador.py                         # Localizador de municipios e INE
    │   ├── lector_ocr_pdf.py                          # Motor híbrido OCR + extracción de capas gráficas
    │   ├── config_vlm.json                            # Parámetros del modelo VLM (timeout, fallback, prompt)
    │   └── requirements.txt                           # Dependencias de Python para la V2
    │
    └── documentacion/                                 # Documentación técnica y memorias de la V2
        ├── GUIA_VLM_LOCAL.md                          # Manual de configuración del motor de visión
        ├── Guía de Uso y Configuración VLM Local.pdf  # Manual de usuario en PDF
        ├── REQUISITOS_HARDWARE.md                     # Requisitos de GPU/VRAM para modelos de visión
        ├── Requisitos de Hardware - VLM Local.pdf     # Ficha de hardware en PDF
        ├── REQUISITOS_COMPUTACIONALES_Y_CONSUMO.md    # Análisis energético e inferencia visual
        └── REQUISITOS_COMPUTACIONALES_Y_CONSUMO.xlsx  # Hoja de cálculo con fórmulas dinámicas
```

---

## 🚀 Cómo Ejecutar el Sistema

### Opción 1: Mediante el Lanzador Central (Recomendado)
Desde la raíz del proyecto, ejecute:

```powershell
python lanzador.py
```

El lanzador mostrará un menú interactivo en terminal para elegir entre la **Versión 1** o la **Versión 2**, garantizando que el entorno de trabajo, codificación UTF-8 y rutas relativas se configuren de forma automática.

También puede ejecutar directamente sin pasar por el menú:
```powershell
python lanzador.py 1       # Ejecuta la Versión 1 (OCR Clásico)
python lanzador.py 2       # Ejecuta la Versión 2 (VLM Multimodal)
python lanzador.py docs    # Muestra el catálogo de documentación disponible
python lanzador.py demo    # Abre la Presentación Comercial Interactiva en el navegador
```

---

### Opción 2: Ejecución Directa por Versión

#### Para ejecutar la Versión 1 (OCR Clásico):
```powershell
cd version_1_ocr/codigo
python main.py
```

#### Para ejecutar la Versión 2 (VLM Multimodal):
```powershell
cd version_2_vlm/codigo
python main.py
```

---

## ⚡ Comparativa Rápida entre Versiones

| Característica | Versión 1 (OCR Clásico) | Versión 2 (VLM Multimodal) |
| :--- | :--- | :--- |
| **Tecnología visual** | RapidOCR (ONNX) + PyMuPDF | VLM Local (`qwen2-vl` / `llama3.2-vision`) + Fallback OCR |
| **Comprensión de planos** | Lectura de texto en cajetines y sellos | Comprensión espacial de alzados, secciones y leyendas |
| **Hardware mínimo** | CPU 4 núcleos + 8 GB RAM (No requiere GPU) | GPU con 8 GB VRAM o CPU potente con 16 GB RAM |
| **Hardware recomendado** | NVIDIA RTX 3050 (4-6 GB VRAM) + 16 GB RAM | NVIDIA RTX 3060 / 4060 Ti (12-16 GB VRAM) + 32 GB RAM |
| **Tiempo por expediente** | ~1 - 2 minutos | ~3 - 5 minutos |
| **Consumo energético medio**| ~85 W (GPU ligera) / ~50 W (CPU) | ~180 W (GPU activa) |
| **Privacidad** | 100% Local (Sin dependencias externas) | 100% Local (Sin dependencias externas) |

---

## 📚 Documentación Técnica Detallada

Cada carpeta `documentacion/` contiene manuales completos en formatos Markdown (.md), PDF y hojas de cálculo Excel (.xlsx):
1. **Guías de Instalación y Requisitos**: Pasos detallados para configurar Python, librerías y Ollama.
2. **Informes Técnicos de Arquitectura**: Desglose funcional paso a paso de los Agentes 1, 2 y 3.
3. **Fichas de Requisitos Hardware**: Tablas de compatibilidad para entornos de oficina, estaciones de trabajo y servidores.
4. **Estudios de Consumo Energético**: Fórmulas y costes en kWh y euros anuales según perfiles de uso.
