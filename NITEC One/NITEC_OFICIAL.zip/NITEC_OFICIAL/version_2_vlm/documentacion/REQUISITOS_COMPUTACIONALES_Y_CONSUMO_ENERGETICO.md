# ⚡👁️ Requisitos Computacionales y Consumo Energético — Sistema NITEC Versión VLM Local (`version_vlm_local`)

Este documento define la carga computacional exacta (TFLOPs de visión y texto, codificación de tokens visuales `Multi-Crop`, ancho de banda de VRAM y transferencia PCIe) y el **consumo energético real (`W`, `Wh`, `kWh`, coste en `€` y huella de $\text{CO}_2$)** de la versión **`version_vlm_local`** (que incorpora un **LLM Multimodal adicional de Visión en Ollama** junto a `RapidOCR`, `llama3.1` y `nomic-embed-text`) **según dónde se ejecute el sistema**.

---

## 1. Perfil Computacional del Pipeline Multimodal (`version_vlm_local`)

A diferencia de la versión basada únicamente en librería OCR (`v1`), `version_vlm_local` introduce un **codificador visual (*Vision Transformer - ViT*) + decodificador multimodal** que analiza 2 imágenes por cada lámina gráfica (`Vista Global 100 DPI` + `Recorte de Cartela 300 DPI`).

Para el mismo **expediente urbanístico/arquitectónico tipo** (1 Memoria digital de 50 págs., 1 Normativa de 25 págs., 6 Planos `A1`/`A0` y 2 Anexos; ~120 MB), la carga computacional se reparte así:

| Fase del Pipeline | Motor / Modelo Activo | Tipo de Cómputo Dominante | Carga Matemática Estimada (Expediente de 6 Planos) | Cuello de Botella Principal |
| :--- | :--- | :--- | :--- | :--- |
| **1. Páginas Digitales (Memoria/Normas)** | Enrutador Híbrido (`PyMuPDF`) | Monohilo CPU | < 0,05 GFLOPs *(salta OCR y salta VLM)* | Lectura SSD (`< 0,2 s`) |
| **2. Recorte `Multi-Crop` + Anclaje OCR** | `PyMuPDF` (`100`/`300 DPI`) + `Pillow` + `RapidOCR` | **CPU Multihilo + RAM** | **~30 GFLOPs** *(rasterizado doble + ONNX en 6 planos)* | Frecuencia CPU y memoria RAM |
| **3. Comprensión Visual de Planos y Cartelas** | **VLM en Ollama (`qwen2.5vl:3b` / `7b` / `32b`)** | **GPU Tensor/FP16 (`ViT` + Atención Cruzada)** | **~75 TFLOPs (`3B`) / ~180 TFLOPs (`7B`) / ~720 TFLOPs (`32B`)** *(~2.200 tokens visuales $\times$ 6 planos)* | **Cómputo matricial FP16/INT4 en GPU y VRAM** |
| **4. Conmutación Limpia de VRAM** | `liberar_modelo_vlm_en_ollama` (`keep_alive=0`) | Bus PCIe / Memoria Unificada | Descarga VLM y carga `llama3.1` (~4,7 GB por PCIe) | Velocidad SSD NVMe / caché RAM del SO (`~1,5 – 3 s`) |
| **5. Indexación + Agentes 1 y 2 (Texto)** | `nomic-embed-text` + `llama3.1:8b` (`num_ctx=16000`) | **GPU Inferencia LLM** | **~10 – 15 TFLOPs** | Ancho de banda de VRAM (`GB/s`) |
| **6. Agente 3 (Compresión y Empaquetado BOJA)** | `PyMuPDF` (`deflate`/`garbage=4`) + `pypdf` | **CPU + SSD NVMe** | Compresión sin pérdida `LZ77` + bisección binaria | CPU monohilo + escritura NVMe |

> **Impacto computacional clave del VLM adicional**: Mientras que `RapidOCR` (`v1`) requiere apenas **~0,025 TFLOPs** para leer 6 planos en CPU, analizar visualmente esos mismos 6 planos con `qwen2.5vl:7b` (`Multi-Crop`) exige **~180 TFLOPs** de cálculo matricial pesado. Por eso el enrutador híbrido de `lector_ocr_pdf.py` (que evita llamar al VLM en páginas de texto digital y limita `max_paginas_vlm_por_pdf = 4`) ahorra entre un **60 % y un 85 % de cómputo y energía** en cada proyecto.

---

## 2. Rendimiento y Consumo Energético Según Dónde se Corra el Sistema

Aplicando $E\,(\text{Wh}) = \frac{P_{\text{media}}\,(\text{W}) \times t\,(\text{s})}{3600}$ sobre el expediente tipo con **6 láminas de planos analizadas visualmente (`Multi-Crop`)**, este es el comportamiento real en cada plataforma:

### Tabla Comparativa por Entorno de Ejecución (Por 1 Expediente Completo con 6 Planos)

| Entorno donde se ejecuta el sistema | Perfil VLM (`config_vlm.json`) | Tiempo por Plano / Tiempo Total ($t$) | Potencia Media en Pared ($P$) | Energía por Expediente ($\text{Wh}$) | Coste Eléctrico / 100 Expedientes* |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **A. Portátil / PC en Solo CPU (Sin GPU dedicada)**<br>*(Core i7 / Ryzen 7, 24–32 GB RAM)* | `"ligero"`<br>(`qwen2.5vl:3b`) | `~28 s/plano`<br>**Total: ~380 s** *(6,3 min)* | **~85 W** | **8,97 Wh** *(0,0090 kWh)* | **0,161 €** *(~144 $\text{gCO}_2$)* |
| **B. Portátil Técnico / PC Básico (GPU 6–8 GB VRAM)**<br>*(Core i7 + **RTX 3050 / RTX 4060 Laptop 8 GB**)* | `"ligero"`<br>(`qwen2.5vl:3b`) | `~3,8 s/plano`<br>**Total: ~58 s** | **~145 W** | **2,34 Wh** *(0,0023 kWh)* | **0,042 €** *(~37 $\text{gCO}_2$)* |
| **C. Sobremesa Estudio Estándar (GPU 12–16 GB VRAM)**<br>*(Core i7 / Ryzen 7 + **RTX 3060 12 GB / 4060 Ti 16 GB / 4070**)* | `"estandar"`<br>(`qwen2.5vl:7b`) | `~3,2 s/plano`<br>**Total: ~55 s** | **~245 W** | **3,74 Wh** *(0,0037 kWh)* | **0,067 €** *(~60 $\text{gCO}_2$)* |
| **D. Workstation Gama Alta (GPU 24 GB+ VRAM)**<br>*(Core i9 / Ryzen 9 + **RTX 4090 24 GB**)* | `"estandar"` (`7b`)<br>o `"potente"` (`32b`) | `~1,3 s/plano` (`7b`) / `~4,5 s` (`32b`)<br>**Total: ~28 s (`7b`) / ~52 s (`32b`)** | **~410 W** (`7b`)<br>**~460 W** (`32b`) | **3,19 Wh** (`7b`)<br>**6,64 Wh** (`32b`) | **0,057 €** (`7b`)<br>**0,120 €** (`32b`) |
| **E. Apple Silicon (Mac Mini / MacBook Pro Metal)**<br>*(**M2/M3/M4 Pro 24–32 GB** o **Max 36–64 GB**)* | `"estandar"`<br>(`qwen2.5vl:7b`) | `~4,5 s/plano`<br>**Total: ~68 s** | **~58 W** | **1,10 Wh** *(0,0011 kWh)* | **0,020 €** *(~18 $\text{gCO}_2$)* |

*\*Cálculo basado en tarifa media en España de `0,18 €/kWh` e intensidad de carbono de `160 gCO2eq/kWh`.*

---

## 3. Análisis Detallado por Entorno de Ejecución

### ⚠️ Entorno A: Ejecución en Solo CPU (Sin tarjeta gráfica dedicada)
* **Coste computacional**: El codificador visual (*Vision Transformer*) debe multiplicar matrices densas para ~2.200 parches de imagen por plano sobre los núcleos de la CPU. Incluso usando el modelo pequeño (`qwen2.5vl:3b`), el *prefill* visual tarda `~20 – 30 segundos` por plano.
* **Impacto energético**: Es el escenario **menos eficiente** (`~8,97 Wh` por expediente, más de 6 minutos de CPU al 100 %). En equipos sin GPU dedicada ni Apple Silicon, suele ser preferible usar la `v1` (`RapidOCR` puro) o dejar `version_vlm_local` en su modo de respaldo automático sin VLM (`4,06 Wh`).

### 💻 Entorno B: Portátil Técnico o PC Compacto con GPU de 6–8 GB VRAM (Perfil `"ligero"`)
* **Coste computacional**: Con `qwen2.5vl:3b` (~4,8 GB en VRAM con las dos vistas `Multi-Crop`) y la descarga automática `keep_alive=0` antes de abrir `llama3.1`, los Tensor Cores de la GPU resuelven el análisis visual de cada plano en menos de `4 segundos`.
* **Impacto energético**: Excelente equilibrio para movilidad o despachos con portátiles gaming/workstation (`~145 W` medios durante menos de un minuto = **`2,34 Wh` por expediente**, consumiendo apenas un ~4 % de batería por proyecto).

### 🏢 Entorno C: PC de Estudio con GPU NVIDIA de 12–16 GB VRAM (Perfil `"estandar"` — Recomendado)
* **Coste computacional**: Permite ejecutar `qwen2.5vl:7b` a máxima precisión sobre las cartelas a `300 DPI`. Durante los ~20 segundos que dura la lectura visual de los 6 planos, la GPU trabaja al 90–100 % de sus Tensor Cores; a continuación ejecuta `keep_alive=0`, carga `llama3.1` desde la caché RAM del sistema operativo en `~1,5 s` y clasifica el expediente completo.
* **Impacto energético**: Demanda `~230 – 260 W` durante unos 55 segundos (**`3,74 Wh` por expediente**). Procesar **1.000 proyectos urbanísticos completos** supone apenas **`3,74 kWh`** en total (**~`0,67 €` de electricidad**).

### 🔥 Entorno D: Workstation de 24 GB+ VRAM (RTX 3090 / 4090 — Perfil `"potente"`)
* **Coste computacional**:
  * Si ejecuta el perfil `"estandar"` (`qwen2.5vl:7b`), despacha cada plano en `~1,3 segundos` y consume menos energía total (**`3,19 Wh`**) que una GPU de gama media porque termina en la mitad de tiempo.
  * Si ejecuta el perfil `"potente"` (`qwen2.5vl:32b` o `gemma3:27b`), la carga matemática se cuadruplica (~720 TFLOPs para 6 planos), elevando el consumo a **`6,64 Wh`** por expediente a cambio de la máxima capacidad de razonamiento visual disponible en local.

### 🍏 Entorno E: Apple Silicon (Mac Mini / MacBook Pro M2/M3/M4 Pro o Max)
* **Coste computacional**: Al compartir la misma memoria física entre CPU y GPU (`24 – 64 GB` unificados), **la conmutación entre el VLM (`qwen2.5vl:7b`) y `llama3.1` no requiere copiar gigabytes por un bus PCIe**, reduciendo la latencia de cambio de fase y el gasto energético de transferencia.
* **Impacto energético**: Consume apenas **`~58 W`** en pared a máxima carga de GPU Metal, completando todo el expediente multimodal en **`1,10 Wh`** (**más de 3 veces menos energía** que un PC de sobremesa equivalente con GPU dedicada).

---

## 4. Comparativa Directa de Coste Computacional y Energético: `v1` (Librería Python OCR) vs `version_vlm_local` (VLM + OCR)

| Métrica (Sobre PC Recomendado con RTX 3060 12 GB / 4060 Ti 16 GB) | `sistema_nitec_ocr_v1` (Solo `RapidOCR` + `llama3.1`) | `version_vlm_local` (`qwen2.5vl:7b` + `RapidOCR` + `llama3.1`) | Diferencia Neta |
| :--- | :--- | :--- | :--- |
| **Operaciones Matemáticas Totales / Expediente** | ~12 – 15 TFLOPs | ~190 – 200 TFLOPs | **~14x más FLOPs** *(por el codificador visual ViT)* |
| **Tiempo de Ejecución / Expediente (6 Planos)** | ~34 segundos | ~55 segundos | **+21 segundos** *(~3,2 s extra por cada plano leído con VLM)* |
| **Potencia Media durante la Ejecución** | ~215 W | ~245 W | **+30 W** *(mayor uso de Tensor Cores en fase visual)* |
| **Energía Total Consumida / Expediente** | **2,03 Wh** | **3,74 Wh** | **+1,71 Wh** *(+84 % de energía por expediente)* |
| **Coste Eléctrico cada 100 Expedientes** | **0,037 €** | **0,067 €** | **+0,030 € cada 100 proyectos** *(diferencia económica despreciable)* |
| **Capacidad de clasificar planos con nombres opacos (`lamina_01.pdf`) y leer cartelas complejas** | Limitada al texto lineal que reconozca el OCR | **Alta precisión visual y semántica (100 % local)** | Ventaja funcional decisiva en proyectos con mucha carga gráfica |
