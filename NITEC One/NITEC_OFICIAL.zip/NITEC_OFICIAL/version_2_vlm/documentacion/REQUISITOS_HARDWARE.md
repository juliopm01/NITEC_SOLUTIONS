# 👁️🖥️ Requisitos de Hardware — Sistema NITEC Versión VLM Local (`version_vlm_local`)

Este documento detalla el dimensionamiento de hardware necesario para ejecutar al completo la **Versión Híbrida Multimodal 100 % Local (`version_vlm_local`)**, que añade comprensión visual de planos, cartelas (cajetines), cuadros urbanísticos, fichas de catálogo e imágenes escaneadas mediante **modelos de visión locales en Ollama (`VLM`)** combinados con **`RapidOCR`**, **`llama3.1`** y **`nomic-embed-text`**, sin enviar ningún dato fuera del equipo.

---

## 1. Arquitectura de Consumo de Memoria (Por qué es eficiente en GPUs locales)

A diferencia de una ejecución ingenua que mantendría cargados a la vez el modelo de visión y el modelo de texto (lo que exigiría >18 GB de VRAM), `version_vlm_local` implementa dos optimizaciones clave de hardware:

1. **Descarga automática de VRAM entre fases (`"liberar_vram_entre_fases": true` en `config_vlm.json`)**:
   * Durante la inspección visual de planos e imágenes, Ollama carga el modelo VLM (`qwen2.5vl` / `gemma3`).
   * En cuanto termina la lectura gráfica, `motor_vision_local.py` envía `keep_alive: 0` a Ollama para **vaciar inmediatamente la VRAM** antes de cargar `llama3.1` (`num_ctx=16000`) o `nomic-embed-text`.
   * **Resultado práctico**: la tarjeta gráfica solo necesita capacidad para el mayor de los dos modelos en cada instante, reduciendo casi a la mitad la VRAM requerida.
2. **Enrutador Híbrido Inteligente + Doble Vista `Multi-Crop`**:
   * Las páginas digitales de memorias, normativas o boletines BOJA **no pasan por el VLM** (`0 ms` de gasto en GPU).
   * Solo los planos, láminas CAD y escaneos generan la pareja de vistas (`100 DPI` global máx. `1280 px` + `300 DPI` cartela máx. `1600 px`), acotando el consumo del codificador visual (*ViT*).

### Tabla de consumo real por componente

| Componente / Fase | Motor / Modelo Local | Recurso Principal | Peso en Disco | Pico de Memoria Activa (VRAM / RAM) |
| :--- | :--- | :--- | :--- | :--- |
| **Visión Perfil Ligero** | Ollama — `qwen2.5vl:3b` *(o `gemma3:4b`)* | **GPU (VRAM)** | ~3,2 GB | **~4,5 – 5,5 GB VRAM** *(incluye 2 vistas `Multi-Crop`)* |
| **Visión Perfil Estándar** | Ollama — `qwen2.5vl:7b` *(o `gemma3:12b`)* | **GPU (VRAM)** | ~6,0 – 8,1 GB | **~7,8 – 9,5 GB VRAM** *(incluye 2 vistas `Multi-Crop`)* |
| **Visión Perfil Potente** | Ollama — `gemma3:27b` / `qwen2.5vl:32b` | **GPU Workstation** | ~17 – 21 GB | **~19 – 23 GB VRAM** |
| **Razonamiento Texto (Ag. 1 y 2)** | Ollama — `llama3.1` (`8B`, `num_ctx=16000`) | **GPU (VRAM)** *(tras liberar VLM)* | ~4,7 GB | **~7,0 – 7,8 GB VRAM** |
| **Embeddings Vectoriales** | Ollama — `nomic-embed-text` | **GPU / CPU** | ~0,3 GB | **~0,4 – 0,6 GB** |
| **Renderizado `Multi-Crop` + OCR** | `PyMuPDF` (`100`/`300 DPI`) + `Pillow` + `RapidOCR` | **CPU + RAM** | ~0,25 GB | **~0,8 – 2,0 GB RAM** |
| **Agente 3 (Compresión y Corte)** | `PyMuPDF` + `pypdf` + `ChromaDB` | **CPU + RAM + SSD NVMe** | Temporal 2x peso proyecto | **~1,5 – 3,5 GB RAM** |

---

## 2. Perfiles de Hardware según el Equipo del Cliente (`config_vlm.json`)

El sistema adapta su carga al equipo del cliente mediante el parámetro `"perfil_hardware"` en `config_vlm.json`:

### 🟡 Perfil 1 — `"ligero"` (Portátiles Técnicos / Equipos Modestos)
*Configuración en `config_vlm.json`: `"perfil_hardware": "ligero"` con `ollama pull qwen2.5vl:3b`.*

* **Procesador (CPU)**: 6 u 8 núcleos modernos con `AVX2` (*Intel Core i5/i7 Gen 12+*, *AMD Ryzen 5/7 serie 5000+*).
* **Memoria RAM**: **16 GB mínimo** (**24 – 32 GB recomendado** si la GPU tiene poca VRAM y comparte memoria con el sistema).
* **Tarjeta Gráfica (GPU)**:
  * **Windows/Linux**: **GPU dedicada NVIDIA de 6 a 8 GB de VRAM** (ej. *RTX 3050 6/8 GB*, *RTX 3060 Laptop 6 GB*, *RTX 4050 6 GB*, *RTX 4060 8 GB*).
  * **Apple Silicon**: *MacBook Air / Pro o Mac Mini M1/M2/M3 con **16 GB de Memoria Unificada***.
  * *(Sin GPU dedicada: puede ejecutarse en CPU con 32 GB de RAM, o bien sin descargar ningún VLM para que el sistema opere automáticamente en modo respaldo `RapidOCR`).*
* **Almacenamiento**: **35 GB libres en SSD NVMe** (~8,5 GB en modelos Ollama + librerías + área temporal).
* **Rendimiento orientativo**: ~`3 – 6 s` por plano en GPU de 6–8 GB (~`20 – 40 s` por plano si corre solo en CPU).

---

### 🟢 Perfil 2 — `"estandar"` / `"auto"` (Recomendado Comercialmente para Estudios)
*Configuración por defecto (`"perfil_hardware": "auto"` o `"estandar"`) con `ollama pull qwen2.5vl:7b`. Ofrece el equilibrio óptimo entre nitidez de lectura en cajetines complejos `A0`/`A1` y coste del equipo.*

* **Procesador (CPU)**: **8 núcleos / 16 hilos** (*Intel Core i7-12700 / 13700 / 14700 / Core Ultra 7* o *AMD Ryzen 7 5800X / 7700X / 9700X*).
* **Memoria RAM**: **32 GB DDR4 / DDR5** *(permite recortar cartelas a `300 DPI`, sostener `RapidOCR` y empaquetar expedientes pesados sin cuellos de botella)*.
* **Tarjeta Gráfica (GPU)**:
  * **Opción PC Windows/Linux (Ideal)**: **NVIDIA con 12 a 16 GB de VRAM**:
    * *NVIDIA GeForce RTX 3060 (12 GB VRAM)* — opción más económica con 12 GB reales.
    * *NVIDIA GeForce RTX 4060 Ti (16 GB VRAM)* o *RTX 5060 Ti (16 GB VRAM)* — margen excelente para vistas de alta resolución.
    * *NVIDIA GeForce RTX 4070 / 4070 Super (12 GB VRAM)* — máxima velocidad de inferencia por plano.
    * *(Nota: en una RTX 4060 / 3070 de **8 GB de VRAM** también funciona de forma fluida gracias al reparto híbrido de Ollama y a las variables de optimización de la sección 3, aunque **12 GB** evita cualquier desbordamiento a RAM).*
  * **Opción Mac (Apple Silicon)**: **Mac Mini / MacBook Pro M2 Pro, M3 Pro o M4 Pro con 24 – 32 GB de Memoria Unificada**.
* **Almacenamiento**: **60 GB libres en SSD NVMe M.2 PCIe 4.0**.
* **Rendimiento orientativo**:
  * Lectura visual `Multi-Crop` (vista global + cartela 300 DPI): **~`2 – 5 segundos` por lámina**.
  * Flujo completo de un proyecto con memoria + varios planos: **~`35 – 90 segundos`**.

---

### 🔵 Perfil 3 — `"potente"` (Workstations de Consultoría Urbanística / Servidor Local de Estudio)
*Configuración en `config_vlm.json`: `"perfil_hardware": "potente"` con `ollama pull gemma3:27b` o `ollama pull qwen2.5vl:32b`.*

* **Procesador (CPU)**: **12 a 16+ núcleos** (*Intel Core i9-13900K/14900K*, *AMD Ryzen 9 7950X / 9950X* o *Apple M3/M4 Max*).
* **Memoria RAM**: **64 GB DDR5** *(o superior)*.
* **Tarjeta Gráfica (GPU)**:
  * **Windows/Linux**: **NVIDIA de 24 GB+ de VRAM** (*RTX 3090 24 GB*, *RTX 4090 24 GB*, *RTX 5090 32 GB* o *NVIDIA RTX A5000 / RTX 4500 Ada 24 GB*).
  * **Apple Silicon**: **Mac Studio / MacBook Pro M2/M3/M4 Max con 36 GB a 64 GB de Memoria Unificada**.
* **Almacenamiento**: **120+ GB libres en SSD NVMe PCIe 4.0**.
* **Ajuste avanzado opcional**: en equipos con `>= 36 GB` de VRAM/Memoria Unificada puedes poner `"liberar_vram_entre_fases": false` y `"max_paginas_vlm_por_pdf": 0` en `config_vlm.json` para mantener simultáneamente en memoria el VLM y `llama3.1` e inspeccionar visualmente todas las páginas de colecciones extensas de planos sin tiempo de recarga.

---

## 3. Recomendaciones Técnicas de Despliegue Local

1. **Priorizar GPU NVIDIA (CUDA) en Windows o Apple Silicon (Metal) en macOS**:
   * El procesamiento de tokens visuales (*Vision Transformer*) es intensivo en cálculo matricial. Una GPU dedicada NVIDIA RTX multiplica por **8x – 15x** la velocidad de lectura de planos frente a ejecutar un VLM únicamente sobre CPU.
2. **Optimización recomendada de variables de entorno para Ollama (especialmente en GPUs de 8 – 12 GB VRAM)**:
   ```powershell
   setx OLLAMA_FLASH_ATTENTION "1"
   setx OLLAMA_KV_CACHE_TYPE "q8_0"
   setx OLLAMA_MAX_LOADED_MODELS "1"
   ```
   * `OLLAMA_FLASH_ATTENTION=1` acelera la atención sobre las imágenes del plano y reduce el pico de VRAM del codificador visual.
   * `OLLAMA_KV_CACHE_TYPE=q8_0` ahorra ~1 GB de VRAM en la ventana de `16.000` tokens de `llama3.1`.
   * `OLLAMA_MAX_LOADED_MODELS=1` refuerza que Ollama nunca retenga dos modelos pesados en VRAM a la vez en tarjetas gráficas ajustadas.
3. **Ajuste fino sin cambiar hardware (`config_vlm.json`)**:
   * Si un cliente tiene muchos PDFs con decenas de planos repetitivos y un equipo modesto, basta con ajustar `"max_paginas_vlm_por_pdf": 2` (lee visualmente portada/primeras láminas y usa `RapidOCR` en el resto) para mantener tiempos de respuesta muy ágiles.
