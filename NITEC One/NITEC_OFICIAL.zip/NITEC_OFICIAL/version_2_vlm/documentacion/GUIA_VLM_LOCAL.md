# 👁️ Guía de Uso y Configuración — Versión 100 % Local con Visión VLM (`version_vlm_local`)

Esta carpeta contiene la variante autónoma **100 % en local (sin nube ni APIs externas)** equipada con lectura visual multimodal (`VLM`) sobre **Ollama** combinada con **RapidOCR** y **PyMuPDF**.

---

## 1. Modelos Locales en Ollama según el Hardware del Cliente

El sistema detecta automáticamente qué modelo visual está instalado en Ollama (`http://127.0.0.1:11434`). Solo necesitas descargar uno de los siguientes según la tarjeta gráfica del equipo:

* **Equipos con GPU dedicada de 8–12 GB VRAM (Perfil Estándar — Recomendado)**:
  ```bash
  ollama pull qwen2.5vl:7b
  ollama pull llama3.1
  ollama pull nomic-embed-text
  ```
* **Equipos modestos / portátiles con 4–6 GB VRAM o CPU rápida (Perfil Ligero)**:
  ```bash
  ollama pull qwen2.5vl:3b
  ollama pull llama3.1
  ollama pull nomic-embed-text
  ```
* **Estaciones de trabajo con 16–24+ GB VRAM (Perfil Potente)**:
  ```bash
  ollama pull gemma3:12b
  # o bien: ollama pull qwen2.5vl:32b
  ollama pull llama3.1
  ollama pull nomic-embed-text
  ```

> **Degradación automática garantizada**: si en un equipo concreto aún no se ha descargado ningún modelo visual en Ollama, el sistema sigue funcionando al 100 % usando `RapidOCR` local sin detenerse.

---

## 2. Cómo Ajustar el Perfil por Cliente (`config_vlm.json`)

Puedes editar `config_vlm.json` sin tocar el código Python:
* `"perfil_hardware"`: `"auto"` (autodetecta entre los instalados), `"estandar"`, `"ligero"` o `"potente"`.
* `"modelo_vlm_preferido"`: fuerza un modelo exacto si lo deseas (ej. `"qwen2.5vl:3b"`).
* `"dpi_vista_global"` (`100`) y `"dpi_recorte_cartela"` (`300`): resoluciones de la estrategia **Multi-Crop** para planos `A0`/`A1`.
* `"max_paginas_vlm_por_pdf"` (`4`): máximo de láminas/páginas gráficas por PDF enviadas al VLM (pon `0` para analizar visualmente todas las páginas sin límite).
* `"liberar_vram_entre_fases"` (`true`): descarga automáticamente el VLM de la tarjeta gráfica (`keep_alive: 0`) al terminar la inspección visual antes de ejecutar `llama3.1`.

---

## 3. Ejecución

```bash
cd version_vlm_local
pip install -r requirements.txt
python main.py
```
