"""
Módulo: creador_base_datos.py (Versión VLM Local — Archivador Vectorial Legal)
================================================================================
Propósito general:
    Indexa los boletines autonómicos y ordenanzas municipales de `./normativas_pdf`
    dentro de `./bd_normativas` (ChromaDB + `nomic-embed-text`).
    Al tratarse de textos normativos legales (y no planos arquitectónicos), invoca
    `cargar_pdf_con_ocr(..., usar_vlm=False)` para leer texto digital + `RapidOCR`
    a máxima velocidad sin consumir VRAM del modelo de visión.
================================================================================
"""

import gc
import os
import re
import shutil
import stat
import sys
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor

try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
    from langchain_ollama import OllamaEmbeddings
    from langchain_chroma import Chroma
    LANGCHAIN_DISPONIBLE = True
except Exception:
    RecursiveCharacterTextSplitter = None
    OllamaEmbeddings = None
    Chroma = None
    LANGCHAIN_DISPONIBLE = False

from lector_ocr_pdf import cargar_pdf_con_ocr

try:
    from geo_localizador import cargar_base_datos
except Exception:
    cargar_base_datos = lambda: {}

DIRECTORIO_BASE = os.path.dirname(os.path.abspath(__file__))
CARPETA_LEYES = os.path.join(DIRECTORIO_BASE, "normativas_pdf")
RUTA_BD_LEGAL = os.path.join(DIRECTORIO_BASE, "bd_normativas")

_PREFIJOS_RUIDO_MUNICIPIO = {
    "urbanistica", "urbanistico", "municipal", "local", "reguladora",
    "general", "sede", "electronica", "digital", "de", "del",
}

_SUFIJOS_RUIDO_MUNICIPIO = {
    "urbanistica", "urbanistico", "municipal", "local", "pdf",
    "definitiva", "inicial", "provisional", "consolidada", "vigente",
}


def _imprimir(mensaje):
    """Imprime de forma segura en consolas Windows cp1252 o flujos redirigidos."""
    try:
        print(mensaje)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        seguro = str(mensaje).encode(enc, errors="replace").decode(enc, errors="replace")
        print(seguro)


def _normalizar(texto):
    """Convierte un texto en identificador alfanumérico en minúsculas separado por guiones bajos."""
    if texto is None or isinstance(texto, bool):
        return ""
    texto = str(texto).strip().lower()
    if not texto:
        return ""
    texto_sin_tildes = "".join(
        c for c in unicodedata.normalize("NFD", texto)
        if unicodedata.category(c) != "Mn"
    )
    texto_limpio = re.sub(r"[\s\-–—_/.,;:'’‘\"“”()·]+", "_", texto_sin_tildes)
    return re.sub(r"[^a-z0-9_]", "", texto_limpio).strip("_")


def _limpiar_tokens_municipio(tokens):
    """Elimina prefijos/sufijos administrativos, años y versiones de un nombre candidato."""
    lista = [t for t in tokens if t]
    while lista and lista[0] in _PREFIJOS_RUIDO_MUNICIPIO:
        lista.pop(0)
    while lista and (
        lista[-1] in _SUFIJOS_RUIDO_MUNICIPIO
        or re.fullmatch(r"(?:19|20)\d{2}", lista[-1])
        or re.fullmatch(r"v\d+", lista[-1])
    ):
        lista.pop()
    candidato = "_".join(lista).strip("_")
    if candidato and candidato not in ("general", "local", "municipal", "urbanistica", "pdf"):
        return candidato
    return ""


def detectar_municipio_en_nombre(nombre_archivo):
    """Deduce a qué municipio corresponde un PDF normativo a partir de su nombre (`'general'` si es boletín autonómico)."""
    base_sin_ext = os.path.splitext(os.path.basename(str(nombre_archivo or "")))[0]
    nombre_norm = _normalizar(base_sin_ext)
    if not nombre_norm:
        return "general"

    palabras_boletin = (
        "boja", "boletin", "junta_de_andalucia", "normativa_autonomica",
        "normativa_general", "bocm", "dogc", "dogv", "nitec",
    )
    if any(p in nombre_norm for p in palabras_boletin):
        return "general"

    db_municipios = cargar_base_datos() or {}
    claves_ordenadas = sorted(db_municipios.keys(), key=len, reverse=True)
    for muni in claves_ordenadas:
        muni_norm = _normalizar(muni)
        if muni_norm and re.search(rf"(?:^|_){re.escape(muni_norm)}(?:_|$)", nombre_norm):
            return muni_norm

    coincidencia_prefijo = re.match(
        r"^(?:normativa|ordenanza|ayuntamiento(?:_de)?|municipio(?:_de)?|pgou|pgom|reglamento)_+([a-z0-9_]+)$",
        nombre_norm,
    )
    if coincidencia_prefijo:
        candidato = _limpiar_tokens_municipio(coincidencia_prefijo.group(1).split("_"))
        if candidato:
            return candidato

    coincidencia_sufijo = re.match(
        r"^([a-z0-9_]+?)_+(?:normativa|ordenanza|reglamento|pgou|pgom)(?:_[a-z0-9_]+)?$",
        nombre_norm,
    )
    if coincidencia_sufijo:
        candidato = _limpiar_tokens_municipio(coincidencia_sufijo.group(1).split("_"))
        if candidato:
            return candidato

    return "general"


def procesar_pdf(archivo, carpeta_leyes=None):
    """Lee un PDF normativo en modo rápido (digital + RapidOCR, `usar_vlm=False`) y añade metadatos municipales."""
    carpeta_activa = carpeta_leyes or CARPETA_LEYES
    ruta_completa = archivo if os.path.isabs(archivo) else os.path.join(carpeta_activa, archivo)
    nombre_base = os.path.basename(ruta_completa)
    muni_detectado = detectar_municipio_en_nombre(nombre_base)
    try:
        paginas = cargar_pdf_con_ocr(ruta_completa, incluir_cabecera_documento=False, usar_vlm=False)
        paginas_validas = []
        for pagina in paginas:
            if pagina.page_content and pagina.page_content.strip():
                pagina.metadata["categoria"] = "NORMATIVA_LEGAL"
                pagina.metadata["archivo_origen"] = nombre_base
                pagina.metadata["municipio"] = muni_detectado
                paginas_validas.append(pagina)
        return paginas_validas
    except Exception as e:
        _imprimir(f"   ⚠️ Error leyendo {nombre_base}: {e}")
        return []


def _desbloquear_ruta(func, path, *_):
    try:
        os.chmod(path, stat.S_IWRITE)
        func(path)
    except Exception:
        pass


def _rmtree_compatible(ruta):
    if sys.version_info >= (3, 12):
        shutil.rmtree(ruta, onexc=_desbloquear_ruta)
    else:
        shutil.rmtree(ruta, onerror=_desbloquear_ruta)


def _limpiar_bd_legal_si_existe(ruta_bd):
    if not os.path.exists(ruta_bd):
        return
    gc.collect()
    for intento in range(4):
        try:
            _rmtree_compatible(ruta_bd)
            if not os.path.exists(ruta_bd):
                break
        except PermissionError:
            gc.collect()
            time.sleep(0.3 * (intento + 1))
        except Exception:
            time.sleep(0.2)


def ingestar_normativas(ruta_pdf_extra=None):
    """Indexa transaccionalmente todos los PDFs legales en `./bd_normativas` con respaldo automático."""
    _imprimir("⚖️ Iniciando el Archivador Legal (Ingesta de Normativas 100% Local)...")

    if not os.path.exists(CARPETA_LEYES):
        os.makedirs(CARPETA_LEYES, exist_ok=True)
        _imprimir(f"📂 Carpeta creada: {CARPETA_LEYES}.")

    if ruta_pdf_extra:
        ruta_limpia = str(ruta_pdf_extra).strip().strip('"').strip("'")
        if os.path.isfile(ruta_limpia) and ruta_limpia.lower().endswith(".pdf") and os.path.getsize(ruta_limpia) > 0:
            destino = os.path.join(CARPETA_LEYES, os.path.basename(ruta_limpia))
            if os.path.abspath(ruta_limpia) != os.path.abspath(destino):
                try:
                    shutil.copy2(ruta_limpia, destino)
                    _imprimir(f"📥 PDF normativo copiado a {CARPETA_LEYES}: {os.path.basename(ruta_limpia)}")
                except Exception as e:
                    _imprimir(f"   ⚠️ No se pudo copiar {ruta_limpia}: {e}")

    archivos_pdf = []
    for raiz, subdirs, archivos in os.walk(CARPETA_LEYES):
        subdirs[:] = sorted([d for d in subdirs if not d.startswith(".")])
        for f in sorted(archivos):
            ruta_f = os.path.join(raiz, f)
            if f.lower().endswith(".pdf") and os.path.isfile(ruta_f) and os.path.getsize(ruta_f) > 0:
                archivos_pdf.append(ruta_f)

    if not archivos_pdf:
        _imprimir("⚠️ No hay normativas en './normativas_pdf' para procesar. Fin del archivador legal.")
        return {"estado": "SIN_NORMATIVAS", "paginas": 0}

    archivos_pdf.sort(key=os.path.getsize)

    documentos_legales = []
    carpeta_actual = CARPETA_LEYES
    with ThreadPoolExecutor(max_workers=min(4, len(archivos_pdf))) as ejecutor:
        resultados = ejecutor.map(lambda arch: procesar_pdf(arch, carpeta_actual), archivos_pdf)
        for paginas in resultados:
            documentos_legales.extend(paginas)

    if not documentos_legales:
        _imprimir("⚠️ No se pudo extraer texto de los PDFs legales.")
        return {"estado": "ERROR", "mensaje": "PDFs sin texto extraíble"}

    _imprimir(f"📚 Total de páginas legales leídas: {len(documentos_legales)}")

    if not LANGCHAIN_DISPONIBLE or RecursiveCharacterTextSplitter is None or Chroma is None:
        return {"estado": "ERROR", "mensaje": "Faltan dependencias de LangChain/Chroma. Ejecuta: pip install -r requirements.txt"}

    guillotina = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    fragmentos_legales = [
        frag for frag in guillotina.split_documents(documentos_legales)
        if frag.page_content and frag.page_content.strip()
    ]

    if not fragmentos_legales:
        return {"estado": "ERROR", "mensaje": "Fragmentos vacíos tras procesar PDFs legales"}

    base_de_datos_leyes = None
    ruta_respaldo = f"{RUTA_BD_LEGAL}_backup_tmp"
    habia_respaldo = False
    try:
        _limpiar_bd_legal_si_existe(ruta_respaldo)
        if os.path.exists(RUTA_BD_LEGAL):
            shutil.copytree(RUTA_BD_LEGAL, ruta_respaldo)
            habia_respaldo = True
        _limpiar_bd_legal_si_existe(RUTA_BD_LEGAL)

        modelo_coordenadas = OllamaEmbeddings(model="nomic-embed-text")
        _imprimir(f"💾 Guardando normativas de forma permanente en: {RUTA_BD_LEGAL}")
        base_de_datos_leyes = Chroma.from_documents(
            documents=fragmentos_legales,
            embedding=modelo_coordenadas,
            persist_directory=RUTA_BD_LEGAL
        )
        if habia_respaldo:
            _limpiar_bd_legal_si_existe(ruta_respaldo)
    except Exception as e:
        if base_de_datos_leyes is not None:
            del base_de_datos_leyes
            base_de_datos_leyes = None
        gc.collect()
        if habia_respaldo and os.path.exists(ruta_respaldo):
            _limpiar_bd_legal_si_existe(RUTA_BD_LEGAL)
            try:
                shutil.copytree(ruta_respaldo, RUTA_BD_LEGAL)
            except Exception:
                pass
            _limpiar_bd_legal_si_existe(ruta_respaldo)
        _imprimir(f"❌ Error al indexar normativas legales en Chroma: {e}")
        return {"estado": "ERROR", "mensaje": f"Fallo al indexar normativas legales: {e}"}
    finally:
        if base_de_datos_leyes is not None:
            del base_de_datos_leyes
        gc.collect()

    _imprimir("✅ Archivador Legal completado. Las leyes están listas para ser consultadas.")
    return {"estado": "COMPLETADO", "paginas": len(documentos_legales)}


if __name__ == "__main__":
    ruta_arg = sys.argv[1] if len(sys.argv) > 1 else None
    resultado = ingestar_normativas(ruta_arg)
    if resultado.get("estado") == "ERROR":
        sys.exit(1)
