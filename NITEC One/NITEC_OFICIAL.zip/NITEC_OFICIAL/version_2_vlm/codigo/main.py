"""
Módulo: main.py (Orquestador Principal — Versión 100 % Local con Visión VLM en Ollama)
================================================================================
Propósito general:
    Punto de entrada principal de `version_vlm_local`. Al iniciar informa del
    perfil de hardware y del modelo de visión local detectado en Ollama
    (`qwen2.5vl:7b`, `qwen2.5vl:3b`, `gemma3`, etc., o modo respaldo `RapidOCR`),
    y orquesta de principio a fin:
      1. Geolocalización y código INE municipal (`geo_localizador.py`).
      2. Sincronización de bases vectoriales locales (`./bd_normativas` y `./bd_vectores`).
      3. Agente 1 Híbrido (Texto Digital + `RapidOCR` + `VLM Multi-Crop`) ->
         metadatos legales + `especificaciones_agente_1.json`.
      4. Agente 2 -> estructura dinámica del BOJA + límite de peso municipal.
      5. Agente 3 -> compresión sin pérdida + fragmentación + carpeta final BOJA.
================================================================================
"""

import json
import os
import re
import subprocess
import sys
import unicodedata

from geo_localizador import obtener_datos_geograficos, registrar_municipio, obtener_codigo_ine
from agente_2_normativo_local import ejecutar_agente_2
from agente_3_procesador import ejecutar_agente_3
from motor_vision_local import cargar_configuracion_vlm, resolver_modelo_vlm_local

try:
    from agente_1_extractor import extraer_metadatos, clasificar_archivos_proyecto
    AGENTE_1_DISPONIBLE = True
except Exception:
    extraer_metadatos = None
    clasificar_archivos_proyecto = None
    AGENTE_1_DISPONIBLE = False

DIRECTORIO_BASE = os.path.dirname(os.path.abspath(__file__))
RUTA_BOJA_JSON = os.path.join(DIRECTORIO_BASE, "boja_base.json")
CARPETA_NORMATIVAS_PDF = os.path.join(DIRECTORIO_BASE, "normativas_pdf")
RUTA_BD_NORMATIVAS = os.path.join(DIRECTORIO_BASE, "bd_normativas")

_CARPETAS_EXCLUIDAS = {
    ".git", "__pycache__", "bd_vectores", "bd_normativas",
    "normativas_pdf", "partes_divididas", "salida_empaquetada",
}


def _imprimir(mensaje=""):
    try:
        print(mensaje)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        seguro = str(mensaje).encode(enc, errors="replace").decode(enc, errors="replace")
        print(seguro)


def _limpiar_ruta(ruta):
    if not ruta:
        return ""
    return str(ruta).strip().strip('"').strip("'")


def _normalizar(texto):
    if not texto or isinstance(texto, bool):
        return ""
    texto = str(texto).strip().lower()
    texto_sin_tildes = "".join(
        c for c in unicodedata.normalize("NFD", texto)
        if unicodedata.category(c) != "Mn"
    )
    texto_limpio = re.sub(r"[\s\-–—_/.,;:'’‘\"“”()·]+", "_", texto_sin_tildes)
    return re.sub(r"[^a-z0-9_]", "", texto_limpio).strip("_")


def _input_consola_seguro(prompt=""):
    try:
        return input(prompt)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        prompt_seguro = str(prompt).encode(enc, errors="replace").decode(enc, errors="replace")
        return input(prompt_seguro)


def _leer_input_seguro(prompt):
    try:
        return _input_consola_seguro(prompt)
    except EOFError:
        return ""


def _pedir_texto_no_vacio(prompt, valor_por_defecto=None, max_intentos=5):
    for _ in range(max_intentos):
        try:
            valor = _input_consola_seguro(prompt).strip()
        except EOFError:
            return valor_por_defecto if valor_por_defecto is not None else ""
        if valor:
            return valor
        if valor_por_defecto is not None:
            return valor_por_defecto
        _imprimir("   ❌ Este campo no puede estar vacío. Inténtalo de nuevo.")
    return valor_por_defecto or ""


def _extraer_entero_positivo_usuario(texto):
    if not texto:
        return None
    limpio = str(texto).strip()
    if re.match(r"^\s*-", limpio):
        return None
    m = re.match(r"^([0-9]+)(?:\s*(?:mb|megabytes?|megas?))?$", limpio, flags=re.IGNORECASE)
    if m:
        valor = int(m.group(1))
        return valor if valor > 0 else None
    return None


def _autodetectar_pdf_principal(ruta_carpeta_proyecto):
    if not ruta_carpeta_proyecto or not os.path.isdir(ruta_carpeta_proyecto):
        return ""

    pdfs_raiz = sorted([
        os.path.join(ruta_carpeta_proyecto, f)
        for f in os.listdir(ruta_carpeta_proyecto)
        if f.lower().endswith(".pdf")
        and "_tomo_" not in f.lower()
        and "_parte_" not in f.lower()
        and os.path.isfile(os.path.join(ruta_carpeta_proyecto, f))
        and os.path.getsize(os.path.join(ruta_carpeta_proyecto, f)) > 0
    ])
    if pdfs_raiz:
        return pdfs_raiz[0]

    for raiz, subcarpetas, archivos in os.walk(ruta_carpeta_proyecto):
        subcarpetas[:] = sorted([
            d for d in subcarpetas
            if not d.startswith(".") and d.lower() not in _CARPETAS_EXCLUIDAS
        ])
        for f in sorted(archivos):
            f_low = f.lower()
            if f_low.endswith(".pdf") and "_tomo_" not in f_low and "_parte_" not in f_low:
                candidato = os.path.join(raiz, f)
                if os.path.isfile(candidato) and os.path.getsize(candidato) > 0:
                    return candidato
    return ""


def _bd_legal_actualizada(ruta_bd_legal, carpeta_normativas):
    sqlite_file = os.path.join(ruta_bd_legal, "chroma.sqlite3")
    if not os.path.isfile(sqlite_file) or os.path.getsize(sqlite_file) == 0:
        return False
    if os.path.isdir(carpeta_normativas):
        mtime_bd = os.path.getmtime(sqlite_file)
        for raiz, subdirs, archivos in os.walk(carpeta_normativas):
            subdirs[:] = [d for d in subdirs if not d.startswith(".")]
            for f in archivos:
                ruta_f = os.path.join(raiz, f)
                if f.lower().endswith(".pdf") and os.path.isfile(ruta_f):
                    if os.path.getmtime(ruta_f) > mtime_bd:
                        return False
    return True


def _actualizar_bd_legal(ruta_pdf_normativa=None):
    script_bd_legal = os.path.join(DIRECTORIO_BASE, "creador_base_datos.py")
    env_utf8 = dict(os.environ)
    env_utf8["PYTHONIOENCODING"] = "utf-8"
    env_utf8["PYTHONUTF8"] = "1"
    _imprimir("   ⚠️ Actualizando './bd_normativas'. Lanzando ingestor legal...")
    try:
        cmd = [sys.executable, script_bd_legal]
        if ruta_pdf_normativa:
            cmd.append(ruta_pdf_normativa)
        subprocess.run(cmd, check=True, cwd=DIRECTORIO_BASE, env=env_utf8)
        _imprimir("   ✅ Proceso de base de datos legal finalizado.")
        return True
    except Exception as e:
        _imprimir(f"   ❌ Error al crear bd_normativas: {e}")
        return False


def comprobar_y_crear_bases_datos(ruta_carpeta_proyecto, ruta_pdf_normativa=None):
    _imprimir("\n🔍 [Pre-vuelo] Comprobando el estado de las bases de datos...")
    script_bd_vectores = os.path.join(DIRECTORIO_BASE, "creador_base_vectores.py")

    env_utf8 = dict(os.environ)
    env_utf8["PYTHONIOENCODING"] = "utf-8"
    env_utf8["PYTHONUTF8"] = "1"

    if ruta_pdf_normativa or not _bd_legal_actualizada(RUTA_BD_NORMATIVAS, CARPETA_NORMATIVAS_PDF):
        _actualizar_bd_legal(ruta_pdf_normativa)
    else:
        _imprimir("   ✅ Base de datos legal lista.")

    if not ruta_carpeta_proyecto or not os.path.isdir(ruta_carpeta_proyecto):
        _imprimir(f"   ⚠️ Carpeta de proyecto no válida o inexistente: {ruta_carpeta_proyecto}")
        return False

    _imprimir(f"   🔄 Procesando la carpeta del proyecto: {ruta_carpeta_proyecto}")
    try:
        subprocess.run(
            [sys.executable, script_bd_vectores, ruta_carpeta_proyecto],
            check=True,
            cwd=DIRECTORIO_BASE,
            env=env_utf8,
        )
        return True
    except Exception as e:
        _imprimir(f"   ❌ Error al procesar el proyecto: {e}")
        return False


def main():
    _imprimir("============================================================")
    _imprimir("🚀 INICIANDO ORQUESTADOR NITEC (VERSIÓN 100% LOCAL VLM + OCR)")
    _imprimir("============================================================")

    cfg_vlm = cargar_configuracion_vlm()
    modelo_vlm, motivo_vlm = resolver_modelo_vlm_local(cfg_vlm)
    if modelo_vlm:
        _imprimir(f"👁️ Motor de Visión Local detectado en Ollama: '{modelo_vlm}' ({motivo_vlm})")
    else:
        _imprimir("ℹ️ Sin modelo visual VLM descargado en Ollama (operando con respaldo local RapidOCR).")
        _imprimir("   Consejo: ejecuta 'ollama pull qwen2.5vl:7b' (o 'qwen2.5vl:3b') para activar visión completa.\n")

    _imprimir("📋 DATOS DEL PROYECTO")
    municipio = _pedir_texto_no_vacio("👉 Introduce el municipio (ej. Málaga): ")

    datos_geo = obtener_datos_geograficos(municipio)
    if datos_geo:
        comunidad = datos_geo["comunidad"]
        provincia = datos_geo["provincia"]
        _imprimir(f"   📍 Detectado automáticamente: Provincia de {provincia}, {comunidad}.")
    else:
        _imprimir("   ⚠️ Municipio no encontrado en la base de datos local.")
        provincia = _pedir_texto_no_vacio("   👉 Introduce la provincia manualmente: ")
        comunidad = _pedir_texto_no_vacio("   👉 Introduce la Comunidad Autónoma manualmente: ")
        if municipio and provincia and comunidad:
            registrar_municipio(municipio, provincia, comunidad)
            _imprimir(f"   💾 Municipio '{municipio}' ({provincia}, {comunidad}) guardado en 'municipios_espana.json'.")

    codigo_ine = obtener_codigo_ine(municipio, provincia=provincia)
    tipo_proyecto = _pedir_texto_no_vacio("👉 Introduce el tipo de proyecto (ej. PGOM, ED): ").upper()

    entrada_carpeta = _limpiar_ruta(
        _pedir_texto_no_vacio("👉 Introduce la ruta a la CARPETA del proyecto (con todos los PDFs/imágenes): ")
    )
    pdf_sugerido = ""
    if entrada_carpeta and os.path.isfile(entrada_carpeta) and entrada_carpeta.lower().endswith(".pdf"):
        pdf_sugerido = entrada_carpeta
        ruta_carpeta_proyecto = os.path.dirname(os.path.abspath(entrada_carpeta))
        _imprimir(f"   📂 Se detectó ruta a archivo PDF; usando carpeta contenedora: {ruta_carpeta_proyecto}")
    else:
        ruta_carpeta_proyecto = entrada_carpeta

    # Autodetección automática del documento principal para carátula sin interrumpir al usuario
    if pdf_sugerido:
        ruta_pdf_proyecto = pdf_sugerido
    elif ruta_carpeta_proyecto and os.path.isdir(ruta_carpeta_proyecto):
        ruta_pdf_proyecto = _autodetectar_pdf_principal(ruta_carpeta_proyecto)
    else:
        ruta_pdf_proyecto = ""

    if ruta_pdf_proyecto:
        _imprimir(f"   ✓ Documento principal autodetectado para carátula: {ruta_pdf_proyecto}")

    ruta_pdf_normativa = None
    boja_valido = False
    if os.path.exists(RUTA_BOJA_JSON):
        try:
            with open(RUTA_BOJA_JSON, "r", encoding="utf-8") as f:
                d = json.load(f)
                boja_valido = isinstance(d, dict) and isinstance(d.get("proyectos"), dict)
        except Exception:
            boja_valido = False

    if not boja_valido:
        pdfs_boja = [
            os.path.join(CARPETA_NORMATIVAS_PDF, f)
            for f in os.listdir(CARPETA_NORMATIVAS_PDF)
            if f.lower().endswith(".pdf") and any(k in _normalizar(f) for k in ("boja", "boletin", "junta", "autonomic"))
        ] if os.path.isdir(CARPETA_NORMATIVAS_PDF) else []

        if pdfs_boja:
            ruta_pdf_normativa = pdfs_boja[0]
            _imprimir(f"   📄 Detectado PDF del BOJA en carpeta: {ruta_pdf_normativa}")
        else:
            if _normalizar(comunidad) == "andalucia":
                ruta_pdf_normativa = _limpiar_ruta(
                    _leer_input_seguro("👉 [Configuración Inicial - Solo 1ª vez] Introduce la ruta al PDF del BOJA: ")
                )
            else:
                ruta_pdf_normativa = _limpiar_ruta(
                    _leer_input_seguro(f"👉 [Configuración Inicial - Solo 1ª vez] Introduce la ruta al PDF del boletín de {comunidad}: ")
                )

    comprobar_y_crear_bases_datos(ruta_carpeta_proyecto, ruta_pdf_normativa)

    _imprimir("\n============================================================")

    _imprimir("\n⚙️ [Paso 1] Ejecutando Agente 1 (Extractor Híbrido VLM + OCR)...")
    if AGENTE_1_DISPONIBLE and extraer_metadatos is not None:
        try:
            datos_caratula = extraer_metadatos(ruta_pdf_proyecto)
        except Exception as e:
            _imprimir(f"⚠️ Error en Agente 1: {e}")
            datos_caratula = {
                "fase_tramitacion": "NO_ENCONTRADA",
                "fecha_aprobacion": "NO_ENCONTRADA",
                "error": "Fallo en la extracción",
            }
    else:
        datos_caratula = {
            "fase_tramitacion": "NO_ENCONTRADA",
            "fecha_aprobacion": "NO_ENCONTRADA",
        }

    _imprimir("\n⚙️ [Paso 2] Ejecutando Agente 2 (Auditor Normativo Local)...")
    reglas_normativas = ejecutar_agente_2(municipio, tipo_proyecto, ruta_boja_pdf=ruta_pdf_normativa)

    intentos_boja = 0
    while reglas_normativas.get("estado") == "REQUIERE_BOJA_PDF" and intentos_boja < 5:
        intentos_boja += 1
        _imprimir(f"\n⚠️ {reglas_normativas.get('mensaje')}")
        try:
            nueva_ruta = _limpiar_ruta(_input_consola_seguro("👉 Introduce la ruta válida al PDF del BOJA: "))
        except EOFError:
            break
        if nueva_ruta:
            ruta_pdf_normativa = nueva_ruta
            if os.path.isfile(nueva_ruta) and not _bd_legal_actualizada(RUTA_BD_NORMATIVAS, CARPETA_NORMATIVAS_PDF):
                _actualizar_bd_legal(nueva_ruta)
            reglas_normativas = ejecutar_agente_2(municipio, tipo_proyecto, ruta_boja_pdf=ruta_pdf_normativa)
        else:
            _imprimir("❌ La ruta no puede estar vacía.")

    if reglas_normativas.get("estado") == "REQUIERE_LIMITE_MANUAL":
        _imprimir(f"\n⚠️ El Ayuntamiento de {municipio} aún no tiene límite registrado en memoria.")
        for _ in range(5):
            try:
                limite_manual = _input_consola_seguro(
                    f"👉 Introduce a mano el límite de peso en MB para {municipio} (se guardará para futuras ejecuciones): "
                ).strip()
            except EOFError:
                break
            valor_mb = _extraer_entero_positivo_usuario(limite_manual)
            if valor_mb is not None:
                reglas_normativas = ejecutar_agente_2(
                    municipio,
                    tipo_proyecto,
                    ruta_boja_pdf=ruta_pdf_normativa,
                    limite_manual_mb=valor_mb,
                )
                break
            _imprimir("❌ Por favor, introduce un número entero mayor que 0 (ej. 25).")

    normativas_salida = dict(reglas_normativas) if isinstance(reglas_normativas, dict) else {}
    estado_normativo = normativas_salida.get("estado")
    if estado_normativo == "COMPLETADO":
        del normativas_salida["estado"]

    referencia_especificaciones_ag1 = None
    if (
        estado_normativo == "COMPLETADO"
        and AGENTE_1_DISPONIBLE
        and callable(clasificar_archivos_proyecto)
        and ruta_carpeta_proyecto
        and os.path.isdir(ruta_carpeta_proyecto)
    ):
        try:
            espec_ag1 = clasificar_archivos_proyecto(
                ruta_carpeta_proyecto,
                reglas_identidad=normativas_salida.get("reglas_identidad"),
                metadatos_caratula=datos_caratula,
                config_vlm=cfg_vlm,
            )
            if isinstance(espec_ag1, dict) and espec_ag1.get("estado") == "COMPLETADO":
                ruta_json_ag1 = espec_ag1.get("ruta_json_generado")
                referencia_especificaciones_ag1 = (
                    ruta_json_ag1 if (ruta_json_ag1 and os.path.isfile(ruta_json_ag1)) else espec_ag1
                )
        except Exception as e_cls:
            _imprimir(f"⚠️ Aviso al clasificar archivos del proyecto en Agente 1: {e_cls}")

    resultado_final = {
        "municipio": municipio,
        "codigo_ine": codigo_ine,
        "provincia": provincia,
        "comunidad_autonoma": comunidad,
        "tipo_proyecto": tipo_proyecto,
        "carpeta_proyecto": ruta_carpeta_proyecto,
        "archivo_origen": ruta_pdf_proyecto,
        "modelo_vlm_local": modelo_vlm or "NINGUNO_RESPALDO_OCR",
        "metadatos_caratula": datos_caratula,
        "normativas_empaquetado": normativas_salida,
    }
    if referencia_especificaciones_ag1 is not None:
        resultado_final["especificaciones_agente_1"] = referencia_especificaciones_ag1

    if estado_normativo == "COMPLETADO" and (
        (ruta_pdf_proyecto and os.path.isfile(ruta_pdf_proyecto))
        or referencia_especificaciones_ag1 is not None
    ):
        _imprimir("\n⚙️ [Paso 3] Ejecutando Agente 3 (Compresión sin pérdida, Fragmentación y Empaquetado BOJA)...")
        resultado_final["procesamiento_pdf"] = ejecutar_agente_3(resultado_final)

    _imprimir("\n============================================================")
    if estado_normativo == "COMPLETADO":
        _imprimir("✅ DATOS CONSOLIDADOS CON ÉXITO")
    else:
        _imprimir("⚠️ PROCESO FINALIZADO CON ADVERTENCIAS EN NORMATIVA")
    _imprimir("============================================================")

    _imprimir(json.dumps(resultado_final, indent=2, ensure_ascii=False))
    return resultado_final


if __name__ == "__main__":
    main()
