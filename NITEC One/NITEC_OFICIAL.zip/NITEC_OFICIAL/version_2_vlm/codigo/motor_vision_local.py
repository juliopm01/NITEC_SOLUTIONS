"""
Módulo: motor_vision_local.py (Motor de Visión Multimodal 100 % Local sobre Ollama)
================================================================================
Propósito general:
    Implementa la capa de inteligencia visual local de `version_vlm_local` para
    leer, comprender e identificar planos arquitectónicos/urbanísticos, cartelas
    (cajetines), cuadros de superficies, fichas de catálogo e imágenes escaneadas
    utilizando exclusivamente un LLM Multimodal (VLM) ejecutado en local mediante
    Ollama (`127.0.0.1` / `localhost`), sin enviar jamás ningún dato a internet.

Características técnicas clave:
    1. Seguridad 100 % Local por Diseño (`_validar_url_estrictamente_local`):
       Bloquea por código cualquier endpoint que no apunte a `127.0.0.1`,
       `localhost` o `::1`, garantizando privacidad absoluta de los expedientes.
    2. Adaptabilidad de Hardware por Cliente (`resolver_modelo_vlm_local`):
       Soporta perfiles configurables (`estandar` -> `qwen2.5vl:7b`, `ligero` ->
       `qwen2.5vl:3b`, `potente` -> `qwen2.5vl:32b` y `auto`) consultando los
       modelos realmente descargados en el servidor Ollama local (`/api/tags`).
    3. Estrategia Doble Vista `Multi-Crop` para Planos Técnicos:
       - Vista Global (`100 DPI`): captura la composición general del plano
         (ortofoto, zonificación, plantas, alzados, secciones, esquemas).
       - Recorte Nítido de Cartela (`300 DPI` en PDF o `1:1` nativo en imagen):
         aísla en alta resolución el cuadrante inferior derecho/margen donde se
         ubica reglamentariamente el cajetín con título, código, escala, fase y fecha.
    4. Anclaje con OCR (`OCR-grounded VLM`):
       Inyecta en el prompt visual el texto previo detectado por `RapidOCR` para
       fijar con exactitud milimétrica cifras, fechas, escalas y siglas de ámbito.
    5. Gestión Inteligente de VRAM (`liberar_modelo_vlm_en_ollama`):
       Descarga bajo demanda el modelo visual de la GPU (`keep_alive=0`) al
       terminar la inspección gráfica para dejar toda la VRAM libre a `llama3.1`.
================================================================================
"""

import ast
import base64
import io
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request

# Carga opcional de PyMuPDF (fitz) para renderizado selectivo y recorte vectorial de planos PDF
try:
    import fitz
    PYMUPDF_DISPONIBLE = True
except Exception:
    fitz = None
    PYMUPDF_DISPONIBLE = False

# Carga opcional de Pillow (PIL) para recorte de alta nitidez sobre imágenes sueltas (.png, .jpg, .tif...)
try:
    from PIL import Image
    PILLOW_DISPONIBLE = True
except Exception:
    Image = None
    PILLOW_DISPONIBLE = False

DIRECTORIO_BASE = os.path.dirname(os.path.abspath(__file__))
RUTA_CONFIG_VLM = os.path.join(DIRECTORIO_BASE, "config_vlm.json")

# Configuración por defecto si `config_vlm.json` no existiera o tuviera algún campo ausente
_CONFIG_POR_DEFECTO = {
    "perfil_hardware": "auto",
    "ollama_base_url": "http://127.0.0.1:11434",
    "modelo_vlm_preferido": "",
    "modelos_por_perfil": {
        "estandar": [
            "qwen2.5vl:7b",
            "gemma3:12b",
            "llama3.2-vision:11b",
            "minicpm-v:8b",
            "qwen2.5vl:3b",
            "gemma3:4b",
        ],
        "ligero": [
            "qwen2.5vl:3b",
            "gemma3:4b",
            "minicpm-v:8b",
            "qwen2.5vl:7b",
        ],
        "potente": [
            "qwen2.5vl:32b",
            "gemma3:27b",
            "gemma3:12b",
            "qwen2.5vl:7b",
            "llama3.2-vision:11b",
        ],
    },
    "modelo_texto": "llama3.1",
    "modelo_embeddings": "nomic-embed-text",
    "dpi_vista_global": 100,
    "dpi_recorte_cartela": 300,
    "lado_maximo_px_global": 1280,
    "lado_maximo_px_cartela": 1600,
    "max_paginas_vlm_por_pdf": 4,
    "timeout_segundos_vlm": 90,
    "liberar_vram_entre_fases": True,
}

# Familias conocidas de modelos con capacidad visual en Ollama (para autodetección cuando hay tags personalizados)
_PREFIJOS_FAMILIAS_VLM = (
    "qwen2.5vl",
    "qwen2-vl",
    "qwen3-vl",
    "gemma3",
    "llama3.2-vision",
    "minicpm-v",
    "llava",
    "bakllava",
    "moondream",
    "pixtral",
    "granite3.2-vision",
)

# Hosts estrictamente locales permitidos (bloquea cualquier salida accidental hacia servidores externos)
_HOSTS_LOCALES_PERMITIDOS = {"127.0.0.1", "localhost", "::1", "[::1]"}

# Prompt estructurado especializado en lectura técnica de planos, cartelas e imágenes de arquitectura/ingeniería
_PROMPT_ANALISIS_VISUAL_TECNICO = """Eres un Arquitecto e Ingeniero Urbanista experto en lectura de planos técnicos, cartelas (cajetines), cuadros urbanísticos y documentación gráfica.
Se te proporcionan imágenes del documento '{nombre_archivo}' (página {numero_pagina}):
- Imagen 1: Vista general completa de la página o plano para identificar su tipología gráfica.
- Imagen 2 (si se adjunta): Recorte en alta resolución del cajetín/cartela (esquina inferior derecha/margen) para leer con nitidez títulos, códigos, escalas, fechas y fases.

Texto auxiliar detectado previamente por OCR rápido (úsalo como referencia para no confundir dígitos ni siglas):
{texto_ocr_apoyo}

Analiza visualmente las imágenes y devuelve EXCLUSIVAMENTE un objeto JSON válido (sin texto adicional ni bloques markdown) con esta estructura exacta:
{{
  "es_plano_o_cartografia": true,
  "tipo_visual_detectado": "PLANO_INFORMACION | PLANO_ORDENACION | PLANO_ARQUITECTURA_INGENIERIA | CATALOGO_PLANOS | CATALOGO_FICHAS | PORTADA_CARATULA | TABLA_CUADRO_TECNICO | MEMORIA_ESCANEADA | OTRO_GRAFICO",
  "titulo_documento_o_plano": "Título exacto leído en la cartela o cabecera (o cadena vacía)",
  "codigo_plano": "Código del plano en el cajetín, ej. I-01, O-02, P-04 (o cadena vacía)",
  "escala": "Escala principal leída, ej. 1:1000, 1:500 (o cadena vacía)",
  "fase_tramitacion": "Sigla o nombre de fase si aparece en cartela/portada (AD, AI, AP, TR, AV o NO_ENCONTRADA)",
  "fecha_documento": "Fecha oficial de aprobación o firma si aparece (formato AAAAMMDD o DD/MM/AAAA, o NO_ENCONTRADA)",
  "ambito": "Siglas del ámbito/sector/unidad de ejecución si figuran en cartela, ej. UE-01, SUP-2 (o NO_ENCONTRADO)",
  "resumen_contenido_visual": "Descripción técnica breve de lo que representa gráficamente la página o plano",
  "texto_clave_transcrito": "Transcripción limpia de los textos más relevantes del cajetín, leyenda o encabezados"
}}"""

# Caché ligera de sesión del modelo VLM detectado para no consultar `/api/tags` en cada página
_CACHE_MODELO_DETECTADO = {"url": None, "perfil": None, "preferido": None, "modelo": None, "consultado": False}


def reiniciar_cache_vlm():
    """Limpia la caché en memoria del modelo VLM resuelto (útil al cambiar configuración o en tests)."""
    _CACHE_MODELO_DETECTADO["url"] = None
    _CACHE_MODELO_DETECTADO["perfil"] = None
    _CACHE_MODELO_DETECTADO["preferido"] = None
    _CACHE_MODELO_DETECTADO["modelo"] = None
    _CACHE_MODELO_DETECTADO["consultado"] = False


def _validar_url_estrictamente_local(url):
    """
    Garantiza por código que la URL de Ollama apunte única y exclusivamente a la máquina local
    (`127.0.0.1`, `localhost` o `::1`), lanzando `ValueError` ante cualquier servidor remoto.
    """
    if not url or not isinstance(url, str):
        raise ValueError("La URL de Ollama no puede estar vacía.")
    limpia = url.strip().rstrip("/")
    parsed = urllib.parse.urlparse(limpia)
    if parsed.scheme not in ("http", "https"):
        raise ValueError(f"Esquema no permitido en URL de Ollama: '{parsed.scheme}'.")
    host = (parsed.hostname or "").strip().lower()
    if host not in _HOSTS_LOCALES_PERMITIDOS:
        raise ValueError(
            f"Seguridad Modo 100% Local: se bloqueó el host externo '{host}'. "
            f"Solo se permite ejecución local en 127.0.0.1 / localhost."
        )
    return limpia


def _entero_acotado(valor, defecto, minimo, maximo=None):
    """Convierte `valor` a entero acotado de forma segura ignorando booleanos o cadenas inválidas."""
    if valor is None or isinstance(valor, bool):
        num = defecto
    else:
        try:
            num = int(valor)
        except (TypeError, ValueError):
            num = defecto
    num = max(minimo, num)
    if maximo is not None:
        num = min(maximo, num)
    return num


def cargar_configuracion_vlm(ruta_config=None):
    """
    Carga la configuración de visión local combinando:
    1. Valores base seguros (`_CONFIG_POR_DEFECTO`).
    2. Archivo `config_vlm.json` del cliente/instalación.
    3. Variables de entorno opcionales (`NITEC_PERFIL_VLM`, `NITEC_MODELO_VLM`, `NITEC_OLLAMA_URL`).
    """
    cfg = json.loads(json.dumps(_CONFIG_POR_DEFECTO))
    ruta_efectiva = ruta_config or os.environ.get("NITEC_CONFIG_VLM") or RUTA_CONFIG_VLM

    if ruta_efectiva and os.path.isfile(ruta_efectiva):
        try:
            with open(ruta_efectiva, "r", encoding="utf-8") as f:
                disco = json.load(f)
            if isinstance(disco, dict):
                for k, v in disco.items():
                    if k == "modelos_por_perfil" and isinstance(v, dict):
                        for pk, pv in v.items():
                            if isinstance(pv, list) and pv:
                                cfg["modelos_por_perfil"][pk] = [str(x).strip() for x in pv if str(x).strip()]
                    elif v is not None:
                        cfg[k] = v
        except Exception:
            pass

    # Sobrescritura opcional mediante variables de entorno para despliegues automatizados en local
    if os.environ.get("NITEC_PERFIL_VLM"):
        cfg["perfil_hardware"] = os.environ["NITEC_PERFIL_VLM"].strip().lower()
    if os.environ.get("NITEC_MODELO_VLM"):
        cfg["modelo_vlm_preferido"] = os.environ["NITEC_MODELO_VLM"].strip()
    if os.environ.get("NITEC_OLLAMA_URL"):
        cfg["ollama_base_url"] = os.environ["NITEC_OLLAMA_URL"].strip()

    cfg["ollama_base_url"] = _validar_url_estrictamente_local(cfg.get("ollama_base_url", "http://127.0.0.1:11434"))
    cfg["dpi_vista_global"] = _entero_acotado(cfg.get("dpi_vista_global"), 100, 72, 200)
    cfg["dpi_recorte_cartela"] = _entero_acotado(cfg.get("dpi_recorte_cartela"), 300, 150, 450)
    cfg["lado_maximo_px_global"] = _entero_acotado(cfg.get("lado_maximo_px_global"), 1280, 640, 2048)
    cfg["lado_maximo_px_cartela"] = _entero_acotado(cfg.get("lado_maximo_px_cartela"), 1600, 800, 2560)
    cfg["max_paginas_vlm_por_pdf"] = _entero_acotado(cfg.get("max_paginas_vlm_por_pdf"), 4, 0, None)
    cfg["timeout_segundos_vlm"] = _entero_acotado(cfg.get("timeout_segundos_vlm"), 90, 5, None)
    cfg["liberar_vram_entre_fases"] = bool(cfg.get("liberar_vram_entre_fases", True))
    return cfg


def _peticion_json_ollama_local(base_url, endpoint, payload=None, timeout=10):
    """Realiza una llamada HTTP estrictamente local (`127.0.0.1`/`localhost`) al servidor Ollama."""
    url_segura = _validar_url_estrictamente_local(base_url)
    url_completa = f"{url_segura}/{endpoint.lstrip('/')}"
    datos_bytes = None
    metodo = "GET"
    cabeceras = {"Accept": "application/json"}

    if payload is not None:
        metodo = "POST"
        datos_bytes = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        cabeceras["Content-Type"] = "application/json"

    req = urllib.request.Request(url_completa, data=datos_bytes, headers=cabeceras, method=metodo)
    # Desactivar proxies del sistema para conexiones a localhost (evita desvíos corporativos)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(req, timeout=timeout) as resp:
        cuerpo = resp.read().decode("utf-8", errors="replace")
        return json.loads(cuerpo) if cuerpo.strip() else {}


def listar_modelos_ollama_locales(base_url="http://127.0.0.1:11434", timeout=3):
    """Consulta `GET /api/tags` en el Ollama local y devuelve la lista de nombres de modelos instalados."""
    try:
        datos = _peticion_json_ollama_local(base_url, "/api/tags", payload=None, timeout=timeout)
        modelos_raw = datos.get("models") if isinstance(datos, dict) else []
        nombres = []
        for m in modelos_raw or []:
            if isinstance(m, dict) and m.get("name"):
                nombres.append(str(m["name"]).strip())
        return nombres
    except Exception:
        return []


def _coincide_modelo_instalado(candidato, instalados):
    """Comprueba si un modelo candidato (ej. 'qwen2.5vl:7b') coincide exacta o parcialmente con los instalados."""
    cand_low = candidato.strip().lower()
    for inst in instalados:
        inst_low = inst.strip().lower()
        if inst_low == cand_low:
            return inst
        # Si el candidato no especifica tag (ej. 'qwen2.5vl') y está 'qwen2.5vl:latest' o 'qwen2.5vl:7b'
        if ":" not in cand_low and inst_low.split(":", 1)[0] == cand_low:
            return inst
    return None


def resolver_modelo_vlm_local(config=None, forzar_reconsulta=False):
    """
    Determina qué modelo multimodal local emplear según la configuración del cliente y los
    modelos disponibles en su instancia local de Ollama:
    - Devuelve `(nombre_modelo, motivo_seleccion)` o `(None, motivo_no_disponible)` si no hay VLM activo.
    """
    cfg = config if isinstance(config, dict) else cargar_configuracion_vlm()
    base_url = cfg["ollama_base_url"]
    perfil = str(cfg.get("perfil_hardware") or "auto").strip().lower()
    preferido = str(cfg.get("modelo_vlm_preferido") or "").strip()

    if (
        not forzar_reconsulta
        and _CACHE_MODELO_DETECTADO["consultado"]
        and _CACHE_MODELO_DETECTADO["url"] == base_url
        and _CACHE_MODELO_DETECTADO["perfil"] == perfil
        and _CACHE_MODELO_DETECTADO["preferido"] == preferido
    ):
        modelo_cache = _CACHE_MODELO_DETECTADO["modelo"]
        return (modelo_cache, "CACHE_SESION") if modelo_cache else (None, "SIN_VLM_EN_OLLAMA_LOCAL")

    instalados = listar_modelos_ollama_locales(base_url=base_url, timeout=3)
    elegido = None
    motivo = "SIN_VLM_EN_OLLAMA_LOCAL"

    if instalados:
        # 1. Si el cliente fijó explícitamente `modelo_vlm_preferido`, buscarlo primero
        if preferido:
            match_pref = _coincide_modelo_instalado(preferido, instalados)
            if match_pref:
                elegido = match_pref
                motivo = "MODELO_PREFERIDO_CLIENTE"

        # 2. Buscar según la lista ordenada del perfil de hardware ('estandar', 'ligero', 'potente' o 'auto')
        if elegido is None:
            mapa_perfiles = cfg.get("modelos_por_perfil") or {}
            clave_lista = perfil if perfil in mapa_perfiles else "estandar"
            candidatos_perfil = mapa_perfiles.get(clave_lista) or _CONFIG_POR_DEFECTO["modelos_por_perfil"]["estandar"]
            for cand in candidatos_perfil:
                match_c = _coincide_modelo_instalado(cand, instalados)
                if match_c:
                    elegido = match_c
                    motivo = f"PERFIL_{clave_lista.upper()}"
                    break

        # 3. Autodetección abierta: cualquier otro VLM conocido que el cliente tenga instalado en Ollama
        if elegido is None:
            for inst in instalados:
                familia = inst.lower().split(":", 1)[0]
                if any(familia.startswith(pref) for pref in _PREFIJOS_FAMILIAS_VLM):
                    elegido = inst
                    motivo = "AUTODETECTADO_FAMILIA_VLM"
                    break

    _CACHE_MODELO_DETECTADO["url"] = base_url
    _CACHE_MODELO_DETECTADO["perfil"] = perfil
    _CACHE_MODELO_DETECTADO["preferido"] = preferido
    _CACHE_MODELO_DETECTADO["modelo"] = elegido
    _CACHE_MODELO_DETECTADO["consultado"] = True
    return elegido, motivo


def liberar_modelo_vlm_en_ollama(config=None):
    """
    Envía `keep_alive: 0` al modelo VLM usado en Ollama para liberar inmediatamente la VRAM
    de la tarjeta gráfica antes de ejecutar fases posteriores con `llama3.1`.
    """
    cfg = config if isinstance(config, dict) else cargar_configuracion_vlm()
    if not cfg.get("liberar_vram_entre_fases", True):
        return False
    modelo_activo = _CACHE_MODELO_DETECTADO.get("modelo")
    if not modelo_activo:
        return False
    try:
        _peticion_json_ollama_local(
            cfg["ollama_base_url"],
            "/api/generate",
            payload={"model": modelo_activo, "prompt": "", "keep_alive": 0},
            timeout=5,
        )
        return True
    except Exception:
        return False


def _redimensionar_png_si_excede(img_bytes, lado_maximo_px):
    """Ajusta una imagen en memoria si supera `lado_maximo_px` preservando su relación de aspecto."""
    if not img_bytes or not PILLOW_DISPONIBLE or Image is None:
        return img_bytes
    try:
        with Image.open(io.BytesIO(img_bytes)) as im:
            ancho, alto = im.size
            mayor = max(ancho, alto)
            if mayor <= lado_maximo_px:
                if im.format == "PNG":
                    return img_bytes
                buf_ok = io.BytesIO()
                im_rgb = im.convert("RGB") if im.mode not in ("RGB", "L") else im
                im_rgb.save(buf_ok, format="PNG")
                return buf_ok.getvalue()

            escala = float(lado_maximo_px) / float(mayor)
            nuevo_tam = (max(1, int(ancho * escala)), max(1, int(alto * escala)))
            reescalado = getattr(Image, "Resampling", Image).LANCZOS
            im_base = im.convert("RGB") if im.mode not in ("RGB", "L") else im
            im_redim = im_base.resize(nuevo_tam, reescalado)
            buf = io.BytesIO()
            im_redim.save(buf, format="PNG")
            return buf.getvalue()
    except Exception:
        return img_bytes


def preparar_vistas_pagina_pdf(pagina_fitz, config=None):
    """
    Genera la pareja de imágenes `Multi-Crop` a partir de una página abierta con `PyMuPDF` (`fitz`):
    1. Vista global completa a `dpi_vista_global` (100 DPI por defecto) para contexto general.
    2. Recorte de alta nitidez a `dpi_recorte_cartela` (300 DPI por defecto) sobre la zona de cartela/cajetín:
       - En formato apaisado o gran formato (> A4): cuadrante inferior derecho (`50%..100%` ancho, `58%..100%` alto).
       - En formato vertical estándar: franja inferior (`0%..100%` ancho, `68%..100%` alto).
    """
    if pagina_fitz is None:
        return []
    cfg = config if isinstance(config, dict) else cargar_configuracion_vlm()
    dpi_global = cfg.get("dpi_vista_global", 100)
    dpi_cartela = cfg.get("dpi_recorte_cartela", 300)
    max_global = cfg.get("lado_maximo_px_global", 1280)
    max_cartela = cfg.get("lado_maximo_px_cartela", 1600)

    vistas = []
    try:
        pix_global = pagina_fitz.get_pixmap(dpi=dpi_global)
        bytes_global = _redimensionar_png_si_excede(pix_global.tobytes("png"), max_global)
        if bytes_global:
            vistas.append(bytes_global)
    except Exception:
        return vistas

    # Calcular región geométrica de la cartela según orientación y tamaño de lámina
    try:
        rect = getattr(pagina_fitz, "rect", None)
        if rect is not None:
            ancho_pt = float(rect.width)
            alto_pt = float(rect.height)
            if ancho_pt > 0 and alto_pt > 0:
                es_apaisado_o_plano_grande = (ancho_pt >= alto_pt) or (max(ancho_pt, alto_pt) > 900.0)
                if es_apaisado_o_plano_grande:
                    coords_clip = (
                        rect.x0 + ancho_pt * 0.50,
                        rect.y0 + alto_pt * 0.58,
                        rect.x1,
                        rect.y1,
                    )
                else:
                    coords_clip = (
                        rect.x0,
                        rect.y0 + alto_pt * 0.68,
                        rect.x1,
                        rect.y1,
                    )
                clip_rect = (
                    fitz.Rect(*coords_clip)
                    if (fitz is not None and hasattr(fitz, "Rect"))
                    else coords_clip
                )
                pix_cartela = pagina_fitz.get_pixmap(dpi=dpi_cartela, clip=clip_rect)
                bytes_cartela = _redimensionar_png_si_excede(pix_cartela.tobytes("png"), max_cartela)
                if bytes_cartela:
                    vistas.append(bytes_cartela)
    except Exception:
        pass

    return vistas


def preparar_vistas_archivo_imagen(img_bytes, config=None):
    """
    Genera las vistas `Multi-Crop` sobre un archivo de imagen suelto (`.png`, `.jpg`, `.tif`, `.webp`):
    1. Vista global normalizada a PNG.
    2. Si la imagen tiene resolución suficiente (`>= 900 px`), recorte `1:1` nativo de la región de cartela.
    """
    if not img_bytes:
        return []
    cfg = config if isinstance(config, dict) else cargar_configuracion_vlm()
    max_global = cfg.get("lado_maximo_px_global", 1280)
    max_cartela = cfg.get("lado_maximo_px_cartela", 1600)

    if not PILLOW_DISPONIBLE or Image is None:
        return [img_bytes]

    vistas = []
    try:
        with Image.open(io.BytesIO(img_bytes)) as im:
            im_rgb = im.convert("RGB") if im.mode not in ("RGB", "L") else im
            ancho, alto = im_rgb.size

            # 1. Vista global
            buf_global = io.BytesIO()
            im_rgb.save(buf_global, format="PNG")
            vistas.append(_redimensionar_png_si_excede(buf_global.getvalue(), max_global))

            # 2. Recorte de cartela en resolución nativa cuando la imagen es suficientemente grande
            if max(ancho, alto) >= 900:
                if ancho >= alto:
                    caja = (int(ancho * 0.50), int(alto * 0.58), ancho, alto)
                else:
                    caja = (0, int(alto * 0.68), ancho, alto)
                recorte = im_rgb.crop(caja)
                buf_crop = io.BytesIO()
                recorte.save(buf_crop, format="PNG")
                vistas.append(_redimensionar_png_si_excede(buf_crop.getvalue(), max_cartela))
    except Exception:
        return [img_bytes]

    return [v for v in vistas if v]


def _parsear_json_vlm(texto_respuesta):
    """Extrae de forma tolerante el diccionario JSON devuelto por el modelo visual local."""
    if not texto_respuesta or not str(texto_respuesta).strip():
        raise ValueError("Respuesta vacía del VLM local.")
    limpio = re.sub(r"```(?:json)?", "", str(texto_respuesta), flags=re.IGNORECASE).strip()
    sin_comas = re.sub(r",\s*([\}\]])", r"\1", limpio)

    for cand in (limpio, sin_comas):
        try:
            obj = json.loads(cand)
            if isinstance(obj, dict):
                return obj
        except json.JSONDecodeError:
            pass

    decoder = json.JSONDecoder()
    for fuente in (sin_comas, limpio):
        for m in re.finditer(r"\{", fuente):
            frag = fuente[m.start():]
            try:
                obj, _ = decoder.raw_decode(frag)
                if isinstance(obj, dict):
                    return obj
            except json.JSONDecodeError:
                pass
            cierres = [c.start() for c in re.finditer(r"\}", frag)]
            for fin in cierres:
                try:
                    obj_py = ast.literal_eval(frag[: fin + 1])
                    if isinstance(obj_py, dict):
                        return obj_py
                except Exception:
                    continue

    raise ValueError("El VLM local no devolvió un bloque JSON interpretable.")


def _normalizar_resultado_vlm(datos_brutos, modelo_usado):
    """Normaliza y valida todos los campos del análisis visual devuelto por el VLM."""
    d = datos_brutos if isinstance(datos_brutos, dict) else {}
    tipo_vis = str(d.get("tipo_visual_detectado") or "OTRO_GRAFICO").strip().upper()
    es_plano_raw = d.get("es_plano_o_cartografia")
    if isinstance(es_plano_raw, bool):
        es_plano = es_plano_raw
    else:
        es_plano = any(k in tipo_vis for k in ("PLANO", "CARTOGRAF", "MAPA"))

    return {
        "vlm_aplicado": True,
        "modelo_vlm": modelo_usado,
        "es_plano_o_cartografia": es_plano,
        "tipo_visual_detectado": tipo_vis,
        "titulo_documento_o_plano": str(d.get("titulo_documento_o_plano") or "").strip(),
        "codigo_plano": str(d.get("codigo_plano") or "").strip(),
        "escala": str(d.get("escala") or "").strip(),
        "fase_tramitacion": str(d.get("fase_tramitacion") or "NO_ENCONTRADA").strip(),
        "fecha_documento": str(d.get("fecha_documento") or "NO_ENCONTRADA").strip(),
        "ambito": str(d.get("ambito") or "NO_ENCONTRADO").strip(),
        "resumen_contenido_visual": str(d.get("resumen_contenido_visual") or "").strip(),
        "texto_clave_transcrito": str(d.get("texto_clave_transcrito") or "").strip(),
    }


def formatear_analisis_vlm_a_texto(analisis):
    """Convierte el diccionario estructurado del VLM en un bloque de texto rico para indexación y clasificación."""
    if not isinstance(analisis, dict) or not analisis.get("vlm_aplicado"):
        return ""
    lineas = [
        f"[Análisis Visual VLM Local ({analisis.get('modelo_vlm', 'VLM')})]:",
        f"- Tipo visual: {analisis.get('tipo_visual_detectado', 'OTRO_GRAFICO')}",
    ]
    if analisis.get("titulo_documento_o_plano"):
        lineas.append(f"- Título en cartela/cabecera: {analisis['titulo_documento_o_plano']}")
    if analisis.get("codigo_plano"):
        lineas.append(f"- Código de plano: {analisis['codigo_plano']}")
    if analisis.get("escala"):
        lineas.append(f"- Escala: {analisis['escala']}")
    if analisis.get("ambito") and analisis.get("ambito") not in ("NO_ENCONTRADO", "NO_ENCONTRADA"):
        lineas.append(f"- Ámbito: {analisis['ambito']}")
    if analisis.get("fase_tramitacion") and analisis.get("fase_tramitacion") != "NO_ENCONTRADA":
        lineas.append(f"- Fase: {analisis['fase_tramitacion']}")
    if analisis.get("fecha_documento") and analisis.get("fecha_documento") != "NO_ENCONTRADA":
        lineas.append(f"- Fecha: {analisis['fecha_documento']}")
    if analisis.get("resumen_contenido_visual"):
        lineas.append(f"- Contenido gráfico: {analisis['resumen_contenido_visual']}")
    if analisis.get("texto_clave_transcrito"):
        lineas.append(f"- Texto clave leído: {analisis['texto_clave_transcrito']}")
    return "\n".join(lineas)


def analizar_vistas_con_vlm_local(
    lista_bytes_imagenes,
    nombre_archivo="documento",
    numero_pagina=1,
    texto_ocr_apoyo="",
    config=None,
):
    """
    Envía las vistas `Multi-Crop` (global + cartela) junto con el texto de apoyo de `RapidOCR`
    al modelo de visión local en Ollama (`POST http://127.0.0.1:11434/api/chat`).
    Si no hay modelo VLM disponible o falla la inferencia, devuelve `None` limpiamente
    sin interrumpir el flujo del sistema.
    """
    imagenes_validas = [b for b in (lista_bytes_imagenes or []) if isinstance(b, (bytes, bytearray)) and len(b) > 0]
    if not imagenes_validas:
        return None

    cfg = config if isinstance(config, dict) else cargar_configuracion_vlm()
    modelo_vlm, _ = resolver_modelo_vlm_local(cfg)
    if not modelo_vlm:
        return None

    apoyo_limpio = (texto_ocr_apoyo or "").strip()[:1200] or "(Sin texto OCR previo detectado)"
    prompt_usuario = _PROMPT_ANALISIS_VISUAL_TECNICO.format(
        nombre_archivo=os.path.basename(str(nombre_archivo or "documento")),
        numero_pagina=int(numero_pagina or 1),
        texto_ocr_apoyo=apoyo_limpio,
    )

    imagenes_b64 = [base64.b64encode(bytes(img)).decode("ascii") for img in imagenes_validas[:2]]
    payload = {
        "model": modelo_vlm,
        "stream": False,
        "format": "json",
        "options": {
            "temperature": 0,
        },
        "messages": [
            {
                "role": "user",
                "content": prompt_usuario,
                "images": imagenes_b64,
            }
        ],
    }

    try:
        respuesta_api = _peticion_json_ollama_local(
            cfg["ollama_base_url"],
            "/api/chat",
            payload=payload,
            timeout=cfg.get("timeout_segundos_vlm", 90),
        )
        mensaje = (respuesta_api or {}).get("message") or {}
        contenido = mensaje.get("content") if isinstance(mensaje, dict) else ""
        if not contenido and isinstance(respuesta_api, dict):
            contenido = respuesta_api.get("response", "")
        datos_json = _parsear_json_vlm(contenido)
        return _normalizar_resultado_vlm(datos_json, modelo_usado=modelo_vlm)
    except Exception:
        return None
