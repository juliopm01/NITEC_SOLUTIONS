"""
Módulo: lector_ocr_pdf.py (Versión Híbrida Inteligente: Texto Digital + RapidOCR + VLM Local)
================================================================================
Propósito general:
    Evolución del motor de lectura transversal para `version_vlm_local`. Combina
    tres niveles de lectura complementarios 100 % en local sin depender de la nube:

      Nivel 1 — Extracción Digital Ultrarrápida (0 ms extra de GPU):
          En páginas de memorias, normativas o anejos con texto digital limpio y
          continuo, conserva directamente la capa de texto nativo sin activar OCR ni VLM.

      Nivel 2 — Anclaje Léxico/Numérico con `RapidOCR` (ONNX en CPU):
          En páginas escaneadas, con imágenes incrustadas o planos con poco texto
          digital (`< umbral_vlm_plano`), extrae primero las cadenas exactas mediante
          `RapidOCR` para fijar cifras, fechas, escalas y códigos sin alucinaciones.

      Nivel 3 — Comprensión Visual `Multi-Crop` con VLM en Ollama (`127.0.0.1`):
          Sobre las páginas gráficas/planos clave de cada PDF (hasta
          `max_paginas_vlm_por_pdf` configurable en `config_vlm.json`), genera
          automáticamente dos vistas con `PyMuPDF`:
            * Vista general del plano a `100 DPI` (tipología visual del dibujo).
            * Recorte nítido a `300 DPI` del cajetín/cartela (esquina inferior derecha).
          Envía ambas vistas + el texto de apoyo de `RapidOCR` al LLM de visión local
          (`qwen2.5vl:7b` / `qwen2.5vl:3b` / `gemma3`), obteniendo título, código,
          escala, ámbito, fase, fecha y clasificación visual estructurada.
================================================================================
"""

import os
import threading

try:
    from pypdf import PdfReader
    PYPDF_DISPONIBLE = True
except Exception:
    PdfReader = None
    PYPDF_DISPONIBLE = False

try:
    from langchain_community.document_loaders import PyPDFLoader
    PYPDFLOADER_DISPONIBLE = True
except Exception:
    PyPDFLoader = None
    PYPDFLOADER_DISPONIBLE = False

try:
    from langchain_core.documents import Document
except Exception:
    class Document:
        """Estructura mínima compatible con `langchain_core.documents.Document`."""
        def __init__(self, page_content="", metadata=None):
            self.page_content = page_content
            self.metadata = dict(metadata) if metadata else {}

try:
    import fitz  # PyMuPDF
    PYMUPDF_DISPONIBLE = True
except Exception:
    fitz = None
    PYMUPDF_DISPONIBLE = False

try:
    from rapidocr_onnxruntime import RapidOCR as _RapidOCRClass
    RAPIDOCR_DISPONIBLE = True
except Exception:
    _RapidOCRClass = None
    RAPIDOCR_DISPONIBLE = False

from motor_vision_local import (
    analizar_vistas_con_vlm_local,
    cargar_configuracion_vlm,
    formatear_analisis_vlm_a_texto,
    preparar_vistas_archivo_imagen,
    preparar_vistas_pagina_pdf,
    resolver_modelo_vlm_local,
)

# Singleton perezoso y thread-safe de RapidOCR
_MOTOR_OCR = None
_LOCK_OCR = threading.Lock()

# Umbral de caracteres por debajo del cual una página CON elementos gráficos/planos
# se considera lámina gráfica con rótulos dispersos (cotas/calles) y activa lectura visual VLM
_UMBRAL_TEXTO_DISPERSO_EN_PLANO = 180


def _obtener_motor_ocr():
    """Inicializa RapidOCR bajo demanda de forma segura para hilos y tolerante a fallos de DLL/ONNX."""
    global _MOTOR_OCR, RAPIDOCR_DISPONIBLE
    if _MOTOR_OCR is not None:
        return _MOTOR_OCR
    if not RAPIDOCR_DISPONIBLE or _RapidOCRClass is None:
        return None
    with _LOCK_OCR:
        if _MOTOR_OCR is not None:
            return _MOTOR_OCR
        try:
            _MOTOR_OCR = _RapidOCRClass()
            return _MOTOR_OCR
        except Exception:
            RAPIDOCR_DISPONIBLE = False
            _MOTOR_OCR = None
            return None


def _ejecutar_ocr_sobre_bytes_imagen(img_bytes):
    """Ejecuta RapidOCR sobre los bytes de una imagen y devuelve el texto reconocido."""
    if not img_bytes or not RAPIDOCR_DISPONIBLE:
        return ""
    motor = _obtener_motor_ocr()
    if motor is None:
        return ""
    try:
        salida = motor(img_bytes)
        resultado = salida[0] if isinstance(salida, tuple) and len(salida) > 0 else salida
        if not resultado or not isinstance(resultado, (list, tuple)):
            return ""
        lineas = []
        for item in resultado:
            if isinstance(item, (list, tuple)) and len(item) > 1 and item[1] is not None:
                texto_linea = str(item[1]).strip()
                if texto_linea:
                    lineas.append(texto_linea)
        return "\n".join(lineas)
    except Exception:
        return ""


def _extraer_imagenes_brutas_pypdf(page_pypdf):
    """Extrae los bloques binarios de imágenes incrustadas en una página `pypdf` cuando `PyMuPDF` no está disponible."""
    bloques = []
    if page_pypdf is None:
        return bloques
    try:
        imagenes_pypdf = getattr(page_pypdf, "images", None) or []
        for imagen_obj in imagenes_pypdf:
            datos_img = getattr(imagen_obj, "data", None)
            if datos_img:
                bloques.append(datos_img)
    except Exception:
        pass
    return bloques


def _extraer_texto_ocr_pagina(ruta_pdf, indice_pagina, page_pypdf=None, doc_fitz=None):
    """
    Extrae el texto contenido en las imágenes de una página PDF mediante `RapidOCR`:
    1. Con `PyMuPDF` (`fitz`): extrae imágenes por `xref` o rasteriza la página a 150 DPI si es un plano vectorial.
    2. Con `pypdf`: extrae `page.images` como respaldo.
    """
    textos_ocr = []

    if PYMUPDF_DISPONIBLE and RAPIDOCR_DISPONIBLE and fitz is not None:
        cerrar_al_salir = False
        doc_activo = doc_fitz
        try:
            if doc_activo is None:
                doc_activo = fitz.open(ruta_pdf)
                cerrar_al_salir = True

            if 0 <= indice_pagina < len(doc_activo):
                pagina_fitz = doc_activo[indice_pagina]
                try:
                    lista_imagenes = pagina_fitz.get_images(full=True) or []
                except Exception:
                    lista_imagenes = []

                xrefs_vistos = set()
                for img_info in lista_imagenes:
                    if not img_info:
                        continue
                    xref = img_info[0]
                    if xref in xrefs_vistos:
                        continue
                    xrefs_vistos.add(xref)
                    try:
                        base_img = doc_activo.extract_image(xref)
                        if isinstance(base_img, dict) and base_img.get("image"):
                            txt = _ejecutar_ocr_sobre_bytes_imagen(base_img["image"])
                            if txt:
                                textos_ocr.append(txt)
                    except Exception:
                        continue

                if not textos_ocr:
                    try:
                        pix = pagina_fitz.get_pixmap(dpi=150)
                        txt_render = _ejecutar_ocr_sobre_bytes_imagen(pix.tobytes("png"))
                        if txt_render:
                            textos_ocr.append(txt_render)
                    except Exception:
                        pass
        except Exception:
            pass
        finally:
            if cerrar_al_salir and doc_activo is not None:
                try:
                    doc_activo.close()
                except Exception:
                    pass

    if not textos_ocr and RAPIDOCR_DISPONIBLE and page_pypdf is not None:
        for datos_img in _extraer_imagenes_brutas_pypdf(page_pypdf):
            txt = _ejecutar_ocr_sobre_bytes_imagen(datos_img)
            if txt:
                textos_ocr.append(txt)

    return "\n".join(textos_ocr).strip()


def _detectar_objetos_imagen_pypdf(page_pypdf):
    """Detecta objetos de imagen o recursos gráficos `/XObject` en una página `pypdf`."""
    if page_pypdf is None:
        return False
    try:
        imagenes = getattr(page_pypdf, "images", None)
        if imagenes and len(imagenes) > 0:
            return True
    except Exception:
        pass
    try:
        recursos = page_pypdf.get("/Resources", {})
        if hasattr(recursos, "get_object"):
            recursos = recursos.get_object()
        xobj = recursos.get("/XObject", {}) if isinstance(recursos, dict) else {}
        if hasattr(xobj, "get_object"):
            xobj = xobj.get_object()
        return bool(xobj)
    except Exception:
        return False


def _detectar_objetos_graficos_fitz(doc_fitz, indice_pagina):
    """Detecta imágenes rasterizadas o geometría vectorial CAD (`get_drawings`) en `PyMuPDF`."""
    if doc_fitz is None:
        return False
    try:
        if 0 <= indice_pagina < len(doc_fitz):
            pag = doc_fitz[indice_pagina]
            if pag.get_images(full=True):
                return True
            if hasattr(pag, "get_drawings") and pag.get_drawings():
                return True
    except Exception:
        pass
    return False


def cargar_pdf_con_ocr(
    ruta_completa,
    incluir_cabecera_documento=True,
    umbral_minimo_caracteres=25,
    usar_vlm=True,
    config_vlm=None,
):
    """
    Carga todas las páginas de un PDF mediante el Enrutador Híbrido Inteligente:
    - Páginas con texto digital continuo (ej. Memorias, Normativa): lectura digital directa.
    - Páginas escaneadas, portadas gráficas o planos CAD/raster con texto insuficiente:
      ejecuta `RapidOCR` + análisis visual `Multi-Crop` (100 DPI global + 300 DPI cartela)
      sobre el modelo VLM local en Ollama (si `usar_vlm=True` y hay VLM instalado).
    """
    if ruta_completa is None or isinstance(ruta_completa, bool) or not isinstance(ruta_completa, (str, os.PathLike)):
        raise ValueError("La ruta del archivo PDF no puede ser nula.")

    ruta_limpia = str(ruta_completa).strip().strip('"').strip("'")
    if not ruta_limpia:
        raise ValueError("La ruta del archivo PDF está vacía.")
    if not os.path.isfile(ruta_limpia):
        raise FileNotFoundError(f"El archivo PDF no existe: {ruta_limpia}")
    if os.path.getsize(ruta_limpia) == 0:
        raise ValueError(f"El archivo PDF está vacío (0 bytes): {ruta_limpia}")

    if umbral_minimo_caracteres is None or isinstance(umbral_minimo_caracteres, bool):
        umbral_efectivo = 25
    else:
        try:
            umbral_efectivo = max(0, int(umbral_minimo_caracteres))
        except (TypeError, ValueError):
            umbral_efectivo = 25

    hay_algun_motor = (
        (PYPDFLOADER_DISPONIBLE and PyPDFLoader is not None)
        or (PYPDF_DISPONIBLE and PdfReader is not None)
        or (PYMUPDF_DISPONIBLE and fitz is not None)
    )
    if not hay_algun_motor:
        raise RuntimeError("No hay ningún motor lector de PDF disponible (instala pypdf o pymupdf).")

    cfg_vlm = config_vlm if isinstance(config_vlm, dict) else (cargar_configuracion_vlm() if usar_vlm else None)
    modelo_vlm_disponible = None
    max_pags_vlm = 0
    if usar_vlm and cfg_vlm is not None:
        modelo_vlm_disponible, _ = resolver_modelo_vlm_local(cfg_vlm)
        max_pags_vlm = int(cfg_vlm.get("max_paginas_vlm_por_pdf", 4))

    nombre_archivo = os.path.basename(ruta_limpia)
    paginas_resultado = []
    errores_lectura = []

    # 1. Carga base con PyPDFLoader
    paginas_base = []
    if PYPDFLOADER_DISPONIBLE and PyPDFLoader is not None:
        try:
            cargador = PyPDFLoader(ruta_limpia)
            paginas_base = cargador.load() or []
        except Exception as e:
            errores_lectura.append(f"PyPDFLoader: {e}")

    # 2. Lector pypdf crudo (incluye desbloqueo de PDFs visados con contraseña vacía)
    lector_raw = None
    paginas_raw = []
    if PYPDF_DISPONIBLE and PdfReader is not None:
        try:
            lector_raw = PdfReader(ruta_limpia)
            if getattr(lector_raw, "is_encrypted", False):
                try:
                    lector_raw.decrypt("")
                except Exception:
                    pass
            if getattr(lector_raw, "is_encrypted", False):
                errores_lectura.append("PdfReader: El PDF está protegido con contraseña")
                lector_raw = None
            else:
                paginas_raw = list(lector_raw.pages)
        except Exception as e:
            errores_lectura.append(f"PdfReader: {e}")
            lector_raw = None

    # 3. Apertura única de PyMuPDF (fitz) para todo el documento
    doc_fitz = None
    if PYMUPDF_DISPONIBLE and fitz is not None:
        try:
            doc_fitz = fitz.open(ruta_limpia)
            if getattr(doc_fitz, "needs_pass", False):
                autenticado = False
                try:
                    autenticado = bool(doc_fitz.authenticate(""))
                except Exception:
                    autenticado = False
                if not autenticado:
                    errores_lectura.append("PyMuPDF: El PDF está protegido con contraseña")
                    doc_fitz.close()
                    doc_fitz = None
        except Exception as e:
            errores_lectura.append(f"PyMuPDF: {e}")
            doc_fitz = None

    paginas_vlm_consumidas = 0

    try:
        len_fitz = len(doc_fitz) if doc_fitz is not None else 0
        total_paginas = max(len(paginas_base), len(paginas_raw), len_fitz)

        if total_paginas == 0 and errores_lectura:
            raise ValueError(f"No se pudo leer el PDF '{nombre_archivo}': {'; '.join(errores_lectura)}")

        mapa_paginas_base = {}
        if len(paginas_base) == total_paginas:
            mapa_paginas_base = {i: paginas_base[i] for i in range(total_paginas)}
        else:
            for i_doc, doc_b in enumerate(paginas_base):
                meta_b = getattr(doc_b, "metadata", None) or {}
                pag_idx = meta_b.get("page", i_doc)
                if isinstance(pag_idx, int) and 0 <= pag_idx < total_paginas and pag_idx not in mapa_paginas_base:
                    mapa_paginas_base[pag_idx] = doc_b

        for idx in range(total_paginas):
            texto_nativo = ""
            meta_base = {}
            page_pypdf = paginas_raw[idx] if idx < len(paginas_raw) else None

            if idx in mapa_paginas_base:
                doc_b = mapa_paginas_base[idx]
                texto_nativo = (doc_b.page_content or "").strip()
                meta_base = dict(doc_b.metadata or {})

            if not texto_nativo and page_pypdf is not None:
                try:
                    texto_nativo = (page_pypdf.extract_text() or "").strip()
                except Exception:
                    texto_nativo = ""

            if not texto_nativo and doc_fitz is not None and idx < len_fitz:
                try:
                    texto_nativo = (doc_fitz[idx].get_text("text") or "").strip()
                except Exception:
                    texto_nativo = ""

            tiene_imagenes = (
                _detectar_objetos_imagen_pypdf(page_pypdf)
                or _detectar_objetos_graficos_fitz(doc_fitz, idx)
            )

            # ENRUTADOR HÍBRIDO:
            # - `requiere_ocr`: texto nativo muy escaso (< umbral_efectivo).
            # - `requiere_vlm`: página gráfica/plano con texto nativo escaso o disperso (< 180 chars)
            #   donde la estructura visual y la cartela aportan información decisiva.
            requiere_ocr = len(texto_nativo) < umbral_efectivo
            es_candidata_visual = (tiene_imagenes and len(texto_nativo) < _UMBRAL_TEXTO_DISPERSO_EN_PLANO) or (
                len(texto_nativo) < umbral_efectivo and (tiene_imagenes or doc_fitz is not None or page_pypdf is not None)
            )

            texto_ocr = ""
            if (requiere_ocr or es_candidata_visual) and RAPIDOCR_DISPONIBLE and (
                tiene_imagenes or PYMUPDF_DISPONIBLE or page_pypdf is not None
            ):
                texto_ocr = _extraer_texto_ocr_pagina(
                    ruta_limpia, idx, page_pypdf=page_pypdf, doc_fitz=doc_fitz
                )

            # Fase VLM Local con Doble Vista Multi-Crop (respetando el presupuesto de páginas por PDF)
            analisis_vlm = None
            puede_usar_vlm_en_pagina = (
                usar_vlm
                and bool(modelo_vlm_disponible)
                and es_candidata_visual
                and (max_pags_vlm == 0 or paginas_vlm_consumidas < max_pags_vlm)
            )
            if puede_usar_vlm_en_pagina:
                vistas_pagina = []
                if doc_fitz is not None and idx < len_fitz:
                    vistas_pagina = preparar_vistas_pagina_pdf(doc_fitz[idx], config=cfg_vlm)
                elif page_pypdf is not None:
                    imgs_brutas = _extraer_imagenes_brutas_pypdf(page_pypdf)
                    if imgs_brutas:
                        vistas_pagina = preparar_vistas_archivo_imagen(imgs_brutas[0], config=cfg_vlm)

                if vistas_pagina:
                    apoyo_ocr_y_nativo = "\n".join(x for x in (texto_nativo, texto_ocr) if x).strip()
                    analisis_vlm = analizar_vistas_con_vlm_local(
                        vistas_pagina,
                        nombre_archivo=nombre_archivo,
                        numero_pagina=idx + 1,
                        texto_ocr_apoyo=apoyo_ocr_y_nativo,
                        config=cfg_vlm,
                    )
                    if analisis_vlm and analisis_vlm.get("vlm_aplicado"):
                        paginas_vlm_consumidas += 1

            texto_vlm = formatear_analisis_vlm_a_texto(analisis_vlm) if analisis_vlm else ""

            bloques_pagina = []
            if texto_nativo:
                bloques_pagina.append(texto_nativo)
            if texto_vlm:
                bloques_pagina.append(texto_vlm)
            if texto_ocr:
                bloques_pagina.append(f"[Texto extraído de imagen (OCR)]:\n{texto_ocr}")

            texto_combinado = "\n".join(bloques_pagina).strip()

            meta_base["source"] = ruta_limpia
            meta_base["archivo_origen"] = nombre_archivo
            meta_base["page"] = idx + 1
            meta_base["contiene_imagenes"] = bool(tiene_imagenes or texto_ocr or texto_vlm)
            meta_base["ocr_aplicado"] = bool(texto_ocr)
            meta_base["vlm_aplicado"] = bool(analisis_vlm and analisis_vlm.get("vlm_aplicado"))
            if analisis_vlm:
                meta_base["analisis_vlm"] = analisis_vlm

            if texto_combinado:
                contenido_final = (
                    f"[Documento: {nombre_archivo} | Página {idx + 1}]\n{texto_combinado}"
                    if incluir_cabecera_documento else texto_combinado
                )
                paginas_resultado.append(Document(page_content=contenido_final, metadata=meta_base))
            elif tiene_imagenes or idx == 0:
                descripcion_grafica = (
                    f"[Documento: {nombre_archivo} | Página {idx + 1} | CONTENIDO GRÁFICO / PLANO / IMAGEN]\n"
                    f"Archivo PDF con contenido gráfico o plano sin texto adicional. "
                    f"Nombre de archivo para clasificación: {nombre_archivo}."
                )
                paginas_resultado.append(Document(page_content=descripcion_grafica, metadata=meta_base))
    finally:
        if doc_fitz is not None:
            try:
                doc_fitz.close()
            except Exception:
                pass

    return paginas_resultado
