"""
================================================================================
Lanzador Central - Sistema Multi-Agente NITEC
================================================================================
Punto de entrada general para seleccionar y ejecutar cualquiera de las dos
versiones del sistema de empaquetado y cumplimiento normativo urbanístico:

  [1] Versión 1: Pipeline Clásico OCR (RapidOCR + PyMuPDF + Ollama Llama 3.1)
  [2] Versión 2: Pipeline Multimodal VLM (Qwen2-VL / Llama-3.2-Vision Local)

Uso interactivo:
    python lanzador.py

Uso directo por línea de comandos:
    python lanzador.py 1       (o python lanzador.py --v1)
    python lanzador.py 2       (o python lanzador.py --v2)
    python lanzador.py docs    (abre resumen de documentación)
================================================================================
"""

import os
import sys
import subprocess

DIRECTORIO_RAIZ = os.path.dirname(os.path.abspath(__file__))
RUTA_V1_CODIGO = os.path.join(DIRECTORIO_RAIZ, "version_1_ocr", "codigo")
RUTA_V2_CODIGO = os.path.join(DIRECTORIO_RAIZ, "version_2_vlm", "codigo")
RUTA_V1_DOCS = os.path.join(DIRECTORIO_RAIZ, "version_1_ocr", "documentacion")
RUTA_V2_DOCS = os.path.join(DIRECTORIO_RAIZ, "version_2_vlm", "documentacion")
RUTA_COMP_DOCS = os.path.join(DIRECTORIO_RAIZ, "estudios_comparativos")
RUTA_COMERCIAL = os.path.join(DIRECTORIO_RAIZ, "material_comercial")


def _imprimir(msg=""):
    """Imprime de forma segura en consolas Windows cp1252 o UTF-8."""
    try:
        print(msg)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        print(str(msg).encode(enc, errors="replace").decode(enc, errors="replace"))


def ejecutar_version(numero_version, args_extra=None):
    """Ejecuta el script main.py de la versión seleccionada configurando el entorno de trabajo."""
    if args_extra is None:
        args_extra = []

    if numero_version == 1:
        directorio_trabajo = RUTA_V1_CODIGO
        nombre = "Versión 1 (RapidOCR + PyMuPDF + Ollama Llama 3.1)"
    elif numero_version == 2:
        directorio_trabajo = RUTA_V2_CODIGO
        nombre = "Versión 2 (VLM Multimodal Local + RapidOCR + Ollama)"
    else:
        _imprimir(f"[ERROR] Versión no válida: {numero_version}")
        return 1

    script_main = os.path.join(directorio_trabajo, "main.py")
    if not os.path.exists(script_main):
        _imprimir(f"[ERROR] No se localizó el script principal en: {script_main}")
        return 1

    _imprimir("\n" + "=" * 80)
    _imprimir(f"  INICIANDO {nombre.upper()}")
    _imprimir(f"  Directorio de ejecución: {directorio_trabajo}")
    _imprimir("=" * 80 + "\n")

    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"

    cmd = [sys.executable, "-B", "main.py"] + args_extra

    try:
        res = subprocess.run(cmd, cwd=directorio_trabajo, env=env)
        return res.returncode
    except KeyboardInterrupt:
        _imprimir("\n[INFO] Ejecución cancelada por el usuario.")
        return 0
    except Exception as e:
        _imprimir(f"\n[ERROR] Fallo al ejecutar el subproceso: {e}")
        return 1


def mostrar_resumen_documentacion():
    """Muestra la estructura y ubicación de todos los documentos disponibles."""
    _imprimir("\n" + "=" * 80)
    _imprimir("              CATÁLOGO DE DOCUMENTACIÓN Y ESTUDIOS DEL SISTEMA")
    _imprimir("=" * 80)
    _imprimir("\n[1] VERSIÓN 1 (OCR Clásico) -> Carpeta: version_1_ocr/documentacion/")
    _imprimir("    - GUIA_INSTALACION_Y_REQUISITOS.md : Instalación paso a paso de Ollama y dependencias.")
    _imprimir("    - INFORME_TECNICO_SISTEMA.md       : Explicación detallada de cada agente y función.")
    _imprimir("    - Informe Técnico NITEC.pdf         : Memoria técnica formal en PDF.")
    _imprimir("    - REQUISITOS_HARDWARE.md / .pdf    : Especificaciones de GPU, VRAM, CPU y RAM mín/rec.")
    _imprimir("    - REQUISITOS_COMPUTACIONALES_Y_CONSUMO_ENERGETICO.md / .xlsx : Consumo en W, kWh y €.")

    _imprimir("\n[2] VERSIÓN 2 (VLM Multimodal) -> Carpeta: version_2_vlm/documentacion/")
    _imprimir("    - GUIA_VLM_LOCAL.md                : Configuración del motor multimodal Qwen2-VL.")
    _imprimir("    - Guía de Uso VLM NITEC.pdf        : Guía técnica completa en PDF.")
    _imprimir("    - REQUISITOS_HARDWARE.md / .pdf    : Requisitos de aceleración gráfica para visión.")
    _imprimir("    - REQUISITOS_COMPUTACIONALES_Y_CONSUMO_ENERGETICO.md / .xlsx : Análisis de inferencia.")

    _imprimir("\n[3] ESTUDIOS COMPARATIVOS -> Carpeta: estudios_comparativos/")
    _imprimir("    - consumo_computacional_modelos_hardware.xlsx : Comparativa V1 vs V2 entre 4 perfiles.")
    _imprimir("    - consumo_energetico_costes_electricos.xlsx   : Costes anuales según tarifa eléctrica.")

    _imprimir("\n[4] MATERIAL COMERCIAL Y WEB -> Carpeta: material_comercial/")
    _imprimir("    - presentacion_comercial_nitec.html   : Pitch deck comercial + Simulador total BOJA.")
    _imprimir("    - web_alternativa_nitecsolutions.html : Web corporativa ingeniería (sin hype de IA).")
    _imprimir("    - mockup_sistema_nitec.html           : Panel de control de escritorio interactivo.")
    _imprimir("    - infografias/                        : Esquemas visuales del flujo multi-agente.")
    _imprimir("    - logos/                              : Identidad de marca oficial (Nitec ONE / NITEC Solutions).")
    _imprimir("=" * 80)


def abrir_presentacion_comercial():
    """Abre la presentación comercial interactiva en el navegador predeterminado."""
    ruta_html = os.path.join(RUTA_COMERCIAL, "presentacion_comercial_nitec.html")
    if os.path.exists(ruta_html):
        _imprimir(f"\n[+] Abriendo presentación comercial interactiva en tu navegador...")
        _imprimir(f"    Ruta: {ruta_html}")
        try:
            import webbrowser
            webbrowser.open(f"file:///{ruta_html.replace(os.sep, '/')}")
        except Exception as e:
            _imprimir(f"[!] No se pudo abrir automáticamente el navegador: {e}")
            _imprimir(f"    Puedes abrir el archivo directamente en: {ruta_html}")
    else:
        _imprimir(f"[ERROR] No se encontró el archivo de presentación en: {ruta_html}")


def menu_interactivo():
    """Menú interactivo de selección en terminal."""
    while True:
        _imprimir("\n" + "=" * 80)
        _imprimir("       SISTEMA MULTI-AGENTE NITEC - GESTIÓN Y REORGANIZACIÓN URBANÍSTICA")
        _imprimir("=" * 80)
        _imprimir("  Seleccione la versión o acción a realizar:")
        _imprimir("")
        _imprimir("  [1] Ejecutar Versión 1: Pipeline Clásico OCR")
        _imprimir("      (RapidOCR + PyMuPDF + Ollama Llama 3.1 - Ligero y optimizado)")
        _imprimir("")
        _imprimir("  [2] Ejecutar Versión 2: Pipeline Multimodal VLM")
        _imprimir("      (Visión Multimodal Local Qwen2-VL / Llama-3.2-Vision - Máxima precisión visual)")
        _imprimir("")
        _imprimir("  [3] Consultar Catálogo de Documentación y Estudios")
        _imprimir("  [4] Abrir Presentación Comercial Interactiva (Nitec ONE)")
        _imprimir("  [0] Salir")
        _imprimir("=" * 80)

        try:
            opcion = input("Ingrese opción [1, 2, 3, 4 o 0]: ").strip()
        except (EOFError, KeyboardInterrupt):
            _imprimir("\nSaliendo...")
            break

        if opcion == "1":
            ejecutar_version(1)
            break
        elif opcion == "2":
            ejecutar_version(2)
            break
        elif opcion == "3":
            mostrar_resumen_documentacion()
            try:
                input("\nPresione Enter para volver al menú...")
            except (EOFError, KeyboardInterrupt):
                break
        elif opcion == "4":
            abrir_presentacion_comercial()
            try:
                input("\nPresione Enter para volver al menú...")
            except (EOFError, KeyboardInterrupt):
                break
        elif opcion in ("0", "salir", "exit", "q"):
            _imprimir("Operación finalizada.")
            break
        else:
            _imprimir("[!] Opción no reconocida. Por favor, ingrese 1, 2, 3, 4 o 0.")


def main():
    if len(sys.argv) > 1:
        arg = sys.argv[1].lower().strip("-")
        args_extra = sys.argv[2:]
        if arg in ("1", "v1", "ocr"):
            sys.exit(ejecutar_version(1, args_extra))
        elif arg in ("2", "v2", "vlm"):
            sys.exit(ejecutar_version(2, args_extra))
        elif arg in ("3", "docs", "doc", "documentacion", "help", "h"):
            mostrar_resumen_documentacion()
            sys.exit(0)
        elif arg in ("4", "demo", "comercial", "web", "pitch"):
            abrir_presentacion_comercial()
            sys.exit(0)
        else:
            _imprimir(f"[!] Argumento desconocido '{sys.argv[1]}'. Lanzando menú interactivo...")
            menu_interactivo()
    else:
        menu_interactivo()


if __name__ == "__main__":
    main()
