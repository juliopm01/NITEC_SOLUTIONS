# 📘 Informe Técnico Integral del Sistema Multi-Agente NITEC (`sistema_nitec_ocr_v1`)

Este documento detalla la arquitectura completa, el flujo de datos y el funcionamiento exacto de **cada archivo y función** que compone el sistema de lectura OCR, auditoría normativa y empaquetado automatizado de proyectos de arquitectura, ingeniería y urbanismo.

> **Principio de Cero Hardcoding Normativo**: Ningún módulo tiene pregrabadas carpetas ni tablas del BOJA. Toda la organización documental se descubre dinámicamente del PDF regulatorio autonómico en su primera lectura y queda persistida localmente para futuras ejecuciones.

---

## 1. Arquitectura General y Flujo de Datos

1. **[`main.py`](./main.py) (Orquestador Principal)**: solicita los datos básicos del proyecto, resuelve automáticamente la geografía e INE con [`geo_localizador.py`](./geo_localizador.py), sincroniza las bases vectoriales ([`creador_base_datos.py`](./creador_base_datos.py) y [`creador_base_vectores.py`](./creador_base_vectores.py)) y coordina los 3 agentes.
2. **[`lector_ocr_pdf.py`](./lector_ocr_pdf.py) (Motor Transversal PDF + OCR)**: extrae texto digital nativo y aplica OCR selectivo (`RapidOCR` + `PyMuPDF`/`pypdf`) sobre imágenes incrustadas, planos escaneados y planos vectoriales CAD.
3. **[`agente_1_extractor.py`](./agente_1_extractor.py) (Agente 1 — Documentalista y Clasificador)**: extrae metadatos legales (`FT`, `AAAAMMDD`, `AMB`), inspecciona cada archivo del proyecto (PDFs, imágenes `.png`/`.jpg`/`.tif` con OCR, capas SIG `.gpkg`/`.shp`, CAD `.dwg`/`.dxf` y metadatos `.txt`/`.xml`) y genera `especificaciones_agente_1.json` para el Agente 3.
4. **[`agente_2_normativo_local.py`](./agente_2_normativo_local.py) (Agente 2 — Auditor Normativo)**: lee al completo una única vez el boletín autonómico guardándolo en `boja_base.json` y almacena permanentemente los límites de peso en MB de cada ayuntamiento en `normativas_ayuntamientos.json`.
5. **[`agente_3_procesador.py`](./agente_3_procesador.py) (Agente 3 — Compresor, Fragmentador y Empaquetador)**: comprime los PDFs al 100 % sin pérdida de calidad en imágenes, divide por peso solo los archivos que sigan superando el límite municipal y genera la carpeta final `<CODIGO_RAIZ>/` con la estructura y codificación exacta del BOJA.

---

## 2. Desglose Exacto Archivo por Archivo

### 2.1. `main.py` — Orquestador Principal
* **Constantes**: `DIRECTORIO_BASE`, `RUTA_BOJA_JSON`, `CARPETA_NORMATIVAS_PDF`, `RUTA_BD_NORMATIVAS` y `_CARPETAS_EXCLUIDAS` (anclan rutas al directorio del código e impiden re-ingerir carpetas internas o entregas previas).
* **Utilidades seguras**: `_imprimir` e `_input_consola_seguro` evitan errores `UnicodeEncodeError` en terminales Windows `cp1252`; `_limpiar_ruta`, `_normalizar`, `_leer_input_seguro`, `_pedir_texto_no_vacio` y `_extraer_entero_positivo_usuario` validan todas las entradas de consola.
* **Gestión de bases vectoriales y autodetección**: `_autodetectar_pdf_principal` localiza el PDF principal si el usuario pulsa Enter; `_bd_legal_actualizada`, `_actualizar_bd_legal` y `comprobar_y_crear_bases_datos` actualizan `./bd_normativas` solo cuando hay PDFs nuevos/modificados (`mtime`) y reconstruyen `./bd_vectores` en UTF-8.
* **`main()`**: ejecuta de principio a fin la resolución geográfica/INE, Agente 1 (carátula), Agente 2 (BOJA + límite municipal), Agente 1 (clasificación completa en JSON) y Agente 3 (empaquetado normativo).

### 2.2. `geo_localizador.py` — Geolocalización y Código INE Oficial
* **Catálogos**: `_DATOS_BASE_MUNICIPIOS` (provincia y comunidad autónoma), `_CODIGOS_INE_OFICIALES` (códigos INE oficiales de 5 dígitos como `29067` Málaga, `29069` Marbella, `29042` Coín, `41091` Sevilla, `11020` Jerez, etc.) y `_PREFIJOS_INE_PROVINCIA` (`01`..`52`).
* **Funciones**:
  * `_normalizar`, `_es_codigo_ine_valido`, `_es_registro_valido`: validaciones y normalización sin tildes ni guiones.
  * `cargar_base_datos` y `obtener_datos_geograficos`: consultas puras de lectura sin efectos secundarios en disco.
  * `registrar_municipio` y `registrar_codigo_ine`: guardado atómico (`_guardar_json_atomico`) en `municipios_espana.json`.
  * `obtener_codigo_ine`: devuelve el código INE de 5 dígitos priorizando personalizados -> catálogo oficial -> prefijo provincial `PP000` -> `'00000'`.

### 2.3. `lector_ocr_pdf.py` — Motor Híbrido de Lectura PDF y OCR de Imágenes
* `_obtener_motor_ocr` y `_ejecutar_ocr_sobre_bytes_imagen`: inicializan `RapidOCR` una única vez de forma *thread-safe* y reconocen texto sobre cualquier imagen en memoria.
* `_extraer_texto_ocr_pagina`: extrae imágenes incrustadas deduplicando `xref` mediante `PyMuPDF` (`fitz`), o rasteriza la página completa a `150 DPI` cuando se trata de un plano vectorial o escaneado sin texto digital, con respaldo en `page.images` de `pypdf`.
* `_detectar_objetos_imagen_pypdf` y `_detectar_objetos_graficos_fitz`: detectan recursos gráficos `/XObject`, mapas de bits y dibujos CAD (`get_drawings`).
* `cargar_pdf_con_ocr`: abre el PDF una sola vez cerrando siempre sus descriptores, desbloquea documentos firmados con clave vacía (`""`), activa OCR selectivamente cuando el texto digital es menor de 25 caracteres y conserva huella gráfica en planos sin texto.

### 2.4. `creador_base_datos.py` — Archivador Vectorial Legal (`./bd_normativas`)
* `detectar_municipio_en_nombre` y `_limpiar_tokens_municipio`: distinguen boletines autonómicos (`'general'`) frente a ordenanzas locales (`'malaga'`, `'velez_malaga'`, `'coin'`).
* `procesar_pdf`: lee cada normativa con OCR en paralelo (`ThreadPoolExecutor`).
* `ingestar_normativas`: fragmenta los textos (`chunk_size=1000`, `chunk_overlap=200`) y actualiza ChromaDB de forma transaccional con respaldo `_backup_tmp` y restauración automática ante fallos.

### 2.5. `creador_base_vectores.py` — Indexador Vectorial del Proyecto (`./bd_vectores`)
* `_descubrir_pdfs_proyecto`: recorre el proyecto excluyendo carpetas internas y partes ya divididas (`_parte_`, `_tomo_`).
* `limpiar_bd_anterior`: gestiona bloqueos de archivos SQLite/HNSW en Windows.
* `ingestar_proyecto`: extrae texto + OCR de todos los PDFs del proyecto, sella cada fragmento con `carpeta_proyecto` y reconstruye `./bd_vectores` transaccionalmente.

### 2.6. `agente_1_extractor.py` — Agente 1 (Lectura Multiformato, OCR y Clasificación en JSON)
* **Extracción de metadatos legales**: `buscar_fusion_hibrida`, `_bd_corresponde_a_proyecto`, `extraer_metadatos`, `_sanitizar_fase`, `_validar_fecha_calendario`, `_sanitizar_fecha`, `_sanitizar_ambito` e `_inferir_ambito_proyecto` obtienen `FT`, `AAAAMMDD` y `AMB` validados.
* **Inspección de archivos e imágenes**: `inspeccionar_archivo_proyecto` y `_detectar_si_es_plano` leen PDFs, imágenes sueltas (`.png`, `.jpg`, `.tif`), capas SIG (`.gpkg`, `.shp`), CAD (`.dxf`, `.dwg`) y metadatos (`.txt`, `.xml`).
* **Clasificación dinámica y entrega JSON**: `_detectar_categoria_tecnica`, `_es_slot_compatible_con_archivo`, `_puntuar_slot_dinamico`, `_clasificar_lote_con_llm`, `clasificar_archivos_proyecto` y `ejecutar_agente_1` asignan cada archivo a su destino normativo y guardan atómicamente `especificaciones_agente_1.json`.

### 2.7. `agente_2_normativo_local.py` — Agente 2 (Normativa BOJA y Límites Municipales)
* **Lectura integral del boletín**: `analizar_documento_completo_y_extraer_normativa` escanea todo el PDF en bloques con contexto deslizante de 12 líneas, limpia erratas de maquetación (`_limpiar_plantilla_codigo`), unifica carpetas (`_fusionar_estructuras_carpetas`) y guarda `boja_base.json` (`extraer_boja_de_local`).
* **Catálogo dinámico**: `construir_catalogo_documental` traduce cualquier `estructura_carpetas` en destinos normalizados sin depender de tablas fijas.
* **Persistencia por ayuntamiento**: `guardar_normativa_ayuntamiento`, `obtener_limite_guardado_ayuntamiento`, `consultar_normativa_local`, `contrastar_excepciones` y `ejecutar_agente_2` guardan los límites locales en `normativas_ayuntamientos.json` y aplican `min(limite_boja, limite_ayuntamiento)`.

### 2.8. `agente_3_procesador.py` — Agente 3 (Compresión Sin Pérdida, Fragmentación y Empaquetado)
* `comprimir_pdf_sin_perdida`: comprime flujos y referencias XRef mediante `PyMuPDF` y `pypdf` sin pérdida alguna de calidad ni resolución en imágenes/planos.
* `dividir_pdf_por_peso` y `_formatear_sufijo_division`: fragmentan PDFs pesados mediante búsqueda exponencial + binaria respetando `limite_mb` y numerando con el patrón oficial (`09_99`).
* `construir_nombre_normativo`, `_aplicar_indice_seriado`, `_materializar_arbol_carpetas_normativo`, `empaquetar_proyecto_completo` y `ejecutar_agente_3`: crean toda la estructura de carpetas del BOJA, comprimen antes de cortar, numeran series de planos y anexos (`AN01`, `AN02`), mantienen juntos los archivos acompañantes de Shapefile y emiten `<CODIGO_RAIZ>_informe_empaquetado.json`.

### 2.9. `requirements.txt` y `GUIA_INSTALACION_Y_REQUISITOS.md`
* Definen las librerías necesarias (`langchain*`, `chromadb`, `pypdf`, `rank-bm25`, `pymupdf`, `rapidocr-onnxruntime`, `pillow`) y las instrucciones de instalación junto a Ollama (`llama3.1` y `nomic-embed-text`).

---

## 3. Viabilidad de una Versión Alterna (`v2`) con LLM Multimodal de Visión (VLM)

Crear una variante (`sistema_nitec_vlm_v2`) apoyada en un **LLM Multimodal de Visión (VLM)** es **altamente viable y muy recomendable** bajo una arquitectura híbrida:
* **Valor diferencial**: interpreta visualmente planos sin capa de texto, distingue tipologías cartográficas (`CI` vs `CO`, plantas, alzados, secciones), lee con estructura espacial las **cartelas/cajetines** y extrae tablas complejas o fichas de catálogo.
* **Técnica clave para planos `A0`/`A1` (`Multi-Crop`)**: enviar al VLM una vista global a `100 DPI` + un recorte de alta nitidez (`250-300 DPI`) de la esquina inferior derecha (cartela) junto al texto de apoyo de `RapidOCR`.
* **Modelos recomendados**:
  * **100 % Local (Ollama)**: `qwen2.5vl:7b` o `gemma3:12b` (requiere GPU con 8-12 GB de VRAM).
  * **Cloud API**: Gemini 2.5 Flash / Pro (procesamiento nativo de alta resolución y gran ventana de contexto sin requerir GPU local).
* **Integración limpia**: al estar los Agentes 2 y 3 desacoplados mediante `especificaciones_agente_1.json`, solo sería necesario sustituir/ampliar el lector y clasificador del Agente 1.
