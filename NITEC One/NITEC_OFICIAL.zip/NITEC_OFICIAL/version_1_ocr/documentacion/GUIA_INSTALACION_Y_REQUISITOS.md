# 🚀 Guía de Instalación y Ejecución (Versión con Lectura de Imágenes OCR)

Esta versión incorpora lectura automática de imágenes y planos escaneados dentro de los archivos PDF mediante **PyMuPDF (`fitz`)** y **RapidOCR (`rapidocr-onnxruntime`)**.

## 1. Requisitos Previos
1. **Python 3.10 o superior**.
2. **Ollama** instalado y ejecutándose (`ollama serve`) con los modelos descargados:
   ```bash
   ollama pull llama3.1
   ollama pull nomic-embed-text
   ```

## 2. Instalación de Librerías (Incluyendo Lectura de Imágenes / OCR)
Desde la carpeta raíz del proyecto, instala todas las dependencias con:
```bash
pip install -r requirements.txt
```
*(O manualmente: `pip install langchain langchain-core langchain-community langchain-text-splitters langchain-ollama langchain-chroma chromadb pypdf rank-bm25 pymupdf rapidocr-onnxruntime pillow`)*

## 3. Ejecución del Sistema
Ejecuta el orquestador principal:
```bash
python main.py
```
