# 🖥️ Requisitos de Hardware — Sistema NITEC v1 (100 % Local: OCR + LLM de Texto)

Este documento detalla el dimensionamiento de hardware necesario para ejecutar de principio a fin la **Versión 1 (`sistema_nitec_ocr_v1`)** del sistema multi-agente de validación, lectura OCR, auditoría normativa BOJA y empaquetado de proyectos urbanísticos, de arquitectura e ingeniería **100 % en local (sin conexión a la nube)**.

---

## 1. Desglose de Consumo Real por Componente del Sistema

Para dimensionar correctamente los equipos donde se instalará el producto, este es el consumo real de cada pieza durante la ejecución:

| Componente / Fase | Motor / Modelo Local | Recurso Principal | Huella en Disco | Consumo en Memoria (VRAM / RAM) |
| :--- | :--- | :--- | :--- | :--- |
| **Razonamiento Agentes 1 y 2** | Ollama — `llama3.1` (`8B` Q4_K_M, `num_ctx=16000`) | **GPU (VRAM)** *(o RAM si va en CPU)* | ~4,7 GB | **~7,0 – 7,8 GB** *(~5,0 GB pesos + ~2,0 GB caché KV para 16k tokens)* |
| **Embeddings Vectoriales** | Ollama — `nomic-embed-text` (`137M`) | **GPU (VRAM) / CPU** | ~0,3 GB | **~0,4 – 0,6 GB** |
| **Lectura de Planos/Escaneos** | `PyMuPDF` (`150 DPI`) + `RapidOCR` (`ONNXRuntime`) | **CPU multihilo + RAM** | ~0,2 GB | **~0,5 – 1,5 GB RAM** *(picos al rasterizar planos `A0`/`A1`)* |
| **Bases Vectoriales y Léxica** | `ChromaDB` (`bd_normativas` + `bd_vectores`) + `BM25` | **RAM + SSD** | 0,1 – 1,5 GB | **~0,4 – 0,8 GB RAM** |
| **Agente 3 (Compresión y Corte)** | `PyMuPDF` (`deflate`/`garbage=4`) + `pypdf` | **CPU + RAM + SSD NVMe** | Temporal 2x peso proyecto | **~1,0 – 3,0 GB RAM** *(en expedientes pesados con ortofotos)* |

> **Punto crítico de diseño**: Los Agentes 1 y 2 utilizan una ventana de contexto amplia (`num_ctx = 16000` tokens) para leer bloques completos del BOJA sin truncar tablas del Anexo II. Por ello, tener **al menos 8–12 GB de VRAM dedicada** (o 16–24 GB de memoria unificada en Apple Silicon) marca la diferencia entre procesar en segundos sobre GPU o en minutos sobre CPU.

---

## 2. Perfiles de Hardware Recomendados

### 🟡 Nivel 1 — Mínimo Funcional (Equipos sin GPU dedicada o GPU básica)
*Válido para despachos pequeños con volumen bajo de expedientes o portátiles de oficina estándar. Funciona al 100 %, pero la inferencia de `llama3.1` recae total o parcialmente sobre la CPU.*

* **Procesador (CPU)**: 6 núcleos / 12 hilos modernos con soporte `AVX2` (ej. *Intel Core i5-11400 / i5-12400*, *AMD Ryzen 5 5600* o *Apple M1*).
* **Memoria RAM**: **16 GB DDR4 / DDR5** *(mínimo estricto: Windows 11 consume ~4 GB + `llama3.1` en RAM ~7,5 GB + Python/OCR/Chroma ~2,5 GB)*.
* **Tarjeta Gráfica (GPU)**: Integrada o dedicada básica de 4–6 GB VRAM (ej. *GTX 1650 / RTX 3050 6 GB*). Ollama repartirá capas automáticamente entre GPU y RAM.
* **Almacenamiento**: **25 GB libres en SSD NVMe** *(no usar discos mecánicos HDD: penalizan severamente a ChromaDB y la división de PDFs del Agente 3)*.
* **Tiempos orientativos**:
  * Ingesta inicial única del BOJA completo (solo la 1ª vez): ~`8 – 15 min`.
  * Procesamiento completo de un proyecto habitual (Agentes 1 + 2 + 3): ~`2 – 5 min`.

---

### 🟢 Nivel 2 — Recomendado Comercial (Estándar para Estudios de Arquitectura e Ingeniería)
*Configuración ideal calidad/precio para comercializar o recomendar al cliente final. Permite ejecutar todo el flujo en segundos mientras el técnico mantiene abiertos AutoCAD, Revit o QGIS.*

* **Procesador (CPU)**: **8 núcleos / 16 hilos** (ej. *Intel Core i7-12700 / i7-13700 / Core Ultra 7* o *AMD Ryzen 7 5800X / 7700X*).
* **Memoria RAM**: **32 GB DDR4 / DDR5** *(holgura total para rasterizar planos `A0` con imágenes pesadas y comprimir/fragmentar PDFs de varios cientos de MB)*.
* **Tarjeta Gráfica (GPU)**:
  * **Opción PC Windows/Linux (Óptima)**: **NVIDIA GeForce RTX 3060 (12 GB VRAM)**, **RTX 4060 Ti (16 GB VRAM)** o **RTX 4070 (12 GB VRAM)**. Con **12 GB de VRAM**, tanto `llama3.1` (`num_ctx=16000`) como `nomic-embed-text` caben íntegramente en la tarjeta gráfica sin tocar la RAM del sistema. *(Una RTX 4060 de 8 GB VRAM también ofrece muy buen rendimiento).*
  * **Opción Mac (Apple Silicon)**: **Mac Mini / MacBook Pro con chip M2 Pro, M3 Pro o M4 Pro y 24 GB de Memoria Unificada** *(mínimo 16 GB unificados)*.
* **Almacenamiento**: **50 GB libres en SSD NVMe M.2 PCIe 4.0**.
* **Tiempos orientativos**:
  * Ingesta inicial única del BOJA completo (solo la 1ª vez): ~`1 – 2,5 min`.
  * Procesamiento completo de un proyecto habitual: **~`20 – 50 segundos`**.

---

### 🔵 Nivel 3 — Alto Rendimiento / Servidor Local de Despacho
*Pensado para consultoras de planeamiento urbanístico (PGOM completos con decenas de planos pesados, estudios ambientales y bases SIG `.gpkg`), ayuntamientos o uso intensivo diario.*

* **Procesador (CPU)**: **12 a 16 núcleos** (ej. *Intel Core i7-14700K / Core i9*, *AMD Ryzen 9 7900X / 9900X* o *Apple M3/M4 Max*).
* **Memoria RAM**: **64 GB DDR5**.
* **Tarjeta Gráfica (GPU)**: **NVIDIA RTX 4070 Ti Super (16 GB)**, **RTX 4080 Super (16 GB)** o **RTX 3090 / 4090 (24 GB VRAM)** *(o Mac Studio / MacBook Pro con 36+ GB de Memoria Unificada)*.
* **Almacenamiento**: **100+ GB libres en SSD NVMe PCIe 4.0**.
* **Tiempos orientativos**:
  * Procesamiento completo de expedientes complejos multiformato: **~`10 – 25 segundos`**.

---

## 3. Requisitos de Sistema Operativo y Notas de Optimización

1. **Sistemas Operativos soportados**:
   * **Windows 10 (64-bit, 22H2) o Windows 11 (64-bit)** con drivers NVIDIA actualizados (CUDA 12+ incluido automáticamente por Ollama).
   * **macOS 13 Ventura o superior** (aceleración nativa por hardware Metal en Apple Silicon M1/M2/M3/M4).
   * **Linux Ubuntu 22.04 / 24.04 LTS** (64-bit).
2. **Tarjetas gráficas NVIDIA frente a AMD / Intel**:
   * Se recomienda priorizar **GPU NVIDIA RTX** en equipos Windows por su madurez con CUDA en Ollama. Las GPUs **AMD Radeon RX serie 6000/7000** con `>= 12 GB` VRAM también son compatibles mediante el soporte ROCm de Ollama, aunque con configuración ligeramente más sensible a versión de driver.
3. **Truco de optimización para equipos ajustados con GPU de 8 GB VRAM**:
   * Configurar en las variables de entorno del sistema antes de iniciar Ollama:
     ```powershell
     setx OLLAMA_FLASH_ATTENTION "1"
     setx OLLAMA_KV_CACHE_TYPE "q8_0"
     ```
   * Esto reduce a la mitad la memoria consumida por la ventana de `16.000` tokens (~1,0 GB menos de VRAM) sin pérdida apreciable de precisión en la extracción normativa ni documental, permitiendo que `llama3.1` + `nomic-embed-text` entren con total holgura en una GPU de **8 GB de VRAM**.
