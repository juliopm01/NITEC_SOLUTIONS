# ⚡🧮 Requisitos Computacionales y Consumo Energético — Sistema NITEC v1 (Librerías Python + OCR ONNX + LLM Local)

Este documento define la carga computacional exacta (FLOPs, ancho de banda de memoria, hilos de CPU, operaciones de disco) y el **consumo energético real (`W`, `Wh`, `kWh`, coste en `€` y huella de $\text{CO}_2$)** del sistema **`sistema_nitec_ocr_v1`** (basado en las librerías Python `PyMuPDF`, `pypdf`, `RapidOCR` sobre `ONNXRuntime`, `ChromaDB` y `llama3.1` en Ollama) **según el entorno de hardware donde se ejecute**.

---

## 1. Perfil Computacional de Cada Fase del Sistema (`v1`)

Para un **expediente urbanístico/arquitectónico tipo** (compuesto por 1 Memoria digital de 50 páginas, 1 Normativa de 25 páginas, 6 Planos `A1`/`A0` con cajetines/imágenes y 2 Anexos técnicos; peso total ~120 MB), la carga computacional se distribuye así:

| Fase del Pipeline | Motor / Librería Python | Tipo de Cómputo Dominante | Carga Matemática Estimada | Cuello de Botella Principal |
| :--- | :--- | :--- | :--- | :--- |
| **1. Extracción Digital de PDFs** | `PyMuPDF` (`fitz`) / `pypdf` | Monohilo CPU + E/S SSD | < 0,05 GFLOPs *(parseo de árboles PDF)* | Latencia de lectura en SSD (`< 0,2 s`) |
| **2. Rasterizado + OCR de Planos** | `PyMuPDF` (`150 DPI`) + `RapidOCR` (`ONNXRuntime` AVX2) | **CPU Multihilo (INT8 / FP32)** | **~2,5 – 4,5 GFLOPs por plano** *(~25 GFLOPs en 6 planos)* | Caché L3 de CPU y frecuencia multinúcleo |
| **3. Indexación Vectorial y BM25** | `nomic-embed-text` (`137M`) + `ChromaDB` + `rank-bm25` | **GPU / CPU Matricial** | **~0,4 TFLOPs** *(~80 fragmentos de 1.000 caracteres)* | Ancho de banda de memoria y escritura SQLite |
| **4. Agente 1 (Carátula + Clasificación)** | `llama3.1:8b` (`Q4_K_M`, `num_ctx=16000`) | **Inferencia LLM (Prefill + Decode)** | **~9 – 14 TFLOPs** *(~3.500 tokens entrada, ~250 salida)* | **Ancho de banda de VRAM/RAM (`GB/s`)** |
| **5. Agente 2 (Auditoría Municipal)** | `llama3.1:8b` + `boja_base.json` (en caché) | **Inferencia LLM Ligera / Caché JSON** | **0 TFLOPs** *(si el municipio ya está en BD)* o **~4 TFLOPs** *(1ª vez)* | Lectura instantánea JSON (`< 5 ms`) |
| **6. Agente 3 (Compresión y Corte)** | `PyMuPDF` (`deflate`/`garbage=4`) + `pypdf` (`zlib`) | **CPU (Compresión `DEFLATE`) + SSD** | Algorítmico (`LZ77` + Huffman sobre streams) | **Velocidad monohilo CPU + escritura NVMe** |

> **Nota sobre la 1ª lectura única del BOJA (`Agente 2`)**: Escanear por primera vez un boletín autonómico completo (~26 páginas, dividido en 3 bloques *Map-Reduce* de `10` páginas con `num_ctx=16000`) supone procesar ~18.000 tokens de entrada y ~1.800 tokens JSON de salida (**~45 – 55 TFLOPs** totales). Una vez guardado en `boja_base.json`, el coste computacional de leer el BOJA en futuras ejecuciones cae exactamente a **cero**.

---

## 2. Rendimiento y Consumo Energético Según Dónde se Corra el Sistema

El consumo energético total de ejecutar un expediente responde a la relación física entre la potencia media demandada por el equipo bajo carga ($P$, en vatios) y el tiempo que tarda en completar el trabajo ($t$, en segundos):

$$E_{\text{expediente}}\,(\text{Wh}) = \frac{P_{\text{media}}\,(\text{W}) \times t_{\text{ejecución}}\,(\text{s})}{3600}$$

A continuación se comparan los **5 entornos reales de despliegue** donde puede instalarse el sistema:

### Resumen Comparativo por Plataforma (Por 1 Expediente Tipo de ~120 MB y 6 Planos)

| Entorno donde se ejecuta el sistema | Velocidad LLM (`llama3.1`) | Tiempo Total por Expediente ($t$) | Potencia Media en Pared ($P$) | Energía por Expediente ($\text{Wh}$) | Coste Eléctrico / 100 Expedientes* |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **A. Portátil / PC Oficina (Solo CPU x86)**<br>*(Core i5/i7 o Ryzen 5/7, 16 GB RAM, sin GPU)* | `7 – 11 tok/s` | **~195 s** *(3 min 15 s)* | **~75 W** | **4,06 Wh** *(0,0041 kWh)* | **0,073 €** *(~65 $\text{gCO}_2$)* |
| **B. Sobremesa Estudio Gama Media (GPU 12 GB)**<br>*(Core i7 / Ryzen 7 + **NVIDIA RTX 3060 12 GB / 4060**)* | `52 – 68 tok/s` | **~34 s** | **~215 W** | **2,03 Wh** *(0,0020 kWh)* | **0,037 €** *(~32 $\text{gCO}_2$)* |
| **C. Workstation Alto Rendimiento (GPU 16–24 GB)**<br>*(Core i9 / Ryzen 9 + **NVIDIA RTX 4070 Ti S / 4090**)* | `110 – 155 tok/s` | **~18 s** | **~360 W** | **1,80 Wh** *(0,0018 kWh)* | **0,032 €** *(~29 $\text{gCO}_2$)* |
| **D. Apple Silicon (Memoria Unificada Metal)**<br>*(**Mac Mini / MacBook Pro M2/M3/M4 Pro 24 GB**)* | `40 – 60 tok/s` | **~38 s** | **~48 W** | **0,51 Wh** *(0,0005 kWh)* | **0,009 €** *(~8 $\text{gCO}_2$)* |
| **E. Servidor On-Premise Compartido de Estudio**<br>*(Nodo local con RTX 4060 Ti 16 GB encendido 8h/día)* | `65 – 75 tok/s` | **~30 s** *(+ consumo basal idle)* | **~200 W** activo / **~42 W** reposo | **1,67 Wh** activo *(+ 336 Wh/día idle)* | **0,030 €** activo *(+ ~1,33 €/mes idle)* |

*\*Cálculo basado en una tarifa eléctrica media en España de `0,18 €/kWh` (impuestos incluidos) y factor de emisión de red de `160 gCO2eq/kWh`.*

---

## 3. Análisis Detallado por Entorno de Ejecución

### 🖥️ Entorno A: Ejecución en Solo CPU (Portátiles de Oficina / Mini-PCs sin GPU dedicada)
* **Comportamiento computacional**:
  * `PyMuPDF` y `RapidOCR` (`ONNXRuntime`) se ejecutan a su velocidad normal porque ya están diseñados para CPU (`~8 – 12 s` para los 6 planos).
  * Sin embargo, al no existir VRAM dedicada, `llama3.1` (`8B`) debe leerse desde la memoria RAM DDR4/DDR5 del sistema (ancho de banda de solo `~35 – 65 GB/s` frente a los `360 – 1.000 GB/s` de una GPU). Esto satura el controlador de memoria de la CPU al 100 % durante ~2,5 minutos.
* **Comportamiento energético**:
  * Aunque la potencia instantánea es moderada (**`65 – 85 W`**), el procesador permanece en estado de máxima frecuencia (*Turbo Boost*) durante más de 3 minutos, haciendo que **consuma el doble de energía total en `Wh` (`~4,06 Wh`) que un PC con tarjeta gráfica dedicada (`~2,03 Wh`)**.
  * En portátiles, esto activa los ventiladores al máximo y drena aproximadamente un **7 % – 9 % de una batería estándar de 55 Wh** por cada expediente procesado.

### 🎮 Entorno B: PC de Estudio con GPU NVIDIA Gama Media (RTX 3060 12 GB / RTX 4060 Ti 16 GB)
* **Comportamiento computacional**:
  * Es el **punto dulce técnico** para la `v1`: la CPU resuelve en paralelo el OCR ligero de `RapidOCR` (`ONNX`) y la compresión `DEFLATE` del Agente 3, mientras la GPU NVIDIA ejecuta `nomic-embed-text` y `llama3.1` a más de `55 tokens/s` gracias a un ancho de banda de VRAM de `272 – 360 GB/s`.
* **Comportamiento energético**:
  * La GPU sube a `~140 – 165 W` únicamente durante las ráfagas de inferencia LLM (que duran apenas `12 – 18 segundos` en total por expediente) y vuelve inmediatamente al estado de reposo (`P8 idle`, `~10 – 15 W`) mientras el Agente 3 empaqueta las carpetas en el SSD.
  * Energía total por expediente: **~`2,03 Wh`** (equivalente a tener encendida una bombilla LED de 10 W durante 12 minutos).

### 🚀 Entorno C: Workstation de Gama Alta (RTX 4070 Ti Super / RTX 4080 / RTX 4090)
* **Comportamiento computacional**:
  * El tiempo de inferencia de `llama3.1` y `nomic-embed-text` se vuelve casi despreciable (`< 6 segundos` en total). El tiempo total de ejecución (`~18 s`) pasa a estar dominado por la CPU y el disco NVMe (rasterizado `150 DPI`, `RapidOCR` en CPU y compresión/fragmentación de PDFs en Agente 3).
* **Comportamiento energético**:
  * A pesar de que la fuente de alimentación entrega picos de `320 – 420 W` durante unos pocos segundos, la altísima velocidad de despacho (*"race-to-idle"*) reduce aún más el gasto por expediente a **~`1,80 Wh`**.

### 🍏 Entorno D: Apple Silicon (Mac Mini / MacBook Pro con M2/M3/M4 Pro o Max)
* **Comportamiento computacional**:
  * La arquitectura de **Memoria Unificada** (`150 – 400 GB/s` de ancho de banda) permite que la CPU (que corre `RapidOCR` mediante instrucciones ARM `NEON`/`AMX`) y la GPU integrada de Apple (que corre `llama3.1` sobre `Metal`) accedan a los mismos bloques de memoria sin copiar datos por el bus PCIe.
* **Comportamiento energético**:
  * Es, con gran diferencia, **la plataforma más eficiente energéticamente**: consume apenas **`35 – 55 W`** en pared a plena carga y completa el expediente en `~38 s`, arrojando solo **`0,51 Wh` por proyecto** (**4 veces menos energía** que un PC Windows con GPU dedicada y **8 veces menos** que un portátil x86 en solo CPU).

---

## 4. Coste Computacional y Energético de la Ingesta Única Inicial del BOJA

Cuando se instala el sistema por primera vez (o cuando la Junta de Andalucía publica un nuevo BOJA normativo), se ejecuta una única vez la lectura completa Map-Reduce:

| Plataforma | Tiempo de Ingesta Única BOJA | Energía Consumida (`Wh`) | Coste Eléctrico Único (`€`) |
| :--- | :--- | :--- | :--- |
| **A. Solo CPU (Portátil / Oficina)** | ~10 min (600 s) | **~12,50 Wh** | **0,0023 €** |
| **B. PC Estudio (RTX 3060 12 GB / 4060 Ti)** | ~1 min 30 s (90 s) | **~5,38 Wh** | **0,0010 €** |
| **C. Workstation (RTX 4080 / 4090)** | ~40 s | **~4,00 Wh** | **0,0007 €** |
| **D. Apple Silicon (M2/M3/M4 Pro)** | ~1 min 45 s (105 s) | **~1,40 Wh** | **0,0003 €** |
