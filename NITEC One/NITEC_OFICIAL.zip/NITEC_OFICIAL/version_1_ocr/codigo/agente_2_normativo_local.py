"""
Módulo: agente_2_normativo_local.py (Agente 2 — Auditor Normativo Autonómico y Municipal)
================================================================================
Propósito general:
    Representa la segunda línea de trabajo del sistema NITEC: gestiona de forma
    dinámica y persistente las reglas normativas tanto autonómicas (BOJA u otros
    boletines oficiales) como municipales (límites de tamaño de archivo por
    ayuntamiento).

Capacidades principales:
    1. Lectura completa por única vez del boletín regulatorio autonómico
       (`analizar_documento_completo_y_extraer_normativa`):
       Recorre todas las páginas del PDF en bloques secuenciales (Map-Reduce)
       con contexto deslizante de 12 líneas entre páginas para no partir tablas,
       extrayendo límites generales de peso (MB), patrón de numeración de partes
       (`09_99`), tipos de proyecto (`PGOM`, `POU`, `ED`, `PRI`, etc.) y el árbol
       completo de carpetas y plantillas de archivos (incluidos archivos en `_RAIZ_`).
       El resultado queda guardado permanentemente en `boja_base.json` sin
       ningún *hardcoding* previo en el código.
    2. Construcción dinámica del catálogo documental (`construir_catalogo_documental`):
       Transforma cualquier `estructura_carpetas` descubierta en descriptores
       normalizados listos para que el Agente 1 clasifique y el Agente 3 empaquete.
    3. Memoria persistente de límites de peso por ayuntamiento
       (`normativas_ayuntamientos.json` + consulta RAG en `./bd_normativas`):
       Los límites locales introducidos manualmente o extraídos de ordenanzas se
       guardan de forma permanente para no volver a solicitarlos en futuras
       ejecuciones, aplicando siempre el criterio más restrictivo
       `min(limite_boja, limite_ayuntamiento)`.
================================================================================
"""

import ast
import copy
import gc
import json
import math
import os
import re
import shutil
import sys
import tempfile
import unicodedata

from lector_ocr_pdf import cargar_pdf_con_ocr

try:
    from langchain_chroma import Chroma
    from langchain_ollama import OllamaEmbeddings, ChatOllama
    from langchain_core.prompts import ChatPromptTemplate
    from langchain_core.output_parsers import StrOutputParser
    LANGCHAIN_DISPONIBLE = True
except Exception:
    Chroma = None
    OllamaEmbeddings = None
    ChatOllama = None
    ChatPromptTemplate = None
    StrOutputParser = None
    LANGCHAIN_DISPONIBLE = False

# Archivos y carpetas de persistencia normativa anclados al directorio del módulo
DIRECTORIO_BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO_BOJA = os.path.join(DIRECTORIO_BASE, "boja_base.json")
ARCHIVO_AYUNTAMIENTOS = os.path.join(DIRECTORIO_BASE, "normativas_ayuntamientos.json")
CARPETA_LEYES = os.path.join(DIRECTORIO_BASE, "normativas_pdf")
RUTA_BD_LEGAL = os.path.join(DIRECTORIO_BASE, "bd_normativas")

llm = None

# Marcas léxicas para distinguir boletines autonómicos frente a ordenanzas exclusivamente municipales
_PALABRAS_BOLETIN_AUTONOMICO = (
    "boja", "boletin", "bocm", "dogc", "dogv", "borm", "boa", "bopa",
    "bopv", "doe", "docm", "bor", "bocyl", "boc", "boib", "bon", "dog",
    "junta", "autonomic", "normativa_autonomica", "normativa_general", "nitec",
)

_PALABRAS_EXCLUSIVAS_MUNICIPALES = (
    "municipal", "ayuntamiento", "ordenanza", "pgou_", "pgom_", "local_",
)

# Claves reservadas para representar documentos ubicados directamente en la carpeta raíz del proyecto
_CLAVES_CARPETA_RAIZ = {"_raiz_", "raiz", "_root_", "root", "."}


def _imprimir(mensaje):
    """Imprime de forma segura en consolas Windows cp1252 o flujos redirigidos."""
    try:
        print(mensaje)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        seguro = str(mensaje).encode(enc, errors="replace").decode(enc, errors="replace")
        print(seguro)


def _obtener_llm():
    """Inicializa perezosamente `ChatOllama` (`llama3.1`) solo cuando se requiere inferencia."""
    global llm
    if llm is None:
        if not LANGCHAIN_DISPONIBLE or ChatOllama is None:
            raise ImportError("Faltan dependencias de LangChain/Ollama. Ejecuta: pip install -r requirements.txt")
        llm = ChatOllama(model="llama3.1", temperature=0, num_ctx=16000)
    return llm


def _guardar_json_atomico(ruta_archivo, datos):
    """Persiste un archivo JSON de forma atómica evitando escrituras truncadas o corruptas."""
    carpeta = os.path.dirname(os.path.abspath(ruta_archivo))
    os.makedirs(carpeta, exist_ok=True)
    fd, ruta_tmp = tempfile.mkstemp(prefix=".tmp_norm_", suffix=".json", dir=carpeta)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(datos, f, indent=2, ensure_ascii=False)
        os.replace(ruta_tmp, ruta_archivo)
    except Exception:
        if os.path.exists(ruta_tmp):
            try:
                os.unlink(ruta_tmp)
            except OSError:
                pass
        raise


def _normalizar(texto):
    """Normaliza cadenas para claves de municipios y comparación de nombres de archivos."""
    if texto is None or isinstance(texto, bool):
        return ""
    texto = str(texto).strip().lower()
    if not texto:
        return ""
    texto_sin_tildes = "".join(
        c for c in unicodedata.normalize("NFD", texto)
        if unicodedata.category(c) != "Mn"
    )
    texto_limpio = re.sub(r"[\s\-–—_/.,;:'’‘\"“”()·]+", "_", texto_sin_tildes)
    return re.sub(r"[^a-z0-9_]", "", texto_limpio).strip("_")


def _limpiar_plantilla_codigo(texto):
    """
    Sanea erratas habituales de maquetación en plantillas oficiales extraídas de tablas PDF
    (p. ej. espacios junto a guiones bajos 'INE_ED_AMB_ FT_AAAAMMDD' o prefijos 'INE_INE_')
    preservando intacta cualquier descripción humana separada tras '|'.
    """
    if texto is None or isinstance(texto, bool):
        return ""
    cadena = str(texto).strip()
    if not cadena:
        return ""

    if "|" in cadena:
        parte_cod, parte_desc = cadena.split("|", 1)
        cod_limpio = _limpiar_plantilla_codigo(parte_cod)
        desc_limpia = " ".join(parte_desc.strip().split())
        return f"{cod_limpio} | {desc_limpia}" if desc_limpia else cod_limpio

    cod = re.sub(r"\s*_\s*", "_", cadena)
    cod = re.sub(r"_{2,}", "_", cod)
    cod = re.sub(r"^INE_INE_", "INE_", cod, flags=re.IGNORECASE)
    return cod.strip()


def _separar_codigo_y_descripcion(etiqueta):
    """Separa una entrada 'CODIGO_PLANTILLA | Descripción' en (codigo_limpio, descripcion)."""
    limpio = _limpiar_plantilla_codigo(etiqueta)
    if "|" in limpio:
        cod, desc = limpio.split("|", 1)
        return cod.strip(), desc.strip()
    return limpio.strip(), ""


def _extraer_primer_entero(texto, por_defecto=50):
    """
    Extrae el primer entero positivo válido ignorando números negativos previos
    (ej. `'-15'` -> usa `por_defecto`; `'25,5 MB'` -> `25`) y valores `NaN`/`inf`/`bool`.
    """
    if texto is None or isinstance(texto, bool):
        return por_defecto
    if isinstance(texto, (int, float)):
        if not math.isfinite(texto) or texto <= 0:
            return por_defecto
        entero = int(texto)
        return entero if entero > 0 else por_defecto

    cadena = str(texto).strip()
    if not cadena or re.match(r"^\s*-\s*\d", cadena):
        return por_defecto

    # Eliminar números explícitamente negativos (incluyendo decimales o espacio tras '-') antes de buscar
    cadena_positiva = re.sub(r"-\s*\d+(?:[.,]\d+)?", " ", cadena)
    coincidencia = re.search(r"(?<![-\d.,])(\d+)(?:[.,]\d+)?(?!\d)", cadena_positiva)
    if coincidencia:
        valor = int(coincidencia.group(1))
        return valor if valor > 0 else por_defecto
    return por_defecto


def _extraer_json_de_texto(texto):
    """Extrae un diccionario JSON válido de la respuesta del LLM tolerando bloques Markdown y comillas simples."""
    if not texto or not str(texto).strip():
        raise ValueError("El LLM devolvió una respuesta vacía.")
    texto_limpio = re.sub(r"```(?:json)?", "", str(texto), flags=re.IGNORECASE).strip()
    texto_sin_comas = re.sub(r",\s*([\}\]])", r"\1", texto_limpio)

    for candidato in (texto_limpio, texto_sin_comas):
        try:
            obj = json.loads(candidato)
            if isinstance(obj, dict):
                return obj
        except json.JSONDecodeError:
            pass

    decoder = json.JSONDecoder()
    for fuente in (texto_sin_comas, texto_limpio):
        for match in re.finditer(r"\{", fuente):
            inicio = match.start()
            fragmento = fuente[inicio:]
            try:
                obj, _ = decoder.raw_decode(fragmento)
                if isinstance(obj, dict):
                    return obj
            except json.JSONDecodeError:
                pass
            posiciones_cierre = [m.start() for m in re.finditer(r"\}", fragmento)]
            for fin in posiciones_cierre:
                try:
                    obj_py = ast.literal_eval(fragmento[: fin + 1])
                    if isinstance(obj_py, dict):
                        return obj_py
                except Exception:
                    continue

    raise ValueError("No se encontró un objeto JSON válido en la respuesta del LLM.")


def _es_pdf_boletin_autonomico(nombre_archivo):
    """Determina si el nombre de un PDF en `./normativas_pdf` corresponde a un boletín autonómico y no a una ordenanza local."""
    base_norm = _normalizar(os.path.splitext(os.path.basename(nombre_archivo))[0])
    if not base_norm:
        return False
    tiene_marca_boletin = any(k in base_norm for k in _PALABRAS_BOLETIN_AUTONOMICO)
    if not tiene_marca_boletin:
        return False
    # Si contiene marcas inequívocas de boletín oficial ('boja', 'boletin', etc.), prevalece
    if any(k in base_norm for k in ("boja", "boletin", "bocm", "dogc", "dogv", "junta", "autonomic", "nitec")):
        return True
    if any(m in base_norm for m in _PALABRAS_EXCLUSIVAS_MUNICIPALES):
        return False
    return True


def _localizar_pdf_boja(ruta_pdf=None):
    """Localiza el PDF del boletín autonómico priorizando la ruta explícita o boletines en CARPETA_LEYES."""
    if ruta_pdf:
        ruta_limpia = str(ruta_pdf).strip().strip('"').strip("'")
        if os.path.isfile(ruta_limpia) and ruta_limpia.lower().endswith(".pdf") and os.path.getsize(ruta_limpia) > 0:
            os.makedirs(CARPETA_LEYES, exist_ok=True)
            destino = os.path.join(CARPETA_LEYES, os.path.basename(ruta_limpia))
            if os.path.abspath(ruta_limpia) != os.path.abspath(destino):
                try:
                    shutil.copy2(ruta_limpia, destino)
                except Exception:
                    pass
            return ruta_limpia
        return None

    if os.path.isdir(CARPETA_LEYES):
        archivos = sorted([
            f for f in os.listdir(CARPETA_LEYES)
            if f.lower().endswith(".pdf")
        ])
        for f in archivos:
            ruta_candidata = os.path.join(CARPETA_LEYES, f)
            if os.path.isfile(ruta_candidata) and os.path.getsize(ruta_candidata) > 0 and _es_pdf_boletin_autonomico(f):
                return ruta_candidata
    return None


def _normalizar_lista_archivos(valor):
    """Convierte cualquier representación de archivos (str, list, dict) en una lista limpia sin duplicados."""
    elementos = []
    if isinstance(valor, list):
        for item in valor:
            elementos.extend(_normalizar_lista_archivos(item))
    elif isinstance(valor, dict):
        if "codigo" in valor and str(valor.get("codigo") or "").strip():
            cod = _limpiar_plantilla_codigo(valor.get("codigo"))
            desc = str(valor.get("descripcion") or valor.get("nombre") or "").strip()
            etiqueta = f"{cod} | {desc}" if desc else cod
            if etiqueta:
                elementos.append(etiqueta)
        else:
            for k, v in valor.items():
                if isinstance(v, (list, dict)):
                    elementos.extend(_normalizar_lista_archivos(v))
                elif v and str(v).strip():
                    elementos.append(_limpiar_plantilla_codigo(v))
                elif k and str(k).strip():
                    elementos.append(_limpiar_plantilla_codigo(k))
    elif valor is not None and not isinstance(valor, bool):
        txt = _limpiar_plantilla_codigo(valor)
        if txt:
            elementos.append(txt)
    return list(dict.fromkeys(elementos))


def _fusionar_estructuras_carpetas(estructura_base, estructura_nueva):
    """
    Fusiona de forma acumulativa e inmutable (deepcopy) las carpetas y tipos de archivos
    descubiertos en distintos bloques del PDF sin mutar referencias compartidas.
    """
    resultado = copy.deepcopy(estructura_base) if isinstance(estructura_base, dict) else {}
    if not isinstance(estructura_nueva, dict):
        return resultado

    # Índice auxiliar por código de carpeta (sin la parte descriptiva '| ...') para unificar bloques
    mapa_codigos = {}
    for k_exist in list(resultado.keys()):
        cod_exist, _ = _separar_codigo_y_descripcion(k_exist)
        if cod_exist:
            mapa_codigos[cod_exist.upper()] = k_exist

    for carpeta, contenido in estructura_nueva.items():
        carpeta_limpia = _limpiar_plantilla_codigo(carpeta) if carpeta is not None else ""
        if not carpeta_limpia:
            continue

        cod_nuevo, desc_nueva = _separar_codigo_y_descripcion(carpeta_limpia)
        clave_existente = mapa_codigos.get(cod_nuevo.upper()) if cod_nuevo else None

        if clave_existente is None:
            if isinstance(contenido, dict) and "codigo" not in contenido:
                resultado[carpeta_limpia] = _fusionar_estructuras_carpetas({}, contenido)
            else:
                resultado[carpeta_limpia] = _normalizar_lista_archivos(contenido)
            if cod_nuevo:
                mapa_codigos[cod_nuevo.upper()] = carpeta_limpia
        else:
            # Si la nueva clave aporta descripción humana y la anterior no, enriquecer clave
            _, desc_previa = _separar_codigo_y_descripcion(clave_existente)
            clave_final = clave_existente
            if desc_nueva and not desc_previa and clave_existente != carpeta_limpia:
                resultado[carpeta_limpia] = resultado.pop(clave_existente)
                clave_final = carpeta_limpia
                mapa_codigos[cod_nuevo.upper()] = clave_final

            actual = resultado[clave_final]
            if isinstance(actual, dict) and isinstance(contenido, dict) and "codigo" not in contenido:
                resultado[clave_final] = _fusionar_estructuras_carpetas(actual, contenido)
            else:
                combinados = _normalizar_lista_archivos(actual) + _normalizar_lista_archivos(contenido)
                resultado[clave_final] = list(dict.fromkeys(combinados))
    return resultado


def construir_catalogo_documental(reglas_identidad):
    """
    Transforma dinámicamente la `estructura_carpetas` extraída de cualquier boletín oficial
    en un catálogo plano de destinos documentales apto para clasificación (Agente 1) y empaquetado (Agente 3),
    sin presuponer ni fijar en código ninguna estructura concreta del BOJA.
    """
    if not isinstance(reglas_identidad, dict):
        return []
    estructura = reglas_identidad.get("estructura_carpetas")
    if not isinstance(estructura, dict) or not estructura:
        return []

    catalogo = []
    contador = [0]

    def _inferir_extension_y_familia(plantilla_arch, desc_arch, desc_carp, cod_carp):
        texto_total = f"{plantilla_arch} {desc_arch} {desc_carp} {cod_carp}".lower()
        m_ext = re.search(r"\.(pdf|gpkg|shp|gml|dxf|dwg|txt|xml|csv|zip)\b", plantilla_arch.lower())

        # Si menciona explícitamente formatos espaciales/SIG vectoriales
        if any(p in texto_total for p in (".gpkg", ".shp", "geopackage", "shapefile", "vectorial", "informacion geografica", "información geográfica")) or re.search(r"(?:^|_)situ(?:_|$)", cod_carp.lower()):
            ext = f".{m_ext.group(1)}" if m_ext and m_ext.group(1) in ("gpkg", "shp", "gml") else "*"
            return ext, "SIG_VECTORIAL"

        # Si menciona explícitamente metadatos en texto o XML (ej. ISO 19115)
        if any(p in texto_total for p in (".txt", ".xml", "iso 19115", "metadato")) or re.search(r"(?:^|_)meta(?:_|$)", cod_carp.lower()):
            ext = f".{m_ext.group(1)}" if m_ext and m_ext.group(1) in ("txt", "xml") else ".txt"
            return ext, "METADATOS_TEXTO"

        if m_ext:
            ext_expl = f".{m_ext.group(1)}"
            fam = "PDF" if ext_expl == ".pdf" else "CUALQUIERA"
            return ext_expl, fam

        return ".pdf", "PDF"

    def _es_plantilla_seriada(plantilla_arch, desc_arch):
        if "seriad" in desc_arch.lower() or "serie numerada" in desc_arch.lower():
            return True
        sin_ext = re.sub(r"\.[a-z0-9]{2,5}$", "", plantilla_arch, flags=re.IGNORECASE)
        return bool(re.search(r"(?:[A-Z]{2,}01|_[0]*1)(?:_|$)", sin_ext))

    def _recorrer(nodo, ruta_codigos, ruta_descripciones):
        if isinstance(nodo, dict):
            for clave_carp, subnodo in nodo.items():
                cod_c, desc_c = _separar_codigo_y_descripcion(clave_carp)
                if not cod_c:
                    continue
                es_raiz = cod_c.strip().lower() in _CLAVES_CARPETA_RAIZ
                nueva_ruta_cod = ruta_codigos if es_raiz else (ruta_codigos + [cod_c])
                nueva_ruta_desc = ruta_descripciones if es_raiz else (ruta_descripciones + [desc_c or cod_c])

                if isinstance(subnodo, dict) and "codigo" not in subnodo:
                    if subnodo:
                        _recorrer(subnodo, nueva_ruta_cod, nueva_ruta_desc)
                    else:
                        _emitir_slot_carpeta_vacia(nueva_ruta_cod, nueva_ruta_desc)
                else:
                    archivos = _normalizar_lista_archivos(subnodo)
                    if not archivos and nueva_ruta_cod:
                        _emitir_slot_carpeta_vacia(nueva_ruta_cod, nueva_ruta_desc)
                    for entrada_arch in archivos:
                        cod_a, desc_a = _separar_codigo_y_descripcion(entrada_arch)
                        if not cod_a:
                            continue
                        contador[0] += 1
                        desc_carp_str = " / ".join(nueva_ruta_desc) if nueva_ruta_desc else "Raíz del proyecto"
                        cod_carp_ultimo = nueva_ruta_cod[-1] if nueva_ruta_cod else ""
                        ext_esp, fam_esp = _inferir_extension_y_familia(cod_a, desc_a, desc_carp_str, cod_carp_ultimo)
                        desc_humana = desc_a or re.sub(r"[_\-]+", " ", re.sub(r"\.[a-z0-9]{2,5}$", "", cod_a, flags=re.IGNORECASE)).strip()
                        catalogo.append({
                            "id_destino": f"D{contador[0]:02d}",
                            "en_raiz": len(nueva_ruta_cod) == 0,
                            "ruta_carpetas_plantilla": list(nueva_ruta_cod),
                            "descripcion_carpeta": desc_carp_str,
                            "plantilla_archivo": cod_a,
                            "descripcion_archivo": desc_humana,
                            "extension_esperada": ext_esp,
                            "familia_esperada": fam_esp,
                            "es_seriado": _es_plantilla_seriada(cod_a, desc_a),
                        })

    def _emitir_slot_carpeta_vacia(ruta_cod, ruta_desc):
        if not ruta_cod:
            return
        contador[0] += 1
        cod_base = ruta_cod[-1]
        desc_carp_str = " / ".join(ruta_desc)
        ext_esp, fam_esp = _inferir_extension_y_familia(cod_base, "", desc_carp_str, cod_base)
        catalogo.append({
            "id_destino": f"D{contador[0]:02d}",
            "en_raiz": False,
            "ruta_carpetas_plantilla": list(ruta_cod),
            "descripcion_carpeta": desc_carp_str,
            "plantilla_archivo": cod_base,
            "descripcion_archivo": desc_carp_str,
            "extension_esperada": ext_esp,
            "familia_esperada": fam_esp,
            "es_seriado": False,
        })

    _recorrer(estructura, [], [])
    return catalogo


def _inferir_reglas_generales_de_texto_pdf(paginas_con_texto):
    """Respaldo determinista sobre el texto del propio boletín si el LLM omite el límite o formato general."""
    texto_unido = "\n".join(txt for _, txt in paginas_con_texto[:20])
    limite_det = None
    m_peso = re.search(
        r"(?:superar|m[aá]ximo|l[ií]mite|tama[ñn]o)[^\n\d]{0,45}?(\d+)\s*(?:mb|megabytes?)\b",
        texto_unido,
        flags=re.IGNORECASE,
    )
    if m_peso:
        val = int(m_peso.group(1))
        if 1 <= val <= 2000:
            limite_det = val

    fmt_det = None
    m_fmt = re.search(r"\b(0+9[_-]9+)\b", texto_unido)
    if m_fmt:
        fmt_det = m_fmt.group(1)

    return limite_det, fmt_det


def analizar_documento_completo_y_extraer_normativa(ruta_pdf, tamano_bloque_paginas=10):
    """
    Lee el 100% del PDF normativo dividiéndolo en bloques secuenciales (Map-Reduce) con contexto deslizante.
    En cada bloque extrae proyectos, plantillas, carpetas y tipos de archivo, y los consolida en un único JSON.
    """
    _imprimir(f"   📖 [Agente 2] Escaneando el documento completo ({os.path.basename(ruta_pdf)}) para descubrir proyectos y estructura de carpetas...")
    todas_las_paginas = cargar_pdf_con_ocr(ruta_pdf, incluir_cabecera_documento=False)
    paginas_con_texto = [
        (idx + 1, p.page_content.strip())
        for idx, p in enumerate(todas_las_paginas)
        if p.page_content and p.page_content.strip()
    ]
    if not paginas_con_texto:
        raise ValueError("No se pudo extraer texto seleccionable del PDF normativo.")

    if not LANGCHAIN_DISPONIBLE or ChatPromptTemplate is None or StrOutputParser is None:
        raise ImportError("Faltan dependencias de LangChain/Ollama. Ejecuta: pip install -r requirements.txt")

    llm_activo = _obtener_llm()
    plantilla_bloque = ChatPromptTemplate.from_messages([
        ("system", """Eres un Auditor Normativo Experto en Urbanismo, Arquitectura e Ingeniería.
        Analiza este fragmento de normativa autonómica y extrae TODOS los tipos de instrumentos/proyectos urbanísticos, reglas de peso máximo (MB o Mb), formato de división/numeración de series y, MUY IMPORTANTE, la estructura completa de carpetas y los códigos/tipos de archivos que van dentro de cada carpeta (incluyendo archivos en la carpeta raíz, memorias, planos/cartografía, normativas, catálogos, estudios económicos, resúmenes ejecutivos, anexos, bases geográficas SIG, metadatos, etc.).

        Reglas de extracción dinámica:
        1. Si en este fragmento no se menciona algún dato general, usa null en ese campo.
        2. Conserva fielmente los marcadores de las plantillas oficiales de carpetas y archivos (como INE, TIP, AMB, FT, AAAAMMDD o equivalentes).
        3. Si hay documentos que van directamente en la carpeta raíz del instrumento sin subcarpeta propia, agrúpalos bajo la clave "_RAIZ_".
        4. Cuando la tabla indique tanto un código de carpeta/archivo como su título descriptivo, puedes incluirlos como "CODIGO_OFICIAL | Descripción del documento".

        FORMATO ESTRICTO JSON (Devuelve ÚNICAMENTE el objeto JSON, sin texto adicional):
        {{
          "limite_peso_general_mb": 50,
          "formato_division": "09_99",
          "estructura_carpetas_comun": {{
            "CODIGO_O_NOMBRE_CARPETA": [
              "CODIGO_O_TIPO_ARCHIVO_1 | Descripción opcional"
            ]
          }},
          "proyectos": {{
            "SIGLAS_DEL_PROYECTO": {{
              "nombre_completo": "Nombre de la figura de planeamiento",
              "plantilla_nombre": "PLANTILLA_DETECTADA",
              "estructura_carpetas": {{
                "_RAIZ_": [
                  "CODIGO_ARCHIVO_RAIZ | Documento en raíz (si existe)"
                ],
                "CODIGO_O_NOMBRE_CARPETA | Nombre carpeta": [
                  "CODIGO_ARCHIVO_1 | Tipo de documento 1",
                  "CODIGO_ARCHIVO_2 | Plano o cartografía 2"
                ]
              }}
            }}
          }}
        }}
        Texto del boletín:
        {bloque_texto}""")
    ])

    cadena_extraccion = plantilla_bloque | llm_activo | StrOutputParser()

    normativa_consolidada = {
        "limite_peso_general_mb": None,
        "formato_division": None,
        "estructura_carpetas_comun": {},
        "proyectos": {},
        "ruta_pdf_origen": ruta_pdf
    }

    tamano_bloque_paginas = max(1, int(tamano_bloque_paginas or 10))
    total_pags = len(paginas_con_texto)
    bloques_exitosos = 0
    ultimo_error_llm = None

    for inicio in range(0, total_pags, tamano_bloque_paginas):
        lote = paginas_con_texto[inicio:inicio + tamano_bloque_paginas]
        rango_str = f"págs. {lote[0][0]}-{lote[-1][0]} de {len(todas_las_paginas)}"
        _imprimir(f"      🔎 Analizando bloque ({rango_str})...")

        partes_bloque = []
        # Incluir las últimas 12 líneas del bloque anterior para mantener contexto de cabeceras de tabla multipágina
        if inicio > 0:
            num_prev, txt_prev = paginas_con_texto[inicio - 1]
            lineas_prev = [ln.strip() for ln in txt_prev.splitlines() if ln.strip()][-12:]
            if lineas_prev:
                partes_bloque.append(
                    f"[Contexto final de Página {num_prev} para continuidad de tablas]\n" + "\n".join(lineas_prev)
                )
        partes_bloque.extend([f"[Página {num}]\n{txt}" for num, txt in lote])
        bloque_texto = "\n\n".join(partes_bloque)

        try:
            respuesta_llm = cadena_extraccion.invoke({"bloque_texto": bloque_texto})
            datos_lote = _extraer_json_de_texto(respuesta_llm)
        except Exception as e:
            ultimo_error_llm = e
            _imprimir(f"      ⚠️ Aviso en bloque ({rango_str}): {e}")
            continue

        if not isinstance(datos_lote, dict):
            continue

        bloques_exitosos += 1

        # 1. Consolidar límite de peso general si aparece en este bloque
        lim_lote = datos_lote.get("limite_peso_general_mb")
        if lim_lote is not None:
            entero_lim = _extraer_primer_entero(lim_lote, por_defecto=0)
            if entero_lim > 0 and normativa_consolidada["limite_peso_general_mb"] is None:
                normativa_consolidada["limite_peso_general_mb"] = entero_lim

        # 2. Consolidar formato de división si aparece en este bloque
        fmt_lote = datos_lote.get("formato_division")
        if fmt_lote and str(fmt_lote).strip().lower() not in ("null", "none", ""):
            if normativa_consolidada["formato_division"] is None:
                normativa_consolidada["formato_division"] = str(fmt_lote).strip()

        # 3. Consolidar estructura de carpetas común
        est_comun = datos_lote.get("estructura_carpetas_comun")
        if isinstance(est_comun, dict) and est_comun:
            normativa_consolidada["estructura_carpetas_comun"] = _fusionar_estructuras_carpetas(
                normativa_consolidada["estructura_carpetas_comun"],
                est_comun
            )

        # 4. Consolidar cada tipo de proyecto descubierto
        proyectos_lote = datos_lote.get("proyectos", {})
        if isinstance(proyectos_lote, dict):
            for sigla_bruta, info_proy in proyectos_lote.items():
                if not isinstance(info_proy, dict):
                    continue
                sigla = str(sigla_bruta).strip().upper()
                if not sigla or sigla in ("SIGLAS_DEL_PROYECTO", "NULL", "NONE"):
                    continue

                plantilla_raw = _limpiar_plantilla_codigo(info_proy.get("plantilla_nombre") or "")
                plantilla_cod, _ = _separar_codigo_y_descripcion(plantilla_raw)
                plantilla_valida = (
                    plantilla_cod
                    if plantilla_cod and plantilla_cod not in ("...", "PLANTILLA_DETECTADA", "null", "None")
                    else f"INE_{sigla}_FT_AAAAMMDD"
                )

                # Filtrar entradas vacías ficticias de '_RAIZ_' si vienen con placeholder del ejemplo
                est_proy_raw = info_proy.get("estructura_carpetas", {})
                est_proy_limpia = _fusionar_estructuras_carpetas({}, est_proy_raw if isinstance(est_proy_raw, dict) else {})
                for k_r in list(est_proy_limpia.keys()):
                    if k_r.strip().lower() in _CLAVES_CARPETA_RAIZ and not est_proy_limpia[k_r]:
                        del est_proy_limpia[k_r]

                if sigla not in normativa_consolidada["proyectos"]:
                    normativa_consolidada["proyectos"][sigla] = {
                        "plantilla_nombre": plantilla_valida,
                        "estructura_carpetas": est_proy_limpia
                    }
                    if info_proy.get("nombre_completo"):
                        normativa_consolidada["proyectos"][sigla]["nombre_completo"] = str(info_proy["nombre_completo"]).strip()
                else:
                    proy_actual = normativa_consolidada["proyectos"][sigla]
                    if plantilla_cod and plantilla_cod not in ("...", "PLANTILLA_DETECTADA", "null", "None"):
                        proy_actual["plantilla_nombre"] = plantilla_cod
                    if info_proy.get("nombre_completo") and "nombre_completo" not in proy_actual:
                        proy_actual["nombre_completo"] = str(info_proy["nombre_completo"]).strip()
                    proy_actual["estructura_carpetas"] = _fusionar_estructuras_carpetas(
                        proy_actual.get("estructura_carpetas", {}),
                        est_proy_limpia
                    )

    if bloques_exitosos == 0:
        raise RuntimeError(
            f"No se pudo procesar ningún bloque del boletín normativo mediante el LLM: {ultimo_error_llm}"
        )

    # Aplicar las carpetas comunes descubiertas en el boletín a todas las figuras registradas
    if normativa_consolidada["estructura_carpetas_comun"]:
        for sigla, datos_p in normativa_consolidada["proyectos"].items():
            datos_p["estructura_carpetas"] = _fusionar_estructuras_carpetas(
                normativa_consolidada["estructura_carpetas_comun"],
                datos_p.get("estructura_carpetas", {})
            )

    lim_inf, fmt_inf = _inferir_reglas_generales_de_texto_pdf(paginas_con_texto)
    if not normativa_consolidada["limite_peso_general_mb"]:
        normativa_consolidada["limite_peso_general_mb"] = lim_inf or 50
    if not normativa_consolidada["formato_division"]:
        normativa_consolidada["formato_division"] = fmt_inf or "09_99"

    return normativa_consolidada


def extraer_proyecto_especifico_de_boja(tipo_proyecto, ruta_pdf):
    """
    Rastrea el PDF normativo buscando la definición, carpetas y archivos de unas siglas concretas
    cuando el usuario solicita un tipo de instrumento que no figuraba aún en `boja_base.json`.
    """
    if ruta_pdf and os.path.isfile(ruta_pdf):
        try:
            paginas = [
                p.page_content
                for p in cargar_pdf_con_ocr(ruta_pdf, incluir_cabecera_documento=False)
                if p.page_content and p.page_content.strip()
            ]
            relevantes = [
                txt for txt in paginas
                if tipo_proyecto.lower() in txt.lower()
                or "estructura" in txt.lower()
                or "carpeta" in txt.lower()
                or "fichero" in txt.lower()
                or "archivo" in txt.lower()
            ]
            bloque = "\n\n".join(relevantes) if relevantes else "\n\n".join(paginas)
            plantilla_proy = ChatPromptTemplate.from_messages([
                ("system", """Extrae del siguiente texto normativo la plantilla de nombre y la estructura completa de carpetas y tipos de archivos para el proyecto urbanístico '{tipo_proyecto}'.
                Conserva los marcadores oficiales (ej. INE, AMB, FT, AAAAMMDD) y usa "_RAIZ_" si hay ficheros en la carpeta raíz sin subcarpeta.
                Devuelve ÚNICAMENTE un objeto JSON válido con esta estructura:
                {{
                  "plantilla_nombre": "INE_{tipo_proyecto}_FT_AAAAMMDD",
                  "estructura_carpetas": {{
                    "NOMBRE_CARPETA": ["CODIGO_ARCHIVO_1 | Descripción", "CODIGO_ARCHIVO_2 | Descripción"]
                  }}
                }}
                Texto: {bloque_texto}""")
            ])
            resp = (plantilla_proy | _obtener_llm() | StrOutputParser()).invoke({
                "tipo_proyecto": tipo_proyecto,
                "bloque_texto": bloque[:45000]
            })
            datos_proy = _extraer_json_de_texto(resp)
            if isinstance(datos_proy, dict) and "plantilla_nombre" in datos_proy:
                cod_p, _ = _separar_codigo_y_descripcion(datos_proy.get("plantilla_nombre") or "")
                datos_proy["plantilla_nombre"] = cod_p or f"INE_{tipo_proyecto}_FT_AAAAMMDD"
                est = datos_proy.get("estructura_carpetas")
                datos_proy["estructura_carpetas"] = _fusionar_estructuras_carpetas({}, est if isinstance(est, dict) else {})
                return datos_proy
        except Exception as e:
            _imprimir(f"   ⚠️ Aviso buscando '{tipo_proyecto}' en el PDF normativo: {e}")

    return {
        "plantilla_nombre": f"INE_{tipo_proyecto}_FT_AAAAMMDD",
        "estructura_carpetas": {}
    }


def extraer_boja_de_local(ruta_pdf):
    """Localiza el boletín PDF, ejecuta su análisis completo por única vez y persiste `boja_base.json`."""
    ruta_real = _localizar_pdf_boja(ruta_pdf)
    if not ruta_real:
        raise FileNotFoundError("No se encontró el archivo PDF del boletín normativo.")

    boja_extraido = analizar_documento_completo_y_extraer_normativa(ruta_real)
    _guardar_json_atomico(ARCHIVO_BOJA, boja_extraido)
    _imprimir(f"   💾 '{ARCHIVO_BOJA}' generado dinámicamente tras leer todo el documento y guardado por el Agente 2.")
    return boja_extraido


# --- GESTIÓN PERSISTENTE DE NORMATIVAS DE AYUNTAMIENTOS (INTRODUCIDAS A MANO) ---
def cargar_normativas_ayuntamientos():
    """Lee el diccionario persistente `normativas_ayuntamientos.json` (o `{}` si no existe o está dañado)."""
    if os.path.exists(ARCHIVO_AYUNTAMIENTOS):
        try:
            with open(ARCHIVO_AYUNTAMIENTOS, "r", encoding="utf-8") as f:
                datos = json.load(f)
                return datos if isinstance(datos, dict) else {}
        except Exception:
            return {}
    return {}


def guardar_normativa_ayuntamiento(municipio, limite_mb):
    """Guarda permanentemente el límite máximo de peso en MB exigido por un ayuntamiento."""
    clave = _normalizar(municipio)
    if not clave:
        raise ValueError("El nombre del municipio no es válido.")
    limite_entero = _extraer_primer_entero(limite_mb, por_defecto=0)
    if limite_entero <= 0:
        raise ValueError(f"El límite de peso en MB debe ser un entero mayor que 0 (recibido: {limite_mb}).")

    datos = cargar_normativas_ayuntamientos()
    datos[clave] = {
        "municipio": str(municipio).strip(),
        "limite_peso_mb": limite_entero
    }
    _guardar_json_atomico(ARCHIVO_AYUNTAMIENTOS, datos)
    _imprimir(f"   💾 Normativa del Ayuntamiento de {municipio} ({limite_entero} MB) guardada permanentemente en '{ARCHIVO_AYUNTAMIENTOS}'.")


def obtener_limite_guardado_ayuntamiento(municipio):
    """Consulta si un municipio ya tiene límite de peso registrado en `normativas_ayuntamientos.json`."""
    clave = _normalizar(municipio)
    if not clave:
        return None
    datos = cargar_normativas_ayuntamientos()
    if clave in datos and isinstance(datos[clave], dict) and "limite_peso_mb" in datos[clave]:
        limite = _extraer_primer_entero(datos[clave]["limite_peso_mb"], por_defecto=0)
        return limite if limite > 0 else None
    return None


def consultar_normativa_local(municipio):
    """
    Busca en `./bd_normativas` fragmentos de ordenanzas locales correspondientes al municipio,
    evitando errores HNSW de Chroma cuando `k` supera el número de documentos y liberando SQLite al salir.
    """
    muni_norm = _normalizar(municipio)
    if not muni_norm or not os.path.exists(RUTA_BD_LEGAL) or Chroma is None:
        return "NO_HAY_REGLAS_LOCALES"

    base_de_datos = None
    try:
        modelo_coordenadas = None
        if OllamaEmbeddings is not None:
            try:
                modelo_coordenadas = OllamaEmbeddings(model="nomic-embed-text")
            except Exception:
                modelo_coordenadas = None

        base_de_datos = Chroma(persist_directory=RUTA_BD_LEGAL, embedding_function=modelo_coordenadas)

        # 1. Consulta directa de metadatos en SQLite (inmune al fallo HNSW cuando k > documentos del municipio)
        textos_muni = []
        try:
            guardados_muni = base_de_datos.get(where={"municipio": muni_norm}) or {}
            textos_muni = [
                t for t in (guardados_muni.get("documents") or [])
                if isinstance(t, str) and t.strip()
            ]
        except Exception:
            textos_muni = []

        if textos_muni:
            if len(textos_muni) <= 3 or modelo_coordenadas is None:
                return "\n".join(textos_muni[:3])
            try:
                recuperador = base_de_datos.as_retriever(
                    search_kwargs={"k": min(3, len(textos_muni)), "filter": {"municipio": muni_norm}}
                )
                documentos = recuperador.invoke("límite peso megabytes mb máximo archivo") or []
                contexto = "\n".join([doc.page_content for doc in documentos if doc.page_content])
                if contexto.strip():
                    return contexto
            except Exception:
                return "\n".join(textos_muni[:3])

        # 2. Respaldo de búsqueda semántica general filtrando por mención al municipio
        if modelo_coordenadas is not None:
            try:
                docs_sem = base_de_datos.similarity_search(
                    f"Ayuntamiento de {municipio} límite peso megabytes mb máximo archivo", k=3
                )
                relevantes = [
                    doc.page_content for doc in docs_sem
                    if doc.page_content and (
                        muni_norm in _normalizar(doc.page_content)
                        or muni_norm in _normalizar((doc.metadata or {}).get("archivo_origen", ""))
                    )
                ]
                if relevantes:
                    return "\n".join(relevantes)
            except Exception:
                pass

        return "NO_HAY_REGLAS_LOCALES"
    except Exception:
        return "NO_HAY_REGLAS_LOCALES"
    finally:
        if base_de_datos is not None:
            del base_de_datos
        gc.collect()


def _extraer_limite_mb_de_texto_respuesta(texto, por_defecto):
    """Prioriza números explícitamente asociados a MB/Megabytes antes de usar el primer entero aislado."""
    if not texto:
        return por_defecto
    cadena = str(texto).strip()
    # Evitar confundir números de artículo ("Artículo 12: máximo 20 MB") priorizando el número seguido de 'MB'
    cadena_positiva = re.sub(r"-\s*\d+(?:[.,]\d+)?(?:\s*(?:mb|megabytes?|megas?))?", " ", cadena, flags=re.IGNORECASE)
    m_mb = re.search(
        r"(?<![-\d.,])(\d+)(?:[.,]\d+)?[\s_]*(?:mb|megabytes?|megas?)(?![a-zA-Z])",
        cadena_positiva,
        flags=re.IGNORECASE,
    )
    if m_mb:
        val = int(m_mb.group(1))
        if val > 0:
            return val
    return _extraer_primer_entero(cadena_positiva, por_defecto=por_defecto)


def contrastar_excepciones(municipio, contexto_local, limite_boja):
    """Compara mediante el LLM (con respaldo regex) el límite local frente al límite general autonómico."""
    limite_boja_int = _extraer_primer_entero(limite_boja, por_defecto=50)
    try:
        if not LANGCHAIN_DISPONIBLE or ChatPromptTemplate is None or StrOutputParser is None:
            raise ImportError("Dependencias de LangChain no disponibles")
        plantilla = ChatPromptTemplate.from_messages([
            ("system", """El límite general es {limite_boja} MB.
            Lee las normas locales. Si exige un límite DIFERENTE y más restrictivo, devuelve ÚNICAMENTE ese número (ej. 15).
            Si no, devuelve ÚNICAMENTE {limite_boja}. No incluyas explicaciones.
            Contexto local: {contexto_local}""")
        ])
        respuesta = (plantilla | _obtener_llm() | StrOutputParser()).invoke({
            "limite_boja": limite_boja_int,
            "municipio": municipio,
            "contexto_local": contexto_local
        })
        return _extraer_limite_mb_de_texto_respuesta(respuesta, por_defecto=limite_boja_int)
    except Exception as e:
        _imprimir(f"   ⚠️ Aviso al contrastar normativa local con LLM ({e}). Aplicando extracción directa de respaldo.")
        return _extraer_limite_mb_de_texto_respuesta(contexto_local, por_defecto=limite_boja_int)


def ejecutar_agente_2(municipio, tipo_proyecto, ruta_boja_pdf=None, limite_manual_mb=None):
    """
    Punto de entrada principal del Agente 2:
    1. Carga `boja_base.json` (o escanea por única vez el PDF del boletín autonómico si aún no existe).
    2. Obtiene la plantilla y estructura de carpetas del `tipo_proyecto` solicitado.
    3. Resuelve el límite de peso municipal desde `limite_manual_mb`, `normativas_ayuntamientos.json`
       o `./bd_normativas` (solicitándolo al usuario con `REQUIERE_LIMITE_MANUAL` solo la primera vez).
    """
    municipio = str(municipio or "").strip()
    tipo_proyecto = str(tipo_proyecto or "").strip().upper()
    if not _normalizar(municipio) or not _normalizar(tipo_proyecto):
        return {"estado": "ERROR", "mensaje": "El municipio y el tipo de proyecto son obligatorios y deben ser válidos."}

    _imprimir(f"⚖️ [Agente 2] Auditando normativa para el municipio: {municipio} (Proyecto: {tipo_proyecto})...")

    boja_datos = None
    if os.path.exists(ARCHIVO_BOJA):
        try:
            with open(ARCHIVO_BOJA, "r", encoding="utf-8") as f:
                cargado = json.load(f)
                if isinstance(cargado, dict) and isinstance(cargado.get("proyectos"), dict):
                    boja_datos = cargado
        except Exception as e:
            _imprimir(f"   ⚠️ '{ARCHIVO_BOJA}' corrupto o ilegible ({e}). Se regenerará leyendo el PDF normativo.")

    if boja_datos is None:
        ruta_boja_real = _localizar_pdf_boja(ruta_boja_pdf)
        if not ruta_boja_real:
            return {
                "estado": "REQUIERE_BOJA_PDF",
                "mensaje": "No existe boja_base.json válido y se requiere la ruta al PDF del boletín autonómico para generarlo."
            }
        try:
            boja_datos = extraer_boja_de_local(ruta_boja_real)
        except Exception as e:
            return {"estado": "ERROR", "mensaje": f"Fallo al generar boja_base.json desde el PDF: {e}"}

    if "proyectos" not in boja_datos or not isinstance(boja_datos["proyectos"], dict):
        boja_datos["proyectos"] = {}

    if tipo_proyecto not in boja_datos["proyectos"] or not isinstance(boja_datos["proyectos"].get(tipo_proyecto), dict):
        _imprimir(f"   🔍 El proyecto '{tipo_proyecto}' no figuraba en caché. Extrayendo del boletín oficial y actualizando '{ARCHIVO_BOJA}'...")
        ruta_origen = boja_datos.get("ruta_pdf_origen") or _localizar_pdf_boja(ruta_boja_pdf)
        nuevo_proy = extraer_proyecto_especifico_de_boja(tipo_proyecto, ruta_origen)
        if boja_datos.get("estructura_carpetas_comun"):
            nuevo_proy["estructura_carpetas"] = _fusionar_estructuras_carpetas(
                boja_datos["estructura_carpetas_comun"],
                nuevo_proy.get("estructura_carpetas", {})
            )
        boja_datos["proyectos"][tipo_proyecto] = nuevo_proy
        try:
            _guardar_json_atomico(ARCHIVO_BOJA, boja_datos)
        except OSError:
            pass

    reglas_proyecto = copy.deepcopy(boja_datos["proyectos"][tipo_proyecto])
    if "plantilla_nombre" in reglas_proyecto:
        cod_limpio, _ = _separar_codigo_y_descripcion(reglas_proyecto.get("plantilla_nombre") or "")
        reglas_proyecto["plantilla_nombre"] = cod_limpio or f"INE_{tipo_proyecto}_FT_AAAAMMDD"

    limite_boja = _extraer_primer_entero(boja_datos.get("limite_peso_general_mb"), por_defecto=50)
    formato_div = str(boja_datos.get("formato_division") or "09_99").strip()

    # Prioridad 1: Nuevo límite manual proporcionado por el usuario -> se persiste para siempre
    if limite_manual_mb is not None:
        limite_manual_int = _extraer_primer_entero(limite_manual_mb, por_defecto=0)
        if limite_manual_int <= 0:
            return {"estado": "REQUIERE_LIMITE_MANUAL", "mensaje": "El límite manual debe ser mayor que 0 MB."}
        guardar_normativa_ayuntamiento(municipio, limite_manual_int)
        limite_final = min(limite_boja, limite_manual_int)
        return {
            "estado": "COMPLETADO",
            "reglas_empaquetado": {
                "limite_peso_mb": str(limite_final),
                "formato_division": formato_div
            },
            "reglas_identidad": reglas_proyecto
        }

    # Prioridad 2: Límite ya almacenado previamente en `normativas_ayuntamientos.json`
    limite_guardado = obtener_limite_guardado_ayuntamiento(municipio)
    if limite_guardado is not None:
        _imprimir(f"   ✅ Normativa del Ayuntamiento de {municipio} recuperada de memoria ('{ARCHIVO_AYUNTAMIENTOS}'): {limite_guardado} MB.")
        limite_final = min(limite_boja, limite_guardado)
        return {
            "estado": "COMPLETADO",
            "reglas_empaquetado": {
                "limite_peso_mb": str(limite_final),
                "formato_division": formato_div
            },
            "reglas_identidad": reglas_proyecto
        }

    # Prioridad 3: Búsqueda en `./bd_normativas` (si se indexó una ordenanza PDF de ese ayuntamiento)
    contexto_ayuntamiento = consultar_normativa_local(municipio)
    if contexto_ayuntamiento == "NO_HAY_REGLAS_LOCALES":
        return {"estado": "REQUIERE_LIMITE_MANUAL", "mensaje": f"Falta límite local para {municipio}"}

    limite_extraido = contrastar_excepciones(municipio, contexto_local=contexto_ayuntamiento, limite_boja=limite_boja)
    limite_final = min(limite_boja, limite_extraido)
    guardar_normativa_ayuntamiento(municipio, limite_final)

    return {
        "estado": "COMPLETADO",
        "reglas_empaquetado": {
            "limite_peso_mb": str(limite_final),
            "formato_division": formato_div
        },
        "reglas_identidad": reglas_proyecto
    }
