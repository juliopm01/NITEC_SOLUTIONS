"""
Módulo: agente_1_extractor.py (Agente 1 — Documentalista y Clasificador OCR)
================================================================================
Propósito general:
    Representa la primera línea de trabajo del sistema multi-agente NITEC para
    proyectos de arquitectura, ingeniería y urbanismo. Cumple dos misiones clave:
      1. Extracción de metadatos legales del proyecto (`extraer_metadatos`):
         Mediante búsqueda híbrida (Vectorial ChromaDB + Léxica BM25) y un LLM
         local (`llama3.1`), localiza y valida rigurosamente la Fase de Tramitación
         (`FT`: `AI`, `AP`, `AD`, `TR`, `AV`, `MOD`) y la Fecha de Aprobación
         (`AAAAMMDD` comprobada contra el calendario gregoriano real), además de
         inferir el código de ámbito urbanístico (`AMB`, p. ej. `UE01`, `SUP2`).
      2. Inspección multiformato con lectura de imágenes (OCR) y clasificación
         integral de todos los archivos del proyecto (`clasificar_archivos_proyecto`):
         Lee PDFs con planos/imágenes, imágenes sueltas (`.png`, `.jpg`, `.tif`),
         capas geográficas SIG (`.gpkg`, `.shp`), CAD (`.dwg`, `.dxf`) y metadatos
         (`.txt`, `.xml`), clasificándolos frente al catálogo normativo dinámico
         del Agente 2 y generando atómicamente `especificaciones_agente_1.json`
         para su reorganización y empaquetado por el Agente 3.
================================================================================
"""

import ast
import datetime
import gc
import json
import os
import re
import sys
import tempfile
import unicodedata

# Importación tolerante a entornos parciales de LangChain / Ollama / BM25
try:
    from langchain_chroma import Chroma
    from langchain_ollama import OllamaEmbeddings, ChatOllama
    from langchain_core.prompts import ChatPromptTemplate
    from langchain_core.output_parsers import StrOutputParser
    from langchain_core.documents import Document
    from langchain_community.retrievers import BM25Retriever
    LANGCHAIN_DISPONIBLE = True
except Exception:
    Chroma = None
    OllamaEmbeddings = None
    ChatOllama = None
    ChatPromptTemplate = None
    StrOutputParser = None
    BM25Retriever = None
    LANGCHAIN_DISPONIBLE = False
    from lector_ocr_pdf import Document

from lector_ocr_pdf import cargar_pdf_con_ocr, _ejecutar_ocr_sobre_bytes_imagen

try:
    from agente_2_normativo_local import construir_catalogo_documental
except Exception:
    construir_catalogo_documental = None

# Rutas base del módulo y nombre estándar del archivo JSON que consume el Agente 3
DIRECTORIO_BASE = os.path.dirname(os.path.abspath(__file__))
RUTA_BD_PROYECTO = os.path.join(DIRECTORIO_BASE, "bd_vectores")
NOMBRE_JSON_ESPECIFICACIONES = "especificaciones_agente_1.json"

# Directorios internos ignorados al escanear carpetas de proyecto para evitar bucles
_CARPETAS_EXCLUIDAS = {
    ".git", "__pycache__", "bd_vectores", "bd_normativas",
    "normativas_pdf", "partes_divididas", "salida_empaquetada",
}

# Clasificación técnica de extensiones habituales en entregas de arquitectura, ingeniería y urbanismo
_EXTENSIONES_IMAGEN = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}
_EXTENSIONES_SIG = {
    ".gpkg", ".shp", ".shx", ".dbf", ".prj", ".cpg", ".qpj",
    ".qml", ".sld", ".gml", ".geojson", ".kml", ".kmz",
}
_EXTENSIONES_CAD = {".dwg", ".dxf", ".dgn"}
_EXTENSIONES_METADATOS = {".txt", ".xml", ".csv", ".md"}

# Prompt del sistema para extracción estricta de fase de tramitación y fecha de aprobación
_SISTEMA_EXTRACTOR = """Eres el Agente Documentalista (Rastreador Implacable).
    Tu objetivo es extraer dos datos legales específicos del proyecto urbanístico basándote ÚNICAMENTE en el contexto proporcionado.
    
    Reglas estrictas:
    1. Fase de Tramitación: Detecta la fase (ej. AI para Aprobación Inicial, AD para Aprobación Definitiva, AP para Aprobación Provisional).
    2. Fecha de aprobación: Formato AAAAMMDD. Busca ÚNICAMENTE fechas ligadas a firmas oficiales, 'Acuerdo de Pleno', 'Resolución' o 'Aprobación'. Ignora explícitamente fechas de topografías, mediciones o certificados antiguos.
    3. Si tras analizar el contexto el dato no existe, debes escribir estrictamente el valor "NO_ENCONTRADA".
    
    Contexto extraído de los documentos:
    {context}
    
    Tu respuesta DEBE ser EXCLUSIVAMENTE un objeto JSON válido. No incluyas texto antes ni después. No saludes ni uses markdown.
    Usa estrictamente esta estructura:
    {{
        "fase_tramitacion": "valor_o_NO_ENCONTRADA",
        "fecha_aprobacion": "valor_o_NO_ENCONTRADA"
    }}"""

# Prompt del sistema para asignación semántica de archivos al catálogo dinámico del boletín oficial
_SISTEMA_CLASIFICADOR_PROYECTO = """Eres el Agente Documentalista Clasificador de Proyectos de Arquitectura, Ingeniería y Urbanismo.
    Tu misión es asignar cada archivo del proyecto al destino documental más adecuado dentro del catálogo normativo proporcionado, basándote en su nombre, subcarpeta original, extensión, presencia de planos/imágenes y texto extraído (incluyendo OCR sobre imágenes y cartelas de planos).

    Catálogo de destinos disponibles:
    {catalogo_texto}

    Archivos inspeccionados del proyecto:
    {archivos_texto}

    Devuelve EXCLUSIVAMENTE un objeto JSON válido asociando el índice numérico (como clave string) de cada archivo con el `id_destino` elegido del catálogo:
    {{
        "clasificaciones": {{
            "1": "D01",
            "2": "D02"
        }}
    }}"""

plantilla = ChatPromptTemplate.from_messages([("system", _SISTEMA_EXTRACTOR)]) if ChatPromptTemplate else None

# Instancias perezosas (lazy) del modelo LLM y de la cadena de extracción para no bloquear la importación
llm = None
cadena = None

# Diccionario de meses en español (completos y abreviados) para normalizar fechas textuales a AAAAMMDD
_MESES_ES = {
    "enero": 1, "ene": 1,
    "febrero": 2, "feb": 2,
    "marzo": 3, "mar": 3,
    "abril": 4, "abr": 4,
    "mayo": 5, "may": 5,
    "junio": 6, "jun": 6,
    "julio": 7, "jul": 7,
    "agosto": 8, "ago": 8,
    "septiembre": 9, "setiembre": 9, "sep": 9, "sept": 9,
    "octubre": 10, "oct": 10,
    "noviembre": 11, "nov": 11,
    "diciembre": 12, "dic": 12,
}

# Conjunto de marcadores nulos o placeholders devueltos habitualmente por modelos LLM cuando falta un dato
_VALORES_NULOS = {
    "", "null", "none", "n/a", "na", "no_encontrada", "no encontrada",
    "no_encontrado", "no encontrado", "desconocida", "desconocido",
    "valor_o_no_encontrada", "aaaammdd", "sin_fecha", "sin fecha",
    "sin_datos", "sin datos", "no consta", "pendiente", "false", "true",
}

# Afinidades léxicas y técnicas generales para proyectos de arquitectura, ingeniería y urbanismo
# (independientes de cualquier estructura de carpetas concreta)
_AFINIDADES_CATEGORIA_TOKENS = {
    "INDICE_GENERAL": {"indice", "diligencia", "contenido", "relacion", "in", "00"},
    "MEMORIA_INFORMACION": {"memoria", "informacion", "diagnostico", "analisis", "estado", "actual", "mi"},
    "MEMORIA_PARTICIPACION": {"memoria", "participacion", "ciudadana", "alegaciones", "consulta", "informacion_publica", "mp"},
    "MEMORIA_ORDENACION": {"memoria", "ordenacion", "justificativa", "propuesta", "descriptiva", "mo"},
    "MEMORIA_ECONOMICA": {"memoria", "economica", "sostenibilidad", "viabilidad", "financiero", "presupuesto", "estudio_economico", "me"},
    "MEMORIA_GENERAL": {"memoria", "descriptiva", "justificativa", "proyecto", "m"},
    "NORMATIVA_URBANISTICA": {"normativa", "normas", "urbanisticas", "ordenanzas", "articulado", "regulacion", "nu"},
    "CARTOGRAFIA_INFORMACION": {"plano", "planos", "cartografia", "informacion", "topografico", "estado_actual", "afecciones", "ci", "ca"},
    "CARTOGRAFIA_ORDENACION": {"plano", "planos", "cartografia", "ordenacion", "estructural", "pormenorizada", "zonificacion", "alineaciones", "rasantes", "estructura", "co", "ca"},
    "PLANO_ARQUITECTURA_INGENIERIA": {"plano", "planos", "cartografia", "planta", "alzado", "seccion", "instalaciones", "estructura", "ca", "co", "ci"},
    "CATALOGO_MEMORIA": {"catalogo", "proteccion", "patrimonio", "bienes", "memoria", "ct", "mj", "md"},
    "CATALOGO_FICHAS": {"catalogo", "fichas", "ficha", "inventario", "bienes", "protegidos", "ct", "fi"},
    "CATALOGO_PLANOS": {"catalogo", "plano", "planos", "cartografia", "proteccion", "ct", "cp"},
    "RESUMEN_EJECUTIVO": {"resumen", "ejecutivo", "sintesis", "delimitacion", "suspension", "re"},
    "ACTUACIONES_TRANSFORMACION": {"actuacion", "actuaciones", "transformacion", "urbanistica", "suelo", "atusr", "atusu"},
    "ANEXO_TECNICO": {"anexo", "anexos", "estudio", "ambiental", "eae", "hidrologico", "inundabilidad", "acustico", "trafico", "movilidad", "geotecnico", "arqueologico", "impacto", "salud", "an", "an01"},
    "DATOS_ESPACIALES_SIG": {"situ", "geografica", "vectorial", "sig", "gis", "gpkg", "shp", "geopackage", "shapefile", "delimitacion"},
    "METADATOS": {"meta", "metadatos", "metadata", "iso", "19115", "txt", "xml"},
    "OTROS_DOCUMENTOS": {"documento", "documentacion", "general"},
}

# Palabras funcionales vacías excluidas al tokenizar nombres y descripciones documentales
_STOPWORDS_ES = {
    "de", "del", "la", "las", "el", "los", "en", "y", "o", "a", "con", "sin",
    "por", "para", "un", "una", "pdf", "doc", "documento", "archivo", "fichero",
    "ine", "ft", "aaaammdd", "amb", "tip", "proyecto",
}


def _imprimir(mensaje):
    """Imprime de forma segura en consolas Windows cp1252 o flujos redirigidos."""
    try:
        print(mensaje)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        seguro = str(mensaje).encode(enc, errors="replace").decode(enc, errors="replace")
        print(seguro)


def _guardar_json_atomico(ruta_archivo, datos):
    """Guarda un diccionario en formato JSON UTF-8 de manera atómica (`mkstemp` + `os.replace`)."""
    carpeta = os.path.dirname(os.path.abspath(ruta_archivo))
    os.makedirs(carpeta, exist_ok=True)
    fd, ruta_tmp = tempfile.mkstemp(prefix=".tmp_ag1_", suffix=".json", dir=carpeta)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(datos, f, ensure_ascii=False, indent=2)
        os.replace(ruta_tmp, ruta_archivo)
    except Exception:
        if os.path.exists(ruta_tmp):
            try:
                os.unlink(ruta_tmp)
            except OSError:
                pass
        raise


def _obtener_cadena():
    """Construye e inicializa bajo demanda la cadena LangChain (`ChatPromptTemplate | ChatOllama | StrOutputParser`)."""
    global llm, cadena, plantilla
    if cadena is not None:
        return cadena
    if not LANGCHAIN_DISPONIBLE or ChatOllama is None or ChatPromptTemplate is None:
        raise ImportError("Faltan dependencias de LangChain/Ollama. Ejecuta: pip install -r requirements.txt")
    if plantilla is None:
        plantilla = ChatPromptTemplate.from_messages([("system", _SISTEMA_EXTRACTOR)])
    if llm is None:
        llm = ChatOllama(model="llama3.1", temperature=0, num_ctx=16000)
    cadena = plantilla | llm | StrOutputParser()
    return cadena


def _obtener_llm_agente_1():
    """Devuelve la instancia singleton de `ChatOllama` para clasificación documental bajo demanda."""
    global llm
    if llm is None:
        if not LANGCHAIN_DISPONIBLE or ChatOllama is None:
            raise ImportError("Faltan dependencias de LangChain/Ollama.")
        llm = ChatOllama(model="llama3.1", temperature=0, num_ctx=16000)
    return llm


def _quitar_tildes(texto):
    """Elimina tildes y diacríticos conservando el resto de caracteres ASCII/alfanuméricos."""
    return "".join(
        c for c in unicodedata.normalize("NFD", str(texto))
        if unicodedata.category(c) != "Mn"
    )


def _tokenizar(texto):
    """Divide un texto en tokens alfanuméricos en minúsculas sin tildes ni stopwords."""
    limpio = _quitar_tildes(str(texto or "")).lower()
    partes = re.split(r"[^a-z0-9]+", limpio)
    return [p for p in partes if p and p not in _STOPWORDS_ES]


def _bd_corresponde_a_proyecto(docs_memoria, ruta_pdf_respaldo):
    """
    Verifica que los documentos almacenados en bd_vectores no pertenezcan exclusivamente
    a un proyecto antiguo distinto al PDF solicitado explícitamente.
    """
    if not ruta_pdf_respaldo:
        return True

    ruta_abs_pdf = os.path.normcase(os.path.abspath(ruta_pdf_respaldo))
    carpeta_pdf = os.path.normcase(os.path.dirname(ruta_abs_pdf))

    # 1. Comprobación prioritaria mediante el sello `carpeta_proyecto` grabado por `creador_base_vectores.py`
    carpetas_proyecto = [
        os.path.normcase(os.path.abspath(str(d.metadata.get("carpeta_proyecto")).strip()))
        for d in docs_memoria
        if isinstance(d.metadata, dict) and str(d.metadata.get("carpeta_proyecto") or "").strip()
    ]
    for c_proy in carpetas_proyecto:
        if carpeta_pdf == c_proy or ruta_abs_pdf.startswith(c_proy + os.sep):
            return True
    if carpetas_proyecto:
        return False

    # 2. Respaldo por rutas `source` individuales si la BD proviene de una ingesta sin sello de carpeta
    fuentes = [
        str(d.metadata.get("source", "")).strip()
        for d in docs_memoria
        if isinstance(d.metadata, dict) and str(d.metadata.get("source", "")).strip()
    ]
    if not fuentes:
        return True

    for f in fuentes:
        f_abs = os.path.normcase(os.path.abspath(f))
        f_dir = os.path.normcase(os.path.dirname(f_abs))
        if (
            f_abs == ruta_abs_pdf
            or f_dir == carpeta_pdf
            or f_dir.startswith(carpeta_pdf + os.sep)
            or carpeta_pdf.startswith(f_dir + os.sep)
        ):
            return True
    return False


def buscar_fusion_hibrida(pregunta, ruta_pdf_respaldo=None):
    """
    Se conecta a bd_vectores bajo demanda, realiza la búsqueda híbrida (Vectorial + BM25)
    aislando fallos entre motores y libera inmediatamente el archivo SQLite.
    """
    if ruta_pdf_respaldo:
        ruta_pdf_respaldo = str(ruta_pdf_respaldo).strip().strip('"').strip("'")

    documentos_fusion = []
    if os.path.exists(RUTA_BD_PROYECTO) and Chroma is not None:
        base_de_datos = None
        try:
            modelo_coordenadas = None
            if OllamaEmbeddings is not None:
                try:
                    modelo_coordenadas = OllamaEmbeddings(model="nomic-embed-text")
                except Exception as e_emb:
                    _imprimir(f"   ⚠️ Aviso al inicializar embeddings en Agente 1: {e_emb}")

            base_de_datos = Chroma(
                persist_directory=RUTA_BD_PROYECTO,
                embedding_function=modelo_coordenadas
            )

            datos_guardados = base_de_datos.get() or {}
            textos_completos = datos_guardados.get("documents") or []
            metadatos_raw = datos_guardados.get("metadatas")
            if not isinstance(metadatos_raw, list):
                metadatos = [{} for _ in textos_completos]
            else:
                metadatos = [
                    (m if isinstance(m, dict) else {})
                    for m in metadatos_raw
                ]
                if len(metadatos) < len(textos_completos):
                    metadatos.extend({} for _ in range(len(textos_completos) - len(metadatos)))

            docs_memoria = [
                Document(page_content=txt, metadata=meta)
                for txt, meta in zip(textos_completos, metadatos)
                if isinstance(txt, str) and txt.strip()
            ]

            # Solo consultar la BD si pertenece al proyecto activo (impide mezclar expedientes anteriores)
            if docs_memoria and _bd_corresponde_a_proyecto(docs_memoria, ruta_pdf_respaldo):
                # Ajustar k dinámicamente al total real de documentos para evitar fallos HNSW en Chroma
                k_busqueda = max(1, min(4, len(docs_memoria)))
                docs_v = []
                docs_p = []

                # Motor 1: Similitud semántica vectorial (OllamaEmbeddings + Chroma)
                if modelo_coordenadas is not None:
                    try:
                        recuperador_vectores = base_de_datos.as_retriever(search_kwargs={"k": k_busqueda})
                        docs_v = recuperador_vectores.invoke(pregunta) or []
                    except Exception as e_vec:
                        _imprimir(f"   ⚠️ Aviso en búsqueda vectorial de Agente 1 (usando respaldo BM25): {e_vec}")

                # Motor 2: Coincidencia léxica exacta BM25 (clave para siglas como 'AD', 'AI', 'Pleno')
                if BM25Retriever is not None:
                    try:
                        recuperador_palabras = BM25Retriever.from_documents(docs_memoria)
                        recuperador_palabras.k = k_busqueda
                        docs_p = recuperador_palabras.invoke(pregunta) or []
                    except Exception as e_bm25:
                        _imprimir(f"   ⚠️ Aviso en búsqueda BM25 de Agente 1: {e_bm25}")
                elif not docs_v:
                    docs_p = docs_memoria[:k_busqueda]

                # Fusión deduplicada preservando el orden de relevancia
                textos_vistos = set()
                for doc in list(docs_v) + list(docs_p):
                    contenido = (doc.page_content or "").strip()
                    if contenido and contenido not in textos_vistos:
                        documentos_fusion.append(doc)
                        textos_vistos.add(contenido)
        except Exception as e:
            _imprimir(f"   ⚠️ Aviso al consultar base vectorial en Agente 1: {e}")
        finally:
            if base_de_datos is not None:
                del base_de_datos
            gc.collect()

    # Respaldo directo: si no existe `bd_vectores` o pertenece a otro proyecto, leer directamente el PDF con OCR
    if not documentos_fusion and ruta_pdf_respaldo and os.path.isfile(ruta_pdf_respaldo):
        try:
            paginas = [
                p for p in cargar_pdf_con_ocr(ruta_pdf_respaldo, incluir_cabecera_documento=False)
                if p.page_content and p.page_content.strip()
            ]
            documentos_fusion = paginas[:4]
        except Exception as e:
            _imprimir(f"   ⚠️ Error en lectura de respaldo PDF ({ruta_pdf_respaldo}): {e}")

    return documentos_fusion[:5]


def _parsear_json_seguro(respuesta_bruta):
    """
    Extrae de forma robusta el primer objeto JSON válido devuelto por el LLM,
    tolerando bloques Markdown (```json), texto conversacional previo/posterior,
    comas finales sobrantes (`trailing commas`) o diccionarios Python con comillas simples.
    """
    if not respuesta_bruta or not str(respuesta_bruta).strip():
        raise ValueError("Respuesta vacía del modelo LLM.")
    texto_limpio = re.sub(r"```(?:json)?", "", str(respuesta_bruta), flags=re.IGNORECASE).strip()
    texto_sin_comas = re.sub(r",\s*([\}\]])", r"\1", texto_limpio)

    for candidato in (texto_limpio, texto_sin_comas):
        try:
            resultado = json.loads(candidato)
            if isinstance(resultado, dict):
                return resultado
        except json.JSONDecodeError:
            pass

    decoder = json.JSONDecoder()
    for fuente in (texto_sin_comas, texto_limpio):
        for match in re.finditer(r"\{", fuente):
            inicio = match.start()
            fragmento = fuente[inicio:]
            try:
                obj, _ = decoder.raw_decode(fragmento)
                if isinstance(obj, dict):
                    return obj
            except json.JSONDecodeError:
                pass
            # Respaldo seguro para diccionarios con comillas simples (incluyendo llaves anidadas)
            posiciones_cierre = [m.start() for m in re.finditer(r"\}", fragmento)]
            for fin in posiciones_cierre:
                try:
                    obj_py = ast.literal_eval(fragmento[: fin + 1])
                    if isinstance(obj_py, dict):
                        return obj_py
                except Exception:
                    continue

    raise ValueError("No se encontró ningún objeto JSON válido en la respuesta del LLM.")


def _sanitizar_fase(valor):
    """
    Normaliza la Fase de Tramitación a sus siglas oficiales (`AD`, `AI`, `AP`, `AV`, `TR`, `MOD`)
    o devuelve `'NO_ENCONTRADA'` ante negaciones ('Sin aprobación inicial') o valores vacíos.
    """
    if valor is None or isinstance(valor, bool):
        return "NO_ENCONTRADA"
    texto = str(valor).strip()
    texto_norm = _quitar_tildes(texto).lower().strip()
    if not texto_norm or texto_norm in _VALORES_NULOS:
        return "NO_ENCONTRADA"
    if texto_norm.startswith(("no ", "sin ", "ningun", "falta", "carece", "no_", "pendiente")):
        return "NO_ENCONTRADA"
    if re.search(
        r"\b(?:sin|no\s+consta|no\s+tiene|no\s+existe|carece\s+de|pendiente\s+de|falta(?:\s+de)?)\s+"
        r"(?:la\s+|el\s+|ninguna?\s+)?(?:fase|aprobaci|acuerdo|resoluci|tramitaci)",
        texto_norm,
    ):
        return "NO_ENCONTRADA"

    # Detección de siglas explícitas aisladas o con guiones bajos (ej. "AD - Aprobación" o "FASE_AD")
    siglas_conocidas = ("AD", "AI", "AP", "AV", "TR", "MOD")
    for sigla in siglas_conocidas:
        if re.search(rf"(?<![A-Za-z0-9]){sigla}(?![A-Za-z0-9])", texto.upper()):
            return sigla

    # Mapeo semántico de nombres completos habituales en planeamiento urbanístico
    if "aprobacion definitiva" in texto_norm or "definitiva" in texto_norm:
        return "AD"
    if "aprobacion inicial" in texto_norm or "inicial" in texto_norm:
        return "AI"
    if "aprobacion provisional" in texto_norm or "provisional" in texto_norm:
        return "AP"
    if "texto refundido" in texto_norm or "refundido" in texto_norm:
        return "TR"
    if "avance" in texto_norm:
        return "AV"
    if "modificacion" in texto_norm or "innovacion" in texto_norm:
        return "MOD"

    if len(texto) <= 6 and re.fullmatch(r"[A-Za-z0-9_\-]+", texto):
        return texto.upper()
    return texto


def _validar_fecha_calendario(anio, mes, dia):
    """Valida que la fecha exista realmente en el calendario gregoriano entre 1900 y 2100."""
    try:
        a, m, d = int(anio), int(mes), int(dia)
        if not (1900 <= a <= 2100):
            return None
        fecha = datetime.date(a, m, d)
        return f"{fecha.year:04d}{fecha.month:02d}{fecha.day:02d}"
    except ValueError:
        return None


def _sanitizar_fecha(valor):
    """
    Convierte fechas numéricas o textuales en español a formato estricto `AAAAMMDD`,
    rechazando días inexistentes (ej. 29/02 en año no bisiesto o 31/04) con `'NO_ENCONTRADA'`.
    """
    if valor is None or isinstance(valor, bool):
        return "NO_ENCONTRADA"
    texto = str(valor).strip()
    texto_norm = _quitar_tildes(texto).lower().strip()
    if not texto_norm or texto_norm in _VALORES_NULOS:
        return "NO_ENCONTRADA"

    # 1. Formato compacto de 8 dígitos exactos (AAAAMMDD o DDMMAAAA) validado contra calendario real
    if re.fullmatch(r"\d{8}", texto):
        iso_ok = _validar_fecha_calendario(texto[:4], texto[4:6], texto[6:8])
        if iso_ok:
            return iso_ok
        eur_ok = _validar_fecha_calendario(texto[4:8], texto[2:4], texto[:2])
        if eur_ok:
            return eur_ok
        return "NO_ENCONTRADA"

    # 2. Formato AAAA-MM-DD, AAAA/MM/DD o AAAA.M.D (1 o 2 dígitos en mes y día, incluso rodeado de '_')
    m_iso = re.search(r"(?<![0-9])(19\d{2}|20\d{2}|2100)[/\-\.](\d{1,2})[/\-\.](\d{1,2})(?![0-9])", texto)
    if m_iso:
        iso_ok = _validar_fecha_calendario(m_iso.group(1), m_iso.group(2), m_iso.group(3))
        if iso_ok:
            return iso_ok

    # 3. Formato DD/MM/AAAA, DD-MM-AAAA o D.M.AAAA (1 o 2 dígitos en día y mes, incluso rodeado de '_')
    m_eur = re.search(r"(?<![0-9])(\d{1,2})[/\-\.](\d{1,2})[/\-\.](19\d{2}|20\d{2}|2100)(?![0-9])", texto)
    if m_eur:
        eur_ok = _validar_fecha_calendario(m_eur.group(3), m_eur.group(2), m_eur.group(1))
        if eur_ok:
            return eur_ok

    # 4. Formato textual o mixto en español (ej. "14 de mayo de 2026", "05-may-2026", "14/ago/2024")
    m_txt = re.search(
        r"(?<![0-9])(\d{1,2})(?:[\s/\-\.]+(?:de[\s/\-\.]+)?)?([a-z]+)(?:[\s/\-\.]+(?:(?:de|del)[\s/\-\.]+)?)?(19\d{2}|20\d{2}|2100)(?![0-9])",
        texto_norm,
    )
    if m_txt:
        mes_num = _MESES_ES.get(m_txt.group(2))
        if mes_num:
            txt_ok = _validar_fecha_calendario(m_txt.group(3), mes_num, m_txt.group(1))
            if txt_ok:
                return txt_ok

    # 5. Bloque compacto de 8 dígitos incrustado en texto/timestamp (ej. "20260514T103000Z" o "20260514 (Pleno)")
    m_8dig = re.search(r"(?<![0-9])(\d{8})(?![0-9])", texto)
    if m_8dig:
        bloque8 = m_8dig.group(1)
        iso_ok = _validar_fecha_calendario(bloque8[:4], bloque8[4:6], bloque8[6:8])
        if iso_ok:
            return iso_ok
        eur_ok = _validar_fecha_calendario(bloque8[4:8], bloque8[2:4], bloque8[:2])
        if eur_ok:
            return eur_ok

    return "NO_ENCONTRADA"


def _sanitizar_ambito(valor):
    """Normaliza siglas de ámbito de actuación (máximo 6 caracteres alfanuméricos sin espacios ni signos)."""
    if valor is None or isinstance(valor, bool):
        return "NO_ENCONTRADO"
    limpio = _quitar_tildes(str(valor)).strip()
    if not limpio or limpio.lower() in _VALORES_NULOS or limpio.upper() == "NO_ENCONTRADO":
        return "NO_ENCONTRADO"
    alfanum = re.sub(r"[^A-Za-z0-9]", "", limpio).upper()
    if not alfanum or alfanum in ("AMB", "AMBITO", "NONE", "NULL"):
        return "NO_ENCONTRADO"
    return alfanum[:6]


def _inferir_ambito_proyecto(textos_muestra, nombre_carpeta=""):
    """Detecta siglas de ámbito urbanístico (ej. UE-01, SUP-2, ARI-03, Sector 1) en textos o carpeta."""
    fuentes = [str(nombre_carpeta or "")] + [str(t or "") for t in textos_muestra]
    patron_explicito = re.compile(
        r"\b(?:AMBITO|ÁMBITO|AMB)\s*[:=\-]\s*([A-Za-z0-9][A-Za-z0-9\-_.]{0,8})",
        flags=re.IGNORECASE,
    )
    patron_sector = re.compile(
        r"\bSECTOR\s+([A-Za-z0-9][A-Za-z0-9\-_.]{0,6})\b",
        flags=re.IGNORECASE,
    )
    patron_unidad = re.compile(
        r"\b((?:UE|UA|SUP|SUS|SUNS|SUNC|ARI|API|APR|PERI|SEC|ATU|AOMA)[\s\-_.]?\d{1,4}[A-Za-z]?)\b",
        flags=re.IGNORECASE,
    )
    for fuente in fuentes:
        for pat in (patron_explicito, patron_unidad, patron_sector):
            m = pat.search(fuente)
            if m:
                cand = _sanitizar_ambito(m.group(1))
                if cand != "NO_ENCONTRADO":
                    return cand
    return "NO_ENCONTRADO"


def extraer_metadatos(ruta_pdf=None):
    """
    Recupera los fragmentos más relevantes del proyecto mediante fusión híbrida
    (Vectorial + BM25 o respaldo OCR directo) e invoca al LLM para obtener un
    diccionario limpio con `fase_tramitacion` y `fecha_aprobacion`.
    """
    _imprimir("🧠 Inicializando el motor del Agente Documentalista (Modo Extractor)...")
    if ruta_pdf is not None:
        ruta_pdf = str(ruta_pdf).strip().strip('"').strip("'")

    pregunta_busqueda = "Aprobación definitiva inicial provisional fase tramitación resolución acuerdo pleno fecha firma"
    documentos_encontrados = buscar_fusion_hibrida(pregunta_busqueda, ruta_pdf_respaldo=ruta_pdf)

    if not documentos_encontrados:
        _imprimir("   ⚠️ No se encontraron fragmentos de texto para analizar en el proyecto.")
        return {
            "fase_tramitacion": "NO_ENCONTRADA",
            "fecha_aprobacion": "NO_ENCONTRADA"
        }

    textos_con_fuentes = []
    for doc in documentos_encontrados:
        meta = doc.metadata if isinstance(doc.metadata, dict) else {}
        origen = os.path.basename(str(meta.get("source", "desconocido")))
        pagina = meta.get("page", "N/A")
        textos_con_fuentes.append(f"[Archivo: {origen} | Pág: {pagina}]\n{doc.page_content}")

    texto_contexto = "\n\n".join(textos_con_fuentes)

    try:
        cadena_activa = _obtener_cadena()
        respuesta_bruta = cadena_activa.invoke({"context": texto_contexto})
        diccionario_datos = _parsear_json_seguro(respuesta_bruta)
        return {
            "fase_tramitacion": _sanitizar_fase(diccionario_datos.get("fase_tramitacion")),
            "fecha_aprobacion": _sanitizar_fecha(diccionario_datos.get("fecha_aprobacion"))
        }
    except Exception as e:
        _imprimir(f"[Error Crítico] Fallo al leer el JSON del Agente 1: {e}")
        return {
            "fase_tramitacion": "NO_ENCONTRADA",
            "fecha_aprobacion": "NO_ENCONTRADA",
            "error": "El LLM no devolvió JSON válido"
        }


# =====================================================================
# INSPECCIÓN MULTIFORMATO CON OCR Y CLASIFICACIÓN DE ARCHIVOS (AGENTE 1 -> AGENTE 3)
# =====================================================================

def _determinar_familia_formato(extension):
    """Agrupa la extensión de un archivo en su familia técnica (`PDF`, `SIG_VECTORIAL`, `CAD`, `IMAGEN`, `METADATOS_TEXTO`, `OTRO`)."""
    ext = str(extension or "").lower()
    if ext == ".pdf":
        return "PDF"
    if ext in _EXTENSIONES_SIG:
        return "SIG_VECTORIAL"
    if ext in _EXTENSIONES_CAD:
        return "CAD"
    if ext in _EXTENSIONES_IMAGEN:
        return "IMAGEN"
    if ext in _EXTENSIONES_METADATOS:
        return "METADATOS_TEXTO"
    return "OTRO"


def _detectar_si_es_plano(nombre_archivo, ruta_relativa, muestra_texto, contiene_imagenes, huella_grafica):
    """
    Determina si un archivo corresponde a un plano o documento cartográfico
    examinando su huella gráfica, escalas numéricas (`1:500`, `1:2000`), cartelas
    y terminología técnica de arquitectura/ingeniería (plantas, alzados, secciones, hojas).
    """
    if huella_grafica:
        return True
    contexto = _quitar_tildes(f"{nombre_archivo} {ruta_relativa} {muestra_texto[:800]}").lower()
    patrones_plano = (
        r"\bplanos?\b",
        r"\bcartografi[ao]\b",
        r"\bescala\s+1\s*:\s*\d+",
        r"\be\s*[=:]?\s*1\s*:\s*\d+",
        r"\balzados?\b",
        r"\bsecciones?\b",
        r"\bplanta\s+(?:baja|alta|cubierta|general|tipo|cotas|estructura|instalaciones)\b",
        r"\bhoja\s+\d+\s+de\s+\d+\b",
        r"\bplano\s+[ioep][\-\._]?\d+",
        r"\bortofoto\b",
        r"\btopografic[oa]\b",
    )
    for pat in patrones_plano:
        if re.search(pat, contexto):
            return True
    return False


def inspeccionar_archivo_proyecto(ruta_archivo, carpeta_base=None):
    """
    Lee e inspecciona un archivo individual del proyecto de arquitectura/ingeniería:
    - Si es PDF: extrae texto digital y ejecuta OCR selectivo sobre imágenes incrustadas y cartelas de planos.
    - Si es imagen suelta (.png, .jpg, .tif...): ejecuta OCR directamente sobre la imagen.
    - Si es archivo SIG (.gpkg, .shp...) o metadatos (.txt, .xml): extrae sus propiedades técnicas.
    """
    ruta_limpia = str(ruta_archivo or "").strip().strip('"').strip("'")
    nombre_original = os.path.basename(ruta_limpia)
    _, ext = os.path.splitext(nombre_original)
    ext_low = ext.lower()
    familia = _determinar_familia_formato(ext_low)

    if carpeta_base and os.path.isdir(carpeta_base):
        try:
            ruta_rel = os.path.relpath(os.path.abspath(ruta_limpia), os.path.abspath(carpeta_base))
        except ValueError:
            ruta_rel = nombre_original
    else:
        ruta_rel = nombre_original
    ruta_rel = ruta_rel.replace("\\", "/")

    if not ruta_limpia or not os.path.isfile(ruta_limpia):
        return {
            "nombre_original": nombre_original,
            "ruta_origen": ruta_limpia,
            "ruta_relativa": ruta_rel,
            "extension": ext_low,
            "formato_familia": familia,
            "peso_bytes": 0,
            "peso_mb": 0.0,
            "total_paginas": 0,
            "contiene_imagenes": False,
            "ocr_aplicado": False,
            "es_documento_grafico_o_plano": False,
            "estado_lectura": "INEXISTENTE",
            "muestra_texto": "",
        }

    peso_bytes = os.path.getsize(ruta_limpia)
    peso_mb = round(peso_bytes / (1024 * 1024), 4)

    if peso_bytes == 0:
        return {
            "nombre_original": nombre_original,
            "ruta_origen": os.path.abspath(ruta_limpia),
            "ruta_relativa": ruta_rel,
            "extension": ext_low,
            "formato_familia": familia,
            "peso_bytes": 0,
            "peso_mb": 0.0,
            "total_paginas": 0,
            "contiene_imagenes": False,
            "ocr_aplicado": False,
            "es_documento_grafico_o_plano": False,
            "estado_lectura": "VACIO",
            "muestra_texto": "",
        }

    total_paginas = 0
    contiene_imagenes = False
    ocr_aplicado = False
    huella_grafica = False
    muestra_texto = ""
    estado_lectura = "OK"

    if familia == "PDF":
        try:
            paginas = cargar_pdf_con_ocr(ruta_limpia, incluir_cabecera_documento=False)
            if paginas:
                max_pag = max((int((p.metadata or {}).get("page") or 0) for p in paginas), default=len(paginas))
                total_paginas = max(len(paginas), max_pag)
            contiene_imagenes = any(bool((p.metadata or {}).get("contiene_imagenes")) for p in paginas)
            ocr_aplicado = any(bool((p.metadata or {}).get("ocr_aplicado")) for p in paginas)
            fragmentos = []
            # Tomamos hasta las primeras 6 páginas (portada, índice/cartela y arranque) para clasificar con precisión
            for p in paginas[:6]:
                contenido_p = (p.page_content or "").strip()
                if "CONTENIDO GRÁFICO / PLANO / IMAGEN" in contenido_p:
                    huella_grafica = True
                if contenido_p:
                    fragmentos.append(contenido_p)
            muestra_texto = "\n".join(fragmentos)[:1800]
        except Exception as e:
            estado_lectura = "ERROR_LECTURA"
            muestra_texto = f"[Aviso lectura PDF: {e}]"

    elif familia == "IMAGEN":
        total_paginas = 1
        contiene_imagenes = True
        huella_grafica = True
        try:
            with open(ruta_limpia, "rb") as f_img:
                datos_img = f_img.read()
            txt_ocr = _ejecutar_ocr_sobre_bytes_imagen(datos_img)
            if txt_ocr:
                ocr_aplicado = True
                muestra_texto = f"[Texto extraído de imagen (OCR)]:\n{txt_ocr[:1800]}"
        except Exception:
            estado_lectura = "ERROR_LECTURA"

    elif familia == "METADATOS_TEXTO" or ext_low in (".gml", ".geojson"):
        try:
            with open(ruta_limpia, "rb") as f_txt:
                crudo = f_txt.read(4096)
            muestra_texto = crudo.decode("utf-8", errors="replace").strip()[:1800]
        except Exception:
            estado_lectura = "ERROR_LECTURA"

    es_plano = _detectar_si_es_plano(
        nombre_original, ruta_rel, muestra_texto, contiene_imagenes, huella_grafica
    )

    return {
        "nombre_original": nombre_original,
        "ruta_origen": os.path.abspath(ruta_limpia),
        "ruta_relativa": ruta_rel,
        "extension": ext_low,
        "formato_familia": familia,
        "peso_bytes": peso_bytes,
        "peso_mb": peso_mb,
        "total_paginas": total_paginas,
        "contiene_imagenes": contiene_imagenes,
        "ocr_aplicado": ocr_aplicado,
        "es_documento_grafico_o_plano": es_plano,
        "estado_lectura": estado_lectura,
        "muestra_texto": muestra_texto,
    }


def _detectar_categoria_tecnica(spec):
    """Clasifica técnicamente un archivo según su formato, nombre, subcarpeta y texto/OCR."""
    familia = spec.get("formato_familia", "OTRO")
    nombre = _quitar_tildes(spec.get("nombre_original", "")).lower()
    ruta_rel = _quitar_tildes(spec.get("ruta_relativa", "")).lower()
    muestra = _quitar_tildes(spec.get("muestra_texto", "")).lower()
    es_plano = bool(spec.get("es_documento_grafico_o_plano"))

    if familia == "SIG_VECTORIAL":
        return "DATOS_ESPACIALES_SIG"
    if familia == "METADATOS_TEXTO":
        return "METADATOS"
    if familia == "CAD":
        return "PLANO_ARQUITECTURA_INGENIERIA"

    # Priorizamos primero título/nombre y cabecera del documento (primeros 600 caracteres)
    # evitando que una tabla de contenido interna ("ÍNDICE:") dentro de una Memoria la clasifique como índice general
    cabecera = f"{nombre} {ruta_rel} {muestra[:600]}"
    nombre_tiene_otro_rol = any(
        k in nombre for k in ("memoria", "normativa", "ordenanza", "plano", "cartografia", "catalogo", "anexo", "resumen")
    )

    if "indice" in nombre or (
        not nombre_tiene_otro_rol
        and re.search(r"\b(?:indice\s+general|indice\s+de\s+documentos|diligencia\s+de\s+indice|indice\s+con\s+diligencia)\b", cabecera)
    ):
        return "INDICE_GENERAL"

    if "resumen ejecutivo" in cabecera or "resumen_ejecutivo" in nombre:
        return "RESUMEN_EJECUTIVO"

    if "catalogo" in cabecera:
        if es_plano or "plano" in cabecera or "cartograf" in cabecera:
            return "CATALOGO_PLANOS"
        if "ficha" in cabecera or "inventario" in cabecera:
            return "CATALOGO_FICHAS"
        return "CATALOGO_MEMORIA"

    if any(p in cabecera for p in ("actuaciones de transformacion", "actuacion de transformacion", "atusr", "atusu")):
        return "ACTUACIONES_TRANSFORMACION"

    if any(p in cabecera for p in ("normativa urbanistica", "normas urbanisticas", "ordenanzas urbanisticas", "articulado urbanistico")) or any(p in nombre for p in ("normativa", "normas_urbanisticas", "ordenanzas")):
        return "NORMATIVA_URBANISTICA"

    if es_plano or any(p in nombre for p in ("plano", "cartografia", "mapa", "hoja_")):
        if any(p in cabecera for p in ("plano de informacion", "planos de informacion", "cartografia de informacion", "estado actual", "topograf", "afecciones", "informacion urbanistica")) or re.search(r"(?:^|[_\-\s])(?:ci|i[\-_]?\d+)(?:[_\-\.\s]|$)", nombre):
            return "CARTOGRAFIA_INFORMACION"
        if any(p in cabecera for p in ("plano de ordenacion", "planos de ordenacion", "cartografia de ordenacion", "zonificacion", "alineaciones", "ordenacion estructural", "ordenacion pormenorizada", "propuesta")) or re.search(r"(?:^|[_\-\s])(?:co|o[\-_]?\d+)(?:[_\-\.\s]|$)", nombre):
            return "CARTOGRAFIA_ORDENACION"
        return "CARTOGRAFIA_ORDENACION" if "ordenacion" in cabecera else "PLANO_ARQUITECTURA_INGENIERIA"

    if any(p in cabecera for p in ("anexo", "estudio ambiental", "evaluacion ambiental", "impacto ambiental", "hidrolog", "inundabilidad", "acustic", "trafico", "movilidad", "geotecnic", "arqueolog", "impacto en la salud")):
        return "ANEXO_TECNICO"

    if any(p in cabecera for p in ("sostenibilidad economica", "memoria economica", "viabilidad economica", "estudio economico", "economico financiero")):
        return "MEMORIA_ECONOMICA"

    if any(p in cabecera for p in ("memoria de participacion", "participacion ciudadana", "informe de alegaciones", "consulta publica")):
        return "MEMORIA_PARTICIPACION"

    if any(p in cabecera for p in ("memoria de informacion", "diagnostico urbanistico", "analisis y diagnostico")):
        return "MEMORIA_INFORMACION"

    if any(p in cabecera for p in ("memoria de ordenacion", "memoria justificativa", "propuesta de ordenacion")):
        return "MEMORIA_ORDENACION"

    if "memoria" in cabecera or "caratula" in cabecera:
        return "MEMORIA_GENERAL"

    return "OTROS_DOCUMENTOS"


def _es_slot_compatible_con_archivo(spec, slot):
    """Comprueba la compatibilidad técnica de formato entre el archivo y un destino del catálogo."""
    fam_archivo = spec.get("formato_familia", "OTRO")
    ext_archivo = spec.get("extension", "")
    fam_slot = slot.get("familia_esperada", "CUALQUIERA")
    ext_slot = slot.get("extension_esperada", "*")

    if fam_archivo == "SIG_VECTORIAL":
        return fam_slot in ("SIG_VECTORIAL", "CUALQUIERA") or ext_slot in ("*", ext_archivo)
    if fam_archivo == "METADATOS_TEXTO":
        return fam_slot in ("METADATOS_TEXTO", "CUALQUIERA") or ext_slot in ("*", ext_archivo)
    if fam_slot == "SIG_VECTORIAL" and fam_archivo not in ("SIG_VECTORIAL", "CAD"):
        return False
    if fam_slot == "METADATOS_TEXTO" and fam_archivo != "METADATOS_TEXTO":
        return False
    return True


def _puntuar_slot_dinamico(spec, categoria_tecnica, slot):
    """
    Calcula la afinidad entre un archivo inspeccionado y un destino extraído dinámicamente
    del boletín regulatorio (sin depender de ninguna tabla fija).
    """
    if not _es_slot_compatible_con_archivo(spec, slot):
        return -1000.0

    puntaje = 0.0
    fam_archivo = spec.get("formato_familia", "OTRO")
    fam_slot = slot.get("familia_esperada", "CUALQUIERA")
    ext_archivo = spec.get("extension", "")
    ext_slot = slot.get("extension_esperada", "*")

    if fam_archivo == fam_slot:
        puntaje += 25.0
    if ext_slot != "*" and ext_archivo == ext_slot:
        puntaje += 10.0

    tokens_slot = set(
        _tokenizar(slot.get("descripcion_archivo", ""))
        + _tokenizar(slot.get("descripcion_carpeta", ""))
        + _tokenizar(slot.get("plantilla_archivo", ""))
        + _tokenizar(" ".join(slot.get("ruta_carpetas_plantilla") or []))
    )

    tokens_afinidad = _AFINIDADES_CATEGORIA_TOKENS.get(categoria_tecnica, set())
    coincidencias_cat = tokens_slot & tokens_afinidad
    puntaje += len(coincidencias_cat) * 14.0

    # Bonificación por sufijos/siglas distintivas presentes en plantillas codificadas (ej. MI, MO, MP, ME, NU, CI, CO, IN, AN01, RE, SITU, META)
    plantilla_upper = str(slot.get("plantilla_archivo") or "").upper()
    partes_plantilla = {
        p.lower() for p in re.split(r"[^A-Z0-9]+", plantilla_upper)
        if p and p not in ("INE", "TIP", "AMB", "FT", "AAAAMMDD", "PDF")
    }
    coincidencias_sigla = partes_plantilla & tokens_afinidad
    puntaje += len(coincidencias_sigla) * 20.0

    # Solapamiento directo entre palabras del nombre/subcarpeta/OCR del archivo y descripción del slot
    tokens_nombre = set(_tokenizar(spec.get("nombre_original", "")) + _tokenizar(spec.get("ruta_relativa", "")))
    tokens_ocr = set(_tokenizar(spec.get("muestra_texto", "")[:500]))
    puntaje += len(tokens_nombre & tokens_slot) * 10.0
    puntaje += len(tokens_ocr & tokens_slot) * 4.0

    # Evitar asignar documentos generales (ej. Memoria Justificativa) a subcarpetas exclusivas de Catálogo
    if ("catalogo" in tokens_slot or "ct" in partes_plantilla) and not categoria_tecnica.startswith("CATALOGO"):
        puntaje -= 25.0

    # Coherencia gráfica: si es plano, priorizar carpetas/archivos gráficos frente a memorias textuales
    es_plano = bool(spec.get("es_documento_grafico_o_plano"))
    es_slot_grafico = bool(tokens_slot & {"plano", "planos", "cartografia", "mapa", "mapas", "ci", "co", "ca", "cp"})
    if es_plano and es_slot_grafico:
        puntaje += 18.0
    elif es_plano and not es_slot_grafico and (tokens_slot & {"memoria", "normativa", "indice", "resumen"}):
        puntaje -= 12.0
    elif not es_plano and fam_archivo == "PDF" and es_slot_grafico and categoria_tecnica.startswith("MEMORIA"):
        puntaje -= 12.0

    return puntaje


def _clasificar_lote_con_llm(archivos_specs, catalogo):
    """
    Intenta refinar la clasificación mediante el LLM local cuando hay catálogo normativo.
    Valida rigurosamente que cada `id_destino` devuelto exista y sea compatible en formato;
    si el LLM no está disponible o devuelve otro esquema, retorna {} sin interrumpir el flujo.
    """
    if not LANGCHAIN_DISPONIBLE or ChatPromptTemplate is None or StrOutputParser is None or ChatOllama is None:
        return {}
    if not archivos_specs or len(catalogo) <= 1:
        return {}

    mapa_slots = {s["id_destino"]: s for s in catalogo}
    lineas_cat = [
        f"- {s['id_destino']}: Carpeta='{s['descripcion_carpeta']}' ({'/'.join(s['ruta_carpetas_plantilla']) or '_RAIZ_'}) "
        f"| Archivo='{s['plantilla_archivo']}' ({s['descripcion_archivo']}) | Formato={s['familia_esperada']}"
        for s in catalogo
    ]
    lineas_arch = []
    for item in archivos_specs:
        resumen_corto = re.sub(r"\s+", " ", item.get("muestra_texto", "")[:260]).strip()
        lineas_arch.append(
            f"- Índice {item['indice']}: nombre='{item['nombre_original']}', ruta='{item['ruta_relativa']}', "
            f"formato={item['formato_familia']}, es_plano={item['es_documento_grafico_o_plano']}, "
            f"categoria_preliminar={item['_categoria_preliminar']}, extracto='{resumen_corto}'"
        )

    try:
        prompt_cls = ChatPromptTemplate.from_messages([("system", _SISTEMA_CLASIFICADOR_PROYECTO)])
        cadena_cls = prompt_cls | _obtener_llm_agente_1() | StrOutputParser()
        respuesta = cadena_cls.invoke({
            "catalogo_texto": "\n".join(lineas_cat),
            "archivos_texto": "\n".join(lineas_arch),
        })
        parsed = _parsear_json_seguro(respuesta)
        bruto = parsed.get("clasificaciones")
        if not isinstance(bruto, dict):
            return {}

        validados = {}
        for item in archivos_specs:
            idx_str = str(item["indice"])
            id_cand = str(bruto.get(idx_str) or bruto.get(item["indice"]) or "").strip().upper()
            if id_cand in mapa_slots and _es_slot_compatible_con_archivo(item, mapa_slots[id_cand]):
                validados[item["indice"]] = id_cand
        return validados
    except Exception:
        return {}


def _descubrir_archivos_proyecto(ruta_entrada):
    """Descubre todos los archivos entregables del proyecto excluyendo carpetas de sistema y fragmentos previos."""
    ruta_limpia = str(ruta_entrada or "").strip().strip('"').strip("'")
    if not ruta_limpia:
        return "", []

    if os.path.isfile(ruta_limpia):
        return os.path.dirname(os.path.abspath(ruta_limpia)), [os.path.abspath(ruta_limpia)]

    if not os.path.isdir(ruta_limpia):
        return ruta_limpia, []

    carpeta_abs = os.path.abspath(ruta_limpia)
    archivos_encontrados = []
    for raiz, subcarpetas, archivos in os.walk(carpeta_abs):
        subcarpetas[:] = sorted([
            d for d in subcarpetas
            if not d.startswith(".") and d.lower() not in _CARPETAS_EXCLUIDAS
        ])
        for nombre in sorted(archivos):
            if nombre.startswith(".") or nombre.startswith(".tmp_"):
                continue
            nom_low = nombre.lower()
            if nom_low == NOMBRE_JSON_ESPECIFICACIONES.lower():
                continue
            if nom_low.endswith("_informe_empaquetado.json"):
                continue
            if nom_low.endswith(".pdf") and ("_parte_" in nom_low or "_tomo_" in nom_low):
                continue
            ruta_f = os.path.join(raiz, nombre)
            if os.path.isfile(ruta_f):
                archivos_encontrados.append(ruta_f)

    return carpeta_abs, archivos_encontrados


def clasificar_archivos_proyecto(
    ruta_carpeta_proyecto,
    reglas_identidad=None,
    metadatos_caratula=None,
    ruta_json_salida=None,
    usar_llm=True,
):
    """
    Función principal del Agente 1 para organización completa de proyectos de arquitectura/ingeniería:
    1. Recorre todos los archivos del proyecto y extrae su contenido (incluyendo OCR en imágenes y planos).
    2. Clasifica cada archivo frente al catálogo dinámico de carpetas/archivos extraído por el Agente 2.
    3. Genera y guarda atómicamente `especificaciones_agente_1.json` listo para el Agente 3.
    """
    _imprimir("📂 [Agente 1] Inspeccionando y clasificando todos los archivos del proyecto (con lectura OCR de imágenes y planos)...")
    carpeta_base, rutas_archivos = _descubrir_archivos_proyecto(ruta_carpeta_proyecto)

    if not carpeta_base or not os.path.isdir(carpeta_base):
        return {
            "estado": "ERROR",
            "mensaje": f"La carpeta del proyecto no existe o no es válida: {ruta_carpeta_proyecto}",
            "total_archivos": 0,
            "archivos": [],
        }

    # Construir dinámicamente el catálogo de carpetas/archivos a partir de las reglas del Agente 2
    catalogo = []
    if callable(construir_catalogo_documental) and isinstance(reglas_identidad, dict):
        catalogo = construir_catalogo_documental(reglas_identidad)

    archivos_inspeccionados = []
    resumen_formatos = {}
    archivos_con_ocr = 0
    textos_proyecto = []

    for idx, ruta_f in enumerate(rutas_archivos, start=1):
        spec = inspeccionar_archivo_proyecto(ruta_f, carpeta_base=carpeta_base)
        spec["indice"] = idx
        cat_tec = _detectar_categoria_tecnica(spec)
        spec["_categoria_preliminar"] = cat_tec
        archivos_inspeccionados.append(spec)

        fam = spec["formato_familia"]
        resumen_formatos[fam] = resumen_formatos.get(fam, 0) + 1
        if spec.get("ocr_aplicado"):
            archivos_con_ocr += 1
        if spec.get("muestra_texto"):
            textos_proyecto.append(spec["muestra_texto"])

    # Enriquecer metadatos del proyecto (fase, fecha y posible ámbito AMB)
    meta_base = dict(metadatos_caratula) if isinstance(metadatos_caratula, dict) else {}
    fase_proy = _sanitizar_fase(meta_base.get("fase_tramitacion"))
    fecha_proy = _sanitizar_fecha(meta_base.get("fecha_aprobacion"))
    ambito_proy = _sanitizar_ambito(meta_base.get("ambito"))

    if ambito_proy == "NO_ENCONTRADO":
        ambito_proy = _inferir_ambito_proyecto(textos_proyecto, os.path.basename(carpeta_base))

    # Si no se pasó carátula previa y hay archivos con texto, intentar inferencia segura sobre muestras
    if (fase_proy == "NO_ENCONTRADA" or fecha_proy == "NO_ENCONTRADA") and not metadatos_caratula and textos_proyecto:
        texto_conjunto = "\n".join(textos_proyecto[:5])
        if fase_proy == "NO_ENCONTRADA":
            m_f = re.search(
                r"(aprobaci[oó]n\s+(?:definitiva|inicial|provisional)|texto\s+refundido)",
                texto_conjunto,
                flags=re.IGNORECASE,
            )
            if m_f:
                fase_proy = _sanitizar_fase(m_f.group(1))
        if fecha_proy == "NO_ENCONTRADA":
            fecha_proy = _sanitizar_fecha(texto_conjunto)

    elecciones_llm = {}
    if usar_llm and catalogo:
        elecciones_llm = _clasificar_lote_con_llm(archivos_inspeccionados, catalogo)

    mapa_slots = {s["id_destino"]: s for s in catalogo}
    archivos_clasificados = []

    for spec in archivos_inspeccionados:
        cat_tec = spec.pop("_categoria_preliminar", "OTROS_DOCUMENTOS")
        slot_elegido = None
        metodo = "REGLAS_TECNICAS_OCR"

        if spec["indice"] in elecciones_llm:
            slot_cand = mapa_slots.get(elecciones_llm[spec["indice"]])
            slot_heur = None
            mejor_pts_h = -999.0
            for s in catalogo:
                pts_h = _puntuar_slot_dinamico(spec, cat_tec, s)
                if pts_h > mejor_pts_h:
                    mejor_pts_h = pts_h
                    slot_heur = s
            # Si el LLM eligió un slot válido y razonable, lo adoptamos; si contradice un match técnico inequívoco, priorizamos precisión
            if slot_cand is not None:
                pts_llm = _puntuar_slot_dinamico(spec, cat_tec, slot_cand)
                if pts_llm >= mejor_pts_h - 15.0:
                    slot_elegido = slot_cand
                    metodo = "LLM+OCR"
                else:
                    slot_elegido = slot_heur
                    metodo = "HIBRIDO_OCR"

        if slot_elegido is None and catalogo:
            mejor_puntaje = -999.0
            for s in catalogo:
                pts = _puntuar_slot_dinamico(spec, cat_tec, s)
                if pts > mejor_puntaje:
                    mejor_puntaje = pts
                    slot_elegido = s
            if mejor_puntaje <= -500.0:
                slot_elegido = None

        if slot_elegido is not None:
            spec["clasificacion"] = {
                "categoria_tecnica": cat_tec,
                "id_destino": slot_elegido["id_destino"],
                "en_raiz": bool(slot_elegido["en_raiz"]),
                "ruta_carpetas_plantilla": list(slot_elegido["ruta_carpetas_plantilla"]),
                "plantilla_archivo": slot_elegido["plantilla_archivo"],
                "descripcion_destino": slot_elegido["descripcion_archivo"],
                "es_seriado": bool(slot_elegido.get("es_seriado", False)),
                "metodo_clasificacion": metodo,
            }
        else:
            # Sin catálogo normativo o archivo complementario fuera de tabla
            stem_limpio = os.path.splitext(spec["nombre_original"])[0]
            spec["clasificacion"] = {
                "categoria_tecnica": cat_tec,
                "id_destino": "SIN_CATALOGO",
                "en_raiz": True,
                "ruta_carpetas_plantilla": [],
                "plantilla_archivo": stem_limpio,
                "descripcion_destino": cat_tec,
                "es_seriado": False,
                "metodo_clasificacion": metodo,
            }

        archivos_clasificados.append(spec)

    if ruta_json_salida and str(ruta_json_salida).strip():
        destino_json = os.path.abspath(str(ruta_json_salida).strip().strip('"').strip("'"))
    else:
        # Guardar por defecto dentro de `<carpeta_proyecto>/salida_empaquetada/especificaciones_agente_1.json`
        destino_json = os.path.join(carpeta_base, "salida_empaquetada", NOMBRE_JSON_ESPECIFICACIONES)

    especificaciones = {
        "estado": "COMPLETADO",
        "version_esquema": "1.0",
        "carpeta_proyecto": carpeta_base,
        "total_archivos": len(archivos_clasificados),
        "resumen_formatos": resumen_formatos,
        "archivos_con_ocr": archivos_con_ocr,
        "metadatos_proyecto": {
            "fase_tramitacion": fase_proy,
            "fecha_aprobacion": fecha_proy,
            "ambito": ambito_proy,
        },
        "archivos": archivos_clasificados,
        "ruta_json_generado": destino_json,
    }

    try:
        _guardar_json_atomico(destino_json, especificaciones)
        _imprimir(
            f"   💾 [Agente 1] '{os.path.basename(destino_json)}' generado con {len(archivos_clasificados)} "
            f"archivo(s) clasificado(s) ({archivos_con_ocr} con lectura OCR de imágenes)."
        )
    except OSError as e:
        _imprimir(f"   ⚠️ Aviso al guardar JSON de especificaciones de Agente 1: {e}")

    return especificaciones


def ejecutar_agente_1(
    ruta_carpeta_proyecto=None,
    ruta_pdf_caratula=None,
    reglas_identidad=None,
    ruta_json_salida=None,
):
    """Punto de entrada unificado del Agente 1: extrae metadatos legales y clasifica todos los archivos en JSON."""
    pdf_ref = ruta_pdf_caratula
    if not pdf_ref and ruta_carpeta_proyecto and os.path.isfile(str(ruta_carpeta_proyecto)):
        pdf_ref = ruta_carpeta_proyecto
    metadatos = extraer_metadatos(pdf_ref)
    if ruta_carpeta_proyecto:
        especificaciones = clasificar_archivos_proyecto(
            ruta_carpeta_proyecto,
            reglas_identidad=reglas_identidad,
            metadatos_caratula=metadatos,
            ruta_json_salida=ruta_json_salida,
        )
        return {
            "metadatos_caratula": metadatos,
            "especificaciones_proyecto": especificaciones,
        }
    return {"metadatos_caratula": metadatos}


if __name__ == "__main__":
    _imprimir("Iniciando Agente 1 (Documentalista)...")
    if len(sys.argv) > 1 and os.path.exists(sys.argv[1]):
        resultado = clasificar_archivos_proyecto(sys.argv[1])
    else:
        resultado = extraer_metadatos()
    _imprimir("\n🤖 Datos extraídos listos para el Orquestador:")
    _imprimir(json.dumps(resultado, indent=2, ensure_ascii=False))
