"""
Módulo: lector_ocr_pdf.py
================================================================================
Propósito general:
    Motor transversal de lectura híbrida (Texto Digital Nativo + OCR sobre Imágenes)
    compartido por los Agentes 1 y 2 y por ambos creadores de bases vectoriales.
    Especialmente diseñado para proyectos de arquitectura, ingeniería y urbanismo,
    donde abundan planos escaneados, cartelas como imagen rasterizada, croquis y
    documentos visados o firmados electrónicamente.

Estrategia de lectura multicapa por página:
    1. Extracción de texto digital nativo mediante cascada tolerante a fallos:
       `PyPDFLoader` -> `pypdf` (`PdfReader`) -> `PyMuPDF` (`fitz`).
    2. Desbloqueo automático de PDFs con cifrado de permisos y clave vacía (`""`),
       muy habitual en documentos firmados o visados por colegios profesionales.
    3. Activación selectiva de OCR (`RapidOCR` sobre ONNX Runtime) únicamente en
       aquellas páginas cuyo texto digital sea inferior a `umbral_minimo_caracteres`
       (25 caracteres por defecto):
         - Vía A: Extracción directa de imágenes incrustadas (`get_images` / `extract_image`)
           en `PyMuPDF`, o renderizado completo de la página a 150 DPI si es un
           plano vectorial/escaneado sin texto extraíble por XRef.
         - Vía B: Extracción de `page.images` desde `pypdf` si `PyMuPDF` no está presente.
    4. Si una página es un plano puramente geométrico sin texto reconocible incluso
       tras OCR, emite una huella descriptiva gráfica (`CONTENIDO GRÁFICO / PLANO / IMAGEN`)
       para que el Agente 1 nunca pierda el documento durante la clasificación.
================================================================================
"""

import os
import threading

# Carga opcional y segura de cada librería lectora para permitir degradación elegante
try:
    from pypdf import PdfReader
    PYPDF_DISPONIBLE = True
except Exception:
    PdfReader = None
    PYPDF_DISPONIBLE = False

try:
    from langchain_community.document_loaders import PyPDFLoader
    PYPDFLOADER_DISPONIBLE = True
except Exception:
    PyPDFLoader = None
    PYPDFLOADER_DISPONIBLE = False

try:
    from langchain_core.documents import Document
except Exception:
    class Document:  # Respaldo ligero si langchain_core no está instalado
        """Estructura mínima compatible con `langchain_core.documents.Document`."""
        def __init__(self, page_content="", metadata=None):
            self.page_content = page_content
            self.metadata = dict(metadata) if metadata else {}

# Intentamos cargar motores de imagen y OCR ligeros (PyMuPDF + RapidOCR) de forma segura
try:
    import fitz  # PyMuPDF
    PYMUPDF_DISPONIBLE = True
except Exception:
    fitz = None
    PYMUPDF_DISPONIBLE = False

try:
    from rapidocr_onnxruntime import RapidOCR as _RapidOCRClass
    RAPIDOCR_DISPONIBLE = True
except Exception:
    _RapidOCRClass = None
    RAPIDOCR_DISPONIBLE = False

# Instancia singleton perezosa (lazy) del motor RapidOCR protegida por cerrojo (thread-safe)
# para evitar recargar los modelos ONNX en cada página o hilo del ThreadPoolExecutor.
_MOTOR_OCR = None
_LOCK_OCR = threading.Lock()


def _obtener_motor_ocr():
    """Inicializa RapidOCR bajo demanda de forma segura para hilos y tolerante a fallos de DLL/ONNX."""
    global _MOTOR_OCR, RAPIDOCR_DISPONIBLE
    if _MOTOR_OCR is not None:
        return _MOTOR_OCR
    if not RAPIDOCR_DISPONIBLE or _RapidOCRClass is None:
        return None
    with _LOCK_OCR:
        if _MOTOR_OCR is not None:
            return _MOTOR_OCR
        try:
            _MOTOR_OCR = _RapidOCRClass()
            return _MOTOR_OCR
        except Exception:
            # Si falla la inicialización nativa de ONNX en tiempo de ejecución, desactivar OCR sin abortar
            RAPIDOCR_DISPONIBLE = False
            _MOTOR_OCR = None
            return None


def _ejecutar_ocr_sobre_bytes_imagen(img_bytes):
    """Ejecuta RapidOCR sobre los bytes de una imagen y devuelve el texto reconocido."""
    if not img_bytes or not RAPIDOCR_DISPONIBLE:
        return ""
    motor = _obtener_motor_ocr()
    if motor is None:
        return ""
    try:
        # RapidOCR devuelve habitualmente una tupla `(lista_detecciones, tiempos)`
        # donde cada detección tiene el formato `[caja_coordenadas, texto_reconocido, confianza]`
        salida = motor(img_bytes)
        resultado = salida[0] if isinstance(salida, tuple) and len(salida) > 0 else salida
        if not resultado or not isinstance(resultado, (list, tuple)):
            return ""
        lineas = []
        for item in resultado:
            if isinstance(item, (list, tuple)) and len(item) > 1 and item[1] is not None:
                texto_linea = str(item[1]).strip()
                if texto_linea:
                    lineas.append(texto_linea)
        return "\n".join(lineas)
    except Exception:
        return ""


def _extraer_texto_ocr_pagina(ruta_pdf, indice_pagina, page_pypdf=None, doc_fitz=None):
    """
    Extrae el texto contenido en las imágenes de una página PDF:
    1. Si PyMuPDF (fitz) está disponible, extrae las imágenes incrustadas o renderiza la página a 150 DPI y pasa RapidOCR.
    2. Si no está PyMuPDF pero sí pypdf + RapidOCR, extrae las imágenes del objeto page.images de pypdf y pasa RapidOCR.
    Garantiza el cierre determinista del descriptor de archivo si abre un documento fitz propio.
    """
    textos_ocr = []

    # Vía 1: PyMuPDF (fitz) + RapidOCR
    if PYMUPDF_DISPONIBLE and RAPIDOCR_DISPONIBLE and fitz is not None:
        cerrar_al_salir = False
        doc_activo = doc_fitz
        try:
            if doc_activo is None:
                doc_activo = fitz.open(ruta_pdf)
                cerrar_al_salir = True

            if 0 <= indice_pagina < len(doc_activo):
                pagina_fitz = doc_activo[indice_pagina]
                try:
                    lista_imagenes = pagina_fitz.get_images(full=True) or []
                except Exception:
                    lista_imagenes = []

                # Deduplicar referencias XRef dentro de la misma página para no repetir OCR sobre logos/símbolos repetidos
                xrefs_vistos = set()
                for img_info in lista_imagenes:
                    if not img_info:
                        continue
                    xref = img_info[0]
                    if xref in xrefs_vistos:
                        continue
                    xrefs_vistos.add(xref)
                    try:
                        base_img = doc_activo.extract_image(xref)
                        if isinstance(base_img, dict) and base_img.get("image"):
                            txt = _ejecutar_ocr_sobre_bytes_imagen(base_img["image"])
                            if txt:
                                textos_ocr.append(txt)
                    except Exception:
                        continue

                # Si es un plano vectorial (texto trazado como polilíneas) o página escaneada donde no salió texto por xref,
                # rasterizamos la página completa a 150 DPI en memoria PNG y pasamos OCR.
                if not textos_ocr:
                    try:
                        pix = pagina_fitz.get_pixmap(dpi=150)
                        txt_render = _ejecutar_ocr_sobre_bytes_imagen(pix.tobytes("png"))
                        if txt_render:
                            textos_ocr.append(txt_render)
                    except Exception:
                        pass
        except Exception:
            pass
        finally:
            if cerrar_al_salir and doc_activo is not None:
                try:
                    doc_activo.close()
                except Exception:
                    pass

    # Vía 2: pypdf (page.images) + RapidOCR como respaldo si PyMuPDF no está instalado
    if not textos_ocr and RAPIDOCR_DISPONIBLE and page_pypdf is not None:
        try:
            imagenes_pypdf = getattr(page_pypdf, "images", None) or []
            for imagen_obj in imagenes_pypdf:
                try:
                    datos_img = getattr(imagen_obj, "data", None)
                    if datos_img:
                        txt = _ejecutar_ocr_sobre_bytes_imagen(datos_img)
                        if txt:
                            textos_ocr.append(txt)
                except Exception:
                    continue
        except Exception:
            pass

    return "\n".join(textos_ocr).strip()


def _detectar_objetos_imagen_pypdf(page_pypdf):
    """Detecta si una página de `pypdf` contiene objetos de imagen o recursos `/XObject`."""
    if page_pypdf is None:
        return False
    try:
        imagenes = getattr(page_pypdf, "images", None)
        if imagenes and len(imagenes) > 0:
            return True
    except Exception:
        pass
    try:
        recursos = page_pypdf.get("/Resources", {})
        if hasattr(recursos, "get_object"):
            recursos = recursos.get_object()
        xobj = recursos.get("/XObject", {}) if isinstance(recursos, dict) else {}
        if hasattr(xobj, "get_object"):
            xobj = xobj.get_object()
        return bool(xobj)
    except Exception:
        return False


def _detectar_objetos_graficos_fitz(doc_fitz, indice_pagina):
    """Detecta si una página abierta con `PyMuPDF` contiene imágenes incrustadas o trazados vectoriales CAD."""
    if doc_fitz is None:
        return False
    try:
        if 0 <= indice_pagina < len(doc_fitz):
            pag = doc_fitz[indice_pagina]
            if pag.get_images(full=True):
                return True
            if hasattr(pag, "get_drawings") and pag.get_drawings():
                return True
    except Exception:
        pass
    return False


def cargar_pdf_con_ocr(ruta_completa, incluir_cabecera_documento=True, umbral_minimo_caracteres=25):
    """
    Carga todas las páginas de un PDF combinando extracción de texto nativo y OCR selectivo sobre imágenes:
    - Si la página tiene texto digital suficiente, lo conserva.
    - Si la página contiene imágenes y poco o ningún texto digital (< umbral_minimo_caracteres),
      activa automáticamente el motor OCR sobre las imágenes de esa página.
    - Si es un plano puramente geométrico sin texto incluso tras OCR, conserva su huella gráfica para clasificación.
    """
    # Validaciones defensivas estrictas sobre el argumento de entrada
    if ruta_completa is None or isinstance(ruta_completa, bool) or not isinstance(ruta_completa, (str, os.PathLike)):
        raise ValueError("La ruta del archivo PDF no puede ser nula.")

    ruta_limpia = str(ruta_completa).strip().strip('"').strip("'")
    if not ruta_limpia:
        raise ValueError("La ruta del archivo PDF está vacía.")
    if not os.path.isfile(ruta_limpia):
        raise FileNotFoundError(f"El archivo PDF no existe: {ruta_limpia}")
    if os.path.getsize(ruta_limpia) == 0:
        raise ValueError(f"El archivo PDF está vacío (0 bytes): {ruta_limpia}")

    if umbral_minimo_caracteres is None or isinstance(umbral_minimo_caracteres, bool):
        umbral_efectivo = 25
    else:
        try:
            umbral_efectivo = max(0, int(umbral_minimo_caracteres))
        except (TypeError, ValueError):
            umbral_efectivo = 25

    hay_algun_motor = (
        (PYPDFLOADER_DISPONIBLE and PyPDFLoader is not None)
        or (PYPDF_DISPONIBLE and PdfReader is not None)
        or (PYMUPDF_DISPONIBLE and fitz is not None)
    )
    if not hay_algun_motor:
        raise RuntimeError("No hay ningún motor lector de PDF disponible (instala pypdf o pymupdf).")

    nombre_archivo = os.path.basename(ruta_limpia)
    paginas_resultado = []
    errores_lectura = []

    # 1. Carga base tolerante a fallos con PyPDFLoader
    paginas_base = []
    if PYPDFLOADER_DISPONIBLE and PyPDFLoader is not None:
        try:
            cargador = PyPDFLoader(ruta_limpia)
            paginas_base = cargador.load() or []
        except Exception as e:
            errores_lectura.append(f"PyPDFLoader: {e}")

    # 2. Lector pypdf crudo para metadatos/imágenes o respaldo de texto (incluye desbloqueo con clave vacía)
    lector_raw = None
    paginas_raw = []
    if PYPDF_DISPONIBLE and PdfReader is not None:
        try:
            lector_raw = PdfReader(ruta_limpia)
            if getattr(lector_raw, "is_encrypted", False):
                try:
                    lector_raw.decrypt("")
                except Exception:
                    pass
            if getattr(lector_raw, "is_encrypted", False):
                errores_lectura.append("PdfReader: El PDF está protegido con contraseña")
                lector_raw = None
            else:
                paginas_raw = list(lector_raw.pages)
        except Exception as e:
            errores_lectura.append(f"PdfReader: {e}")
            lector_raw = None

    # 3. Apertura única de PyMuPDF (fitz) para todo el documento evitando fugas y reaperturas O(N)
    doc_fitz = None
    if PYMUPDF_DISPONIBLE and fitz is not None:
        try:
            doc_fitz = fitz.open(ruta_limpia)
            if getattr(doc_fitz, "needs_pass", False):
                autenticado = False
                try:
                    autenticado = bool(doc_fitz.authenticate(""))
                except Exception:
                    autenticado = False
                if not autenticado:
                    errores_lectura.append("PyMuPDF: El PDF está protegido con contraseña")
                    doc_fitz.close()
                    doc_fitz = None
        except Exception as e:
            errores_lectura.append(f"PyMuPDF: {e}")
            doc_fitz = None

    try:
        len_fitz = len(doc_fitz) if doc_fitz is not None else 0
        total_paginas = max(len(paginas_base), len(paginas_raw), len_fitz)

        if total_paginas == 0 and errores_lectura:
            raise ValueError(f"No se pudo leer el PDF '{nombre_archivo}': {'; '.join(errores_lectura)}")

        # Alinear índices de páginas devueltas por PyPDFLoader con el índice físico real de página (0..N-1)
        mapa_paginas_base = {}
        if len(paginas_base) == total_paginas:
            mapa_paginas_base = {i: paginas_base[i] for i in range(total_paginas)}
        else:
            for i_doc, doc_b in enumerate(paginas_base):
                meta_b = getattr(doc_b, "metadata", None) or {}
                pag_idx = meta_b.get("page", i_doc)
                if isinstance(pag_idx, int) and 0 <= pag_idx < total_paginas and pag_idx not in mapa_paginas_base:
                    mapa_paginas_base[pag_idx] = doc_b

        # Recorrido página a página combinando texto digital + OCR selectivo + detección gráfica
        for idx in range(total_paginas):
            texto_nativo = ""
            meta_base = {}
            page_pypdf = paginas_raw[idx] if idx < len(paginas_raw) else None

            if idx in mapa_paginas_base:
                doc_b = mapa_paginas_base[idx]
                texto_nativo = (doc_b.page_content or "").strip()
                meta_base = dict(doc_b.metadata or {})

            if not texto_nativo and page_pypdf is not None:
                try:
                    texto_nativo = (page_pypdf.extract_text() or "").strip()
                except Exception:
                    texto_nativo = ""

            if not texto_nativo and doc_fitz is not None and idx < len_fitz:
                try:
                    texto_nativo = (doc_fitz[idx].get_text("text") or "").strip()
                except Exception:
                    texto_nativo = ""

            tiene_imagenes = (
                _detectar_objetos_imagen_pypdf(page_pypdf)
                or _detectar_objetos_graficos_fitz(doc_fitz, idx)
            )

            # Activar OCR solo si el texto nativo no alcanza el umbral mínimo (ahorra tiempo en memorias digitales)
            texto_ocr = ""
            if len(texto_nativo) < umbral_efectivo and RAPIDOCR_DISPONIBLE and (
                tiene_imagenes or PYMUPDF_DISPONIBLE or page_pypdf is not None
            ):
                texto_ocr = _extraer_texto_ocr_pagina(
                    ruta_limpia, idx, page_pypdf=page_pypdf, doc_fitz=doc_fitz
                )

            if texto_nativo and texto_ocr:
                texto_combinado = f"{texto_nativo}\n[Texto extraído de imagen (OCR)]:\n{texto_ocr}"
            elif texto_ocr:
                texto_combinado = f"[Texto extraído de imagen (OCR)]:\n{texto_ocr}"
            else:
                texto_combinado = texto_nativo

            # Enriquecer metadatos de trazabilidad para los Agentes 1 y 2
            meta_base["source"] = ruta_limpia
            meta_base["archivo_origen"] = nombre_archivo
            meta_base["page"] = idx + 1
            meta_base["contiene_imagenes"] = bool(tiene_imagenes or texto_ocr)
            meta_base["ocr_aplicado"] = bool(texto_ocr)

            if texto_combinado:
                contenido_final = (
                    f"[Documento: {nombre_archivo} | Página {idx + 1}]\n{texto_combinado}"
                    if incluir_cabecera_documento else texto_combinado
                )
                paginas_resultado.append(Document(page_content=contenido_final, metadata=meta_base))
            elif tiene_imagenes or idx == 0:
                # Preservar huella documental de planos mudos o portadas gráficas sin texto reconocible
                descripcion_grafica = (
                    f"[Documento: {nombre_archivo} | Página {idx + 1} | CONTENIDO GRÁFICO / PLANO / IMAGEN]\n"
                    f"Archivo PDF con contenido gráfico o plano sin texto adicional. "
                    f"Nombre de archivo para clasificación: {nombre_archivo}."
                )
                paginas_resultado.append(Document(page_content=descripcion_grafica, metadata=meta_base))
    finally:
        # Cierre garantizado del descriptor nativo de PyMuPDF para evitar bloqueos de archivo en Windows
        if doc_fitz is not None:
            try:
                doc_fitz.close()
            except Exception:
                pass

    return paginas_resultado
