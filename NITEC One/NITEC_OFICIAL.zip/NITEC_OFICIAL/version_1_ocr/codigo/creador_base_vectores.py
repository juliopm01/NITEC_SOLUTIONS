"""
Módulo: creador_base_vectores.py
================================================================================
Propósito general:
    Construye la base de datos vectorial temporal de trabajo del proyecto activo
    (`./bd_vectores` sobre ChromaDB + `nomic-embed-text`) para alimentar la
    búsqueda híbrida (Vectorial + BM25) del Agente 1 al extraer metadatos legales
    (fase de tramitación y fecha oficial de aprobación).

Funcionamiento paso a paso:
    1. Acepta tanto una carpeta de proyecto como la ruta directa a un PDF dentro
       de ella (tomando automáticamente su carpeta contenedora).
    2. Recorre recursivamente la carpeta del proyecto excluyendo directorios
       internos (`salida_empaquetada`, `partes_divididas`, `bd_vectores`, etc.)
       y descartando fragmentos previamente cortados (`_parte_`, `_tomo_`).
    3. Extrae texto digital + OCR de imágenes de cada PDF mediante `cargar_pdf_con_ocr`
       y etiqueta cada fragmento con `carpeta_proyecto` para impedir contaminación
       cruzada entre proyectos distintos.
    4. Reemplaza `./bd_vectores` de manera transaccional (backup temporal + rollback
       automático si falla Ollama/Chroma) y libera al instante el bloqueo SQLite.
================================================================================
"""

import gc
import os
import shutil
import stat
import sys
import time

try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
    from langchain_ollama import OllamaEmbeddings
    from langchain_chroma import Chroma
    LANGCHAIN_DISPONIBLE = True
except Exception:
    RecursiveCharacterTextSplitter = None
    OllamaEmbeddings = None
    Chroma = None
    LANGCHAIN_DISPONIBLE = False

from lector_ocr_pdf import cargar_pdf_con_ocr

# Rutas del directorio del sistema y de la base vectorial activa
DIRECTORIO_BASE = os.path.dirname(os.path.abspath(__file__))
RUTA_BD_PROYECTO = os.path.join(DIRECTORIO_BASE, "bd_vectores")

# Carpetas internas excluidas para no re-indexar bases de datos ni entregas ya empaquetadas
_CARPETAS_EXCLUIDAS = {
    ".git", "__pycache__", "bd_vectores", "bd_normativas",
    "normativas_pdf", "partes_divididas", "salida_empaquetada",
}


def _imprimir(mensaje):
    """Imprime de forma segura en consolas Windows cp1252 o flujos redirigidos."""
    try:
        print(mensaje)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        seguro = str(mensaje).encode(enc, errors="replace").decode(enc, errors="replace")
        print(seguro)


def _forzar_desbloqueo(func, path, *_):
    """Elimina atributo de solo lectura en Windows y reintenta borrar (compatible Python 3.10-3.14+)."""
    try:
        os.chmod(path, stat.S_IWRITE)
        func(path)
    except Exception:
        pass


def _rmtree_compatible(ruta):
    """Borra recursivamente un directorio adaptándose al parámetro `onexc`/`onerror` según la versión de Python."""
    if sys.version_info >= (3, 12):
        shutil.rmtree(ruta, onexc=_forzar_desbloqueo)
    else:
        shutil.rmtree(ruta, onerror=_forzar_desbloqueo)


def limpiar_bd_anterior(ruta_bd):
    """
    Elimina la carpeta de base vectorial anterior gestionando posibles bloqueos
    transitorios de archivos SQLite/HNSW en Windows con reintentos progresivos.
    """
    if not os.path.exists(ruta_bd):
        return
    _imprimir("   🗑️ Borrando memoria anterior del proyecto...")
    gc.collect()
    for intento in range(5):
        try:
            _rmtree_compatible(ruta_bd)
            if not os.path.exists(ruta_bd):
                break
        except PermissionError:
            gc.collect()
            time.sleep(0.5 * (intento + 1))
        except Exception:
            time.sleep(0.3)

    # Limpieza manual archivo por archivo como último recurso si algún subelemento resistió `rmtree`
    if os.path.exists(ruta_bd):
        for root, dirs, files in os.walk(ruta_bd, topdown=False):
            for name in files:
                ruta_f = os.path.join(root, name)
                try:
                    os.chmod(ruta_f, stat.S_IWRITE)
                    os.unlink(ruta_f)
                except Exception:
                    pass
            for name in dirs:
                try:
                    os.rmdir(os.path.join(root, name))
                except Exception:
                    pass


def _descubrir_pdfs_proyecto(ruta_carpeta):
    """Localiza todos los PDFs del proyecto (incluyendo subcarpetas), excluyendo artefactos ya divididos."""
    rutas_pdf = []
    for raiz, subcarpetas, archivos in os.walk(ruta_carpeta):
        subcarpetas[:] = sorted([
            d for d in subcarpetas
            if d.lower() not in _CARPETAS_EXCLUIDAS and not d.startswith(".")
        ])
        for archivo in sorted(archivos):
            nombre_low = archivo.lower()
            if (
                nombre_low.endswith(".pdf")
                and "_tomo_" not in nombre_low
                and "_parte_" not in nombre_low
            ):
                ruta_completa = os.path.join(raiz, archivo)
                if os.path.isfile(ruta_completa) and os.path.getsize(ruta_completa) > 0:
                    rutas_pdf.append(ruta_completa)
    return rutas_pdf


def ingestar_proyecto(ruta_carpeta):
    """
    Lee todos los documentos PDF del proyecto (texto digital + OCR de imágenes),
    los divide en fragmentos semánticos y construye `./bd_vectores` de forma segura.
    """
    if ruta_carpeta is None or not str(ruta_carpeta).strip():
        return {"estado": "ERROR", "mensaje": "Ruta de carpeta vacía."}

    ruta_carpeta = str(ruta_carpeta).strip().strip('"').strip("'")
    # Si el usuario pasó la ruta de un PDF concreto en lugar de su carpeta, subir al directorio padre
    if os.path.isfile(ruta_carpeta) and ruta_carpeta.lower().endswith(".pdf"):
        ruta_carpeta = os.path.dirname(os.path.abspath(ruta_carpeta))

    _imprimir(f"⚙️ Construyendo base de datos del proyecto (con soporte OCR de imágenes) desde: {ruta_carpeta}")

    if not os.path.isdir(ruta_carpeta):
        _imprimir(f"   ❌ La carpeta no existe: {ruta_carpeta}")
        return {"estado": "ERROR", "mensaje": "La carpeta no existe."}

    rutas_pdf = _descubrir_pdfs_proyecto(ruta_carpeta)
    if not rutas_pdf:
        _imprimir("   ⚠️ No se encontraron PDFs válidos en la carpeta.")
        return {"estado": "ERROR", "mensaje": "No se encontraron PDFs."}

    carpeta_proyecto_abs = os.path.abspath(ruta_carpeta)
    documentos = []
    for ruta_completa in rutas_pdf:
        archivo = os.path.basename(ruta_completa)
        try:
            docs_pdf = cargar_pdf_con_ocr(ruta_completa, incluir_cabecera_documento=True)
            for doc_p in docs_pdf:
                if isinstance(doc_p.metadata, dict):
                    # Sellar la carpeta raíz exacta del proyecto para validación posterior en el Agente 1
                    doc_p.metadata["carpeta_proyecto"] = carpeta_proyecto_abs
            documentos.extend(docs_pdf)
        except Exception as e:
            _imprimir(f"   ⚠️ Error leyendo {archivo}: {e}")

    if not documentos:
        return {"estado": "ERROR", "mensaje": "No se pudo extraer contenido de los PDFs."}

    if not LANGCHAIN_DISPONIBLE or RecursiveCharacterTextSplitter is None or Chroma is None:
        return {"estado": "ERROR", "mensaje": "Faltan dependencias de LangChain/Chroma. Ejecuta: pip install -r requirements.txt"}

    guillotina = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    fragmentos = [
        frag for frag in guillotina.split_documents(documentos)
        if frag.page_content and frag.page_content.strip()
    ]

    if not fragmentos:
        return {"estado": "ERROR", "mensaje": "No se generaron fragmentos válidos."}

    # Escritura transaccional sobre `./bd_vectores` con respaldo automático en caso de error
    db = None
    ruta_respaldo = f"{RUTA_BD_PROYECTO}_backup_tmp"
    habia_respaldo = False
    try:
        limpiar_bd_anterior(ruta_respaldo)
        if os.path.exists(RUTA_BD_PROYECTO):
            shutil.copytree(RUTA_BD_PROYECTO, ruta_respaldo)
            habia_respaldo = True
        limpiar_bd_anterior(RUTA_BD_PROYECTO)

        modelo_coordenadas = OllamaEmbeddings(model="nomic-embed-text")
        db = Chroma.from_documents(
            documents=fragmentos,
            embedding=modelo_coordenadas,
            persist_directory=RUTA_BD_PROYECTO
        )
        if habia_respaldo:
            limpiar_bd_anterior(ruta_respaldo)
    except Exception as e:
        if db is not None:
            del db
            db = None
        gc.collect()
        if habia_respaldo and os.path.exists(ruta_respaldo):
            limpiar_bd_anterior(RUTA_BD_PROYECTO)
            try:
                shutil.copytree(ruta_respaldo, RUTA_BD_PROYECTO)
            except Exception:
                pass
            limpiar_bd_anterior(ruta_respaldo)
        _imprimir(f"   ❌ Error al crear la base vectorial del proyecto: {e}")
        return {"estado": "ERROR", "mensaje": f"Error al indexar vectores: {e}"}
    finally:
        # Liberar conexión SQLite antes de retornar al orquestador
        if db is not None:
            del db
        gc.collect()

    _imprimir("   ✅ Base de datos del proyecto lista.")
    return {"estado": "COMPLETADO", "fragmentos": len(fragmentos)}


if __name__ == "__main__":
    if len(sys.argv) > 1:
        res = ingestar_proyecto(sys.argv[1])
        if res.get("estado") == "ERROR":
            sys.exit(1)
    else:
        _imprimir("Uso: python creador_base_vectores.py <ruta_carpeta>")
