"""
Módulo: creador_base_datos.py
================================================================================
Propósito general:
    Archivador e ingestor vectorial permanente de normativas legales y ordenanzas
    municipales/autonómicas (`./bd_normativas` sobre ChromaDB + `nomic-embed-text`).

Funcionamiento paso a paso:
    1. Recibe opcionalmente un PDF normativo nuevo y lo archiva en `./normativas_pdf`.
    2. Escanea recursivamente `./normativas_pdf` y lee todos los PDFs en paralelo
       (`ThreadPoolExecutor`) con soporte OCR (`cargar_pdf_con_ocr`).
    3. Etiqueta cada página con el metadato `municipio` deducido del nombre del
       archivo (`detectar_municipio_en_nombre`):
         - `'general'` si se trata de un boletín autonómico (BOJA, BOCM, DOGC, etc.).
         - El nombre normalizado del municipio (p. ej. `'malaga'`, `'velez_malaga'`)
           si se trata de una ordenanza o instrucción técnica local.
    4. Trocea los textos (`chunk_size=1000`, `chunk_overlap=200`) y reconstruye
       `./bd_normativas` de forma **transaccional** con copia de respaldo previa
       (`_backup_tmp`) y restauración automática (rollback) si falla Ollama o Chroma.
================================================================================
"""

import gc
import os
import re
import shutil
import stat
import sys
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor

try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
    from langchain_ollama import OllamaEmbeddings
    from langchain_chroma import Chroma
    LANGCHAIN_DISPONIBLE = True
except Exception:
    RecursiveCharacterTextSplitter = None
    OllamaEmbeddings = None
    Chroma = None
    LANGCHAIN_DISPONIBLE = False

from lector_ocr_pdf import cargar_pdf_con_ocr

try:
    from geo_localizador import cargar_base_datos
except Exception:
    cargar_base_datos = lambda: {}

# Rutas permanentes de normativas en PDF y base vectorial legal ancladas al módulo
DIRECTORIO_BASE = os.path.dirname(os.path.abspath(__file__))
CARPETA_LEYES = os.path.join(DIRECTORIO_BASE, "normativas_pdf")
RUTA_BD_LEGAL = os.path.join(DIRECTORIO_BASE, "bd_normativas")

# Palabras genéricas descartadas al inferir el nombre de un municipio desde el nombre del PDF
_PREFIJOS_RUIDO_MUNICIPIO = {
    "urbanistica", "urbanistico", "municipal", "local", "reguladora",
    "general", "sede", "electronica", "digital", "de", "del",
}

_SUFIJOS_RUIDO_MUNICIPIO = {
    "urbanistica", "urbanistico", "municipal", "local", "pdf",
    "definitiva", "inicial", "provisional", "consolidada", "vigente",
}


def _imprimir(mensaje):
    """Imprime de forma segura en consolas Windows cp1252 o flujos redirigidos."""
    try:
        print(mensaje)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        seguro = str(mensaje).encode(enc, errors="replace").decode(enc, errors="replace")
        print(seguro)


def _normalizar(texto):
    """Convierte un texto en identificador alfanumérico en minúsculas separado por guiones bajos."""
    if texto is None or isinstance(texto, bool):
        return ""
    texto = str(texto).strip().lower()
    if not texto:
        return ""
    texto_sin_tildes = "".join(
        c for c in unicodedata.normalize("NFD", texto)
        if unicodedata.category(c) != "Mn"
    )
    texto_limpio = re.sub(r"[\s\-–—_/.,;:'’‘\"“”()·]+", "_", texto_sin_tildes)
    return re.sub(r"[^a-z0-9_]", "", texto_limpio).strip("_")


def _limpiar_tokens_municipio(tokens):
    """Elimina prefijos/sufijos administrativos, años (ej. 2025) y versiones (ej. v2) de un nombre candidato."""
    lista = [t for t in tokens if t]
    while lista and lista[0] in _PREFIJOS_RUIDO_MUNICIPIO:
        lista.pop(0)
    while lista and (
        lista[-1] in _SUFIJOS_RUIDO_MUNICIPIO
        or re.fullmatch(r"(?:19|20)\d{2}", lista[-1])
        or re.fullmatch(r"v\d+", lista[-1])
    ):
        lista.pop()
    candidato = "_".join(lista).strip("_")
    if candidato and candidato not in ("general", "local", "municipal", "urbanistica", "pdf"):
        return candidato
    return ""


def detectar_municipio_en_nombre(nombre_archivo):
    """
    Deduce a qué municipio corresponde un PDF normativo a partir de su nombre:
    - Si es un boletín autonómico (BOJA, BOCM, etc.), devuelve `'general'`.
    - Si coincide con un municipio registrado (priorizando nombres compuestos más largos como
      `velez_malaga` antes que `malaga`), devuelve dicho municipio normalizado.
    - Si sigue patrones como `ordenanza_coin_2025.pdf` o `marbella_normativa.pdf`, extrae el municipio.
    """
    base_sin_ext = os.path.splitext(os.path.basename(str(nombre_archivo or "")))[0]
    nombre_norm = _normalizar(base_sin_ext)
    if not nombre_norm:
        return "general"

    palabras_boletin = (
        "boja", "boletin", "junta_de_andalucia", "normativa_autonomica",
        "normativa_general", "bocm", "dogc", "dogv", "nitec",
    )
    if any(p in nombre_norm for p in palabras_boletin):
        return "general"

    # Buscar primero contra el catálogo conocido ordenando de mayor a menor longitud
    db_municipios = cargar_base_datos() or {}
    claves_ordenadas = sorted(db_municipios.keys(), key=len, reverse=True)
    for muni in claves_ordenadas:
        muni_norm = _normalizar(muni)
        if muni_norm and re.search(rf"(?:^|_){re.escape(muni_norm)}(?:_|$)", nombre_norm):
            return muni_norm

    # Patrón con prefijo administrativo: ej. "ordenanza_urbanistica_coin_2024" -> "coin"
    coincidencia_prefijo = re.match(
        r"^(?:normativa|ordenanza|ayuntamiento(?:_de)?|municipio(?:_de)?|pgou|pgom|reglamento)_+([a-z0-9_]+)$",
        nombre_norm,
    )
    if coincidencia_prefijo:
        candidato = _limpiar_tokens_municipio(coincidencia_prefijo.group(1).split("_"))
        if candidato:
            return candidato

    # Patrón con sufijo administrativo: ej. "rincon_de_la_victoria_ordenanza" -> "rincon_de_la_victoria"
    coincidencia_sufijo = re.match(
        r"^([a-z0-9_]+?)_+(?:normativa|ordenanza|reglamento|pgou|pgom)(?:_[a-z0-9_]+)?$",
        nombre_norm,
    )
    if coincidencia_sufijo:
        candidato = _limpiar_tokens_municipio(coincidencia_sufijo.group(1).split("_"))
        if candidato:
            return candidato

    return "general"


def procesar_pdf(archivo, carpeta_leyes=None):
    """Lee un PDF normativo con soporte OCR y enriquece cada página con metadatos legales y municipales."""
    carpeta_activa = carpeta_leyes or CARPETA_LEYES
    ruta_completa = archivo if os.path.isabs(archivo) else os.path.join(carpeta_activa, archivo)
    nombre_base = os.path.basename(ruta_completa)
    muni_detectado = detectar_municipio_en_nombre(nombre_base)
    try:
        paginas = cargar_pdf_con_ocr(ruta_completa, incluir_cabecera_documento=False)
        paginas_validas = []
        for pagina in paginas:
            if pagina.page_content and pagina.page_content.strip():
                pagina.metadata["categoria"] = "NORMATIVA_LEGAL"
                pagina.metadata["archivo_origen"] = nombre_base
                pagina.metadata["municipio"] = muni_detectado
                paginas_validas.append(pagina)
        return paginas_validas
    except Exception as e:
        _imprimir(f"   ⚠️ Error leyendo {nombre_base}: {e}")
        return []


def _desbloquear_ruta(func, path, *_):
    """Quita el atributo de solo lectura en Windows y reintenta la operación de borrado."""
    try:
        os.chmod(path, stat.S_IWRITE)
        func(path)
    except Exception:
        pass


def _rmtree_compatible(ruta):
    """Elimina un árbol de directorios usando `onexc` (Python 3.12+) u `onerror` (Python <=3.11)."""
    if sys.version_info >= (3, 12):
        shutil.rmtree(ruta, onexc=_desbloquear_ruta)
    else:
        shutil.rmtree(ruta, onerror=_desbloquear_ruta)


def _limpiar_bd_legal_si_existe(ruta_bd):
    """Libera referencias del recolector de basura y elimina de forma segura una carpeta ChromaDB en Windows."""
    if not os.path.exists(ruta_bd):
        return
    gc.collect()
    for intento in range(4):
        try:
            _rmtree_compatible(ruta_bd)
            if not os.path.exists(ruta_bd):
                break
        except PermissionError:
            gc.collect()
            time.sleep(0.3 * (intento + 1))
        except Exception:
            time.sleep(0.2)


def ingestar_normativas(ruta_pdf_extra=None):
    """
    Ejecuta el flujo completo de indexación de normativas legales en `./bd_normativas`:
    copia cualquier PDF nuevo indicado en `ruta_pdf_extra`, lee todos los boletines/ordenanzas,
    fragmenta sus textos y actualiza ChromaDB con respaldo transaccional ante fallos.
    """
    _imprimir("⚖️ Iniciando el Archivador Legal (Ingesta de Normativas con soporte OCR)...")

    if not os.path.exists(CARPETA_LEYES):
        os.makedirs(CARPETA_LEYES, exist_ok=True)
        _imprimir(f"📂 Carpeta creada: {CARPETA_LEYES}.")

    # Si se suministra una ruta externa a un PDF normativo, copiarlo primero al almacén central
    if ruta_pdf_extra:
        ruta_limpia = str(ruta_pdf_extra).strip().strip('"').strip("'")
        if os.path.isfile(ruta_limpia) and ruta_limpia.lower().endswith(".pdf") and os.path.getsize(ruta_limpia) > 0:
            destino = os.path.join(CARPETA_LEYES, os.path.basename(ruta_limpia))
            if os.path.abspath(ruta_limpia) != os.path.abspath(destino):
                try:
                    shutil.copy2(ruta_limpia, destino)
                    _imprimir(f"📥 PDF normativo copiado a {CARPETA_LEYES}: {os.path.basename(ruta_limpia)}")
                except Exception as e:
                    _imprimir(f"   ⚠️ No se pudo copiar {ruta_limpia}: {e}")

    # Recopilar todos los PDFs no vacíos dentro de `./normativas_pdf` y sus subdirectorios
    archivos_pdf = []
    for raiz, subdirs, archivos in os.walk(CARPETA_LEYES):
        subdirs[:] = sorted([d for d in subdirs if not d.startswith(".")])
        for f in sorted(archivos):
            ruta_f = os.path.join(raiz, f)
            if f.lower().endswith(".pdf") and os.path.isfile(ruta_f) and os.path.getsize(ruta_f) > 0:
                archivos_pdf.append(ruta_f)

    if not archivos_pdf:
        _imprimir("⚠️ No hay normativas en './normativas_pdf' para procesar. Fin del archivador legal.")
        return {"estado": "SIN_NORMATIVAS", "paginas": 0}

    # Procesar primero los archivos más ligeros para equilibrar los hilos de lectura
    archivos_pdf.sort(key=os.path.getsize)

    documentos_legales = []
    carpeta_actual = CARPETA_LEYES
    with ThreadPoolExecutor(max_workers=min(4, len(archivos_pdf))) as ejecutor:
        resultados = ejecutor.map(lambda arch: procesar_pdf(arch, carpeta_actual), archivos_pdf)
        for paginas in resultados:
            documentos_legales.extend(paginas)

    if not documentos_legales:
        _imprimir("⚠️ No se pudo extraer texto de los PDFs legales.")
        return {"estado": "ERROR", "mensaje": "PDFs sin texto extraíble"}

    _imprimir(f"📚 Total de páginas legales leídas: {len(documentos_legales)}")

    if not LANGCHAIN_DISPONIBLE or RecursiveCharacterTextSplitter is None or Chroma is None:
        return {"estado": "ERROR", "mensaje": "Faltan dependencias de LangChain/Chroma. Ejecuta: pip install -r requirements.txt"}

    # Fragmentación con solapamiento de 200 caracteres para no cortar frases donde se citen límites en MB
    guillotina = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    fragmentos_legales = [
        frag for frag in guillotina.split_documents(documentos_legales)
        if frag.page_content and frag.page_content.strip()
    ]

    if not fragmentos_legales:
        return {"estado": "ERROR", "mensaje": "Fragmentos vacíos tras procesar PDFs legales"}

    # Reconstrucción transaccional: se guarda copia previa y se restaura si falla la vectorización
    base_de_datos_leyes = None
    ruta_respaldo = f"{RUTA_BD_LEGAL}_backup_tmp"
    habia_respaldo = False
    try:
        _limpiar_bd_legal_si_existe(ruta_respaldo)
        if os.path.exists(RUTA_BD_LEGAL):
            shutil.copytree(RUTA_BD_LEGAL, ruta_respaldo)
            habia_respaldo = True
        _limpiar_bd_legal_si_existe(RUTA_BD_LEGAL)

        modelo_coordenadas = OllamaEmbeddings(model="nomic-embed-text")
        _imprimir(f"💾 Guardando normativas de forma permanente en: {RUTA_BD_LEGAL}")
        base_de_datos_leyes = Chroma.from_documents(
            documents=fragmentos_legales,
            embedding=modelo_coordenadas,
            persist_directory=RUTA_BD_LEGAL
        )
        if habia_respaldo:
            _limpiar_bd_legal_si_existe(ruta_respaldo)
    except Exception as e:
        if base_de_datos_leyes is not None:
            del base_de_datos_leyes
            base_de_datos_leyes = None
        gc.collect()
        # Rollback: restaurar base de datos legal previa intacta
        if habia_respaldo and os.path.exists(ruta_respaldo):
            _limpiar_bd_legal_si_existe(RUTA_BD_LEGAL)
            try:
                shutil.copytree(ruta_respaldo, RUTA_BD_LEGAL)
            except Exception:
                pass
            _limpiar_bd_legal_si_existe(ruta_respaldo)
        _imprimir(f"❌ Error al indexar normativas legales en Chroma: {e}")
        return {"estado": "ERROR", "mensaje": f"Fallo al indexar normativas legales: {e}"}
    finally:
        # Liberar descriptores SQLite de ChromaDB inmediatamente en Windows
        if base_de_datos_leyes is not None:
            del base_de_datos_leyes
        gc.collect()

    _imprimir("✅ Archivador Legal completado. Las leyes están listas para ser consultadas.")
    return {"estado": "COMPLETADO", "paginas": len(documentos_legales)}


if __name__ == "__main__":
    ruta_arg = sys.argv[1] if len(sys.argv) > 1 else None
    resultado = ingestar_normativas(ruta_arg)
    if resultado.get("estado") == "ERROR":
        sys.exit(1)
