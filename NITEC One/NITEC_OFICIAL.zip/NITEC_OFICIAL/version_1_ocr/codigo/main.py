"""
Módulo: main.py (Orquestador Principal del Sistema Multi-Agente NITEC)
================================================================================
Propósito general:
    Coordina interactivamente y de extremo a extremo la ejecución secuencial de
    todos los subsistemas y agentes del proyecto:
      1. Recopilación validada de datos del expediente (municipio, resolución
         automática de provincia/CCAA y código INE de 5 dígitos con aprendizaje
         persistente, siglas del instrumento urbanístico y rutas del proyecto).
      2. Pre-vuelo de bases vectoriales (`comprobar_y_crear_bases_datos`):
         Verifica marcas de tiempo (`mtime`) de `./bd_normativas` frente a los
         PDFs de `./normativas_pdf` e indexa la carpeta activa en `./bd_vectores`
         mediante subprocesos forzados a UTF-8 (`PYTHONUTF8=1`).
      3. Ejecución encadenada de los 3 Agentes:
         - Agente 1 (`extraer_metadatos` + `clasificar_archivos_proyecto`) ->
           genera metadatos de carátula y `especificaciones_agente_1.json`.
         - Agente 2 (`ejecutar_agente_2`) -> obtiene la normativa autonómica
           desde `boja_base.json` (o lee una sola vez el PDF del boletín) y el
           límite municipal de peso (pidiéndolo a mano solo la primera vez).
         - Agente 3 (`ejecutar_agente_3`) -> comprime sin pérdida, fragmenta por
           peso y construye la carpeta final con estructura y nombres BOJA.
================================================================================
"""

import json
import os
import re
import subprocess
import sys
import unicodedata

from geo_localizador import obtener_datos_geograficos, registrar_municipio, obtener_codigo_ine
from agente_2_normativo_local import ejecutar_agente_2
from agente_3_procesador import ejecutar_agente_3

try:
    from agente_1_extractor import extraer_metadatos, clasificar_archivos_proyecto
    AGENTE_1_DISPONIBLE = True
except Exception:
    extraer_metadatos = None
    clasificar_archivos_proyecto = None
    AGENTE_1_DISPONIBLE = False

# Rutas del sistema ancladas al directorio fuente para funcionar desde cualquier CWD
DIRECTORIO_BASE = os.path.dirname(os.path.abspath(__file__))
RUTA_BOJA_JSON = os.path.join(DIRECTORIO_BASE, "boja_base.json")
CARPETA_NORMATIVAS_PDF = os.path.join(DIRECTORIO_BASE, "normativas_pdf")
RUTA_BD_NORMATIVAS = os.path.join(DIRECTORIO_BASE, "bd_normativas")

# Directorios excluidos durante la autodetección del PDF principal del proyecto
_CARPETAS_EXCLUIDAS = {
    ".git", "__pycache__", "bd_vectores", "bd_normativas",
    "normativas_pdf", "partes_divididas", "salida_empaquetada",
}


def _imprimir(mensaje=""):
    """Imprime de forma segura en consolas Windows cp1252 o flujos redirigidos."""
    try:
        print(mensaje)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        seguro = str(mensaje).encode(enc, errors="replace").decode(enc, errors="replace")
        print(seguro)


def _limpiar_ruta(ruta):
    """Elimina espacios y comillas simples/dobles habituales al arrastrar rutas en la terminal."""
    if not ruta:
        return ""
    return str(ruta).strip().strip('"').strip("'")


def _normalizar(texto):
    """Normaliza cadenas eliminando tildes y convirtiendo separadores en guiones bajos."""
    if not texto or isinstance(texto, bool):
        return ""
    texto = str(texto).strip().lower()
    texto_sin_tildes = "".join(
        c for c in unicodedata.normalize("NFD", texto)
        if unicodedata.category(c) != "Mn"
    )
    texto_limpio = re.sub(r"[\s\-–—_/.,;:'’‘\"“”()·]+", "_", texto_sin_tildes)
    return re.sub(r"[^a-z0-9_]", "", texto_limpio).strip("_")


def _input_consola_seguro(prompt=""):
    """Ejecuta input() degradando limpiamente emojis si sys.stdout usa codificación cp1252/ascii."""
    try:
        return input(prompt)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        prompt_seguro = str(prompt).encode(enc, errors="replace").decode(enc, errors="replace")
        return input(prompt_seguro)


def _leer_input_seguro(prompt):
    """Lee una entrada opcional del usuario devolviendo `''` si el flujo estándar se cierra (`EOFError`)."""
    try:
        return _input_consola_seguro(prompt)
    except EOFError:
        return ""


def _pedir_texto_no_vacio(prompt, valor_por_defecto=None, max_intentos=5):
    """Solicita un dato obligatorio hasta `max_intentos` veces sin quedarse en bucle infinito."""
    for _ in range(max_intentos):
        try:
            valor = _input_consola_seguro(prompt).strip()
        except EOFError:
            return valor_por_defecto if valor_por_defecto is not None else ""
        if valor:
            return valor
        if valor_por_defecto is not None:
            return valor_por_defecto
        _imprimir("   ❌ Este campo no puede estar vacío. Inténtalo de nuevo.")
    return valor_por_defecto or ""


def _extraer_entero_positivo_usuario(texto):
    """Extrae un entero positivo ASCII (ej. '25' o '25 MB'), rechazando superíndices Unicode ('²') o negativos."""
    if not texto:
        return None
    limpio = str(texto).strip()
    if re.match(r"^\s*-", limpio):
        return None
    m = re.match(r"^([0-9]+)(?:\s*(?:mb|megabytes?|megas?))?$", limpio, flags=re.IGNORECASE)
    if m:
        valor = int(m.group(1))
        return valor if valor > 0 else None
    return None


def _autodetectar_pdf_principal(ruta_carpeta_proyecto):
    """
    Selecciona automáticamente el primer PDF válido del proyecto cuando el usuario pulsa Enter,
    priorizando archivos en la raíz del proyecto frente a subcarpetas e ignorando fragmentos previos.
    """
    if not ruta_carpeta_proyecto or not os.path.isdir(ruta_carpeta_proyecto):
        return ""

    # Prioridad 1: PDFs no vacíos en la raíz de la carpeta del proyecto
    pdfs_raiz = sorted([
        os.path.join(ruta_carpeta_proyecto, f)
        for f in os.listdir(ruta_carpeta_proyecto)
        if f.lower().endswith(".pdf")
        and "_tomo_" not in f.lower()
        and "_parte_" not in f.lower()
        and os.path.isfile(os.path.join(ruta_carpeta_proyecto, f))
        and os.path.getsize(os.path.join(ruta_carpeta_proyecto, f)) > 0
    ])
    if pdfs_raiz:
        return pdfs_raiz[0]

    # Prioridad 2: PDFs no vacíos en subcarpetas del proyecto (excluyendo carpetas internas del sistema)
    for raiz, subcarpetas, archivos in os.walk(ruta_carpeta_proyecto):
        subcarpetas[:] = sorted([
            d for d in subcarpetas
            if not d.startswith(".") and d.lower() not in _CARPETAS_EXCLUIDAS
        ])
        for f in sorted(archivos):
            f_low = f.lower()
            if f_low.endswith(".pdf") and "_tomo_" not in f_low and "_parte_" not in f_low:
                candidato = os.path.join(raiz, f)
                if os.path.isfile(candidato) and os.path.getsize(candidato) > 0:
                    return candidato
    return ""


def _bd_legal_actualizada(ruta_bd_legal, carpeta_normativas):
    """
    Comprueba si `./bd_normativas/chroma.sqlite3` existe, no está vacío y es más reciente
    que todos los PDFs alojados en `./normativas_pdf` (invalidación automática por `mtime`).
    """
    sqlite_file = os.path.join(ruta_bd_legal, "chroma.sqlite3")
    if not os.path.isfile(sqlite_file) or os.path.getsize(sqlite_file) == 0:
        return False
    if os.path.isdir(carpeta_normativas):
        mtime_bd = os.path.getmtime(sqlite_file)
        for raiz, subdirs, archivos in os.walk(carpeta_normativas):
            subdirs[:] = [d for d in subdirs if not d.startswith(".")]
            for f in archivos:
                ruta_f = os.path.join(raiz, f)
                if f.lower().endswith(".pdf") and os.path.isfile(ruta_f):
                    if os.path.getmtime(ruta_f) > mtime_bd:
                        return False
    return True


def _actualizar_bd_legal(ruta_pdf_normativa=None):
    """Ejecuta `creador_base_datos.py` en un subproceso UTF-8 aislado para regenerar `./bd_normativas`."""
    script_bd_legal = os.path.join(DIRECTORIO_BASE, "creador_base_datos.py")
    env_utf8 = dict(os.environ)
    env_utf8["PYTHONIOENCODING"] = "utf-8"
    env_utf8["PYTHONUTF8"] = "1"
    _imprimir("   ⚠️ Actualizando './bd_normativas'. Lanzando ingestor legal...")
    try:
        cmd = [sys.executable, script_bd_legal]
        if ruta_pdf_normativa:
            cmd.append(ruta_pdf_normativa)
        subprocess.run(cmd, check=True, cwd=DIRECTORIO_BASE, env=env_utf8)
        _imprimir("   ✅ Proceso de base de datos legal finalizado.")
        return True
    except Exception as e:
        _imprimir(f"   ❌ Error al crear bd_normativas: {e}")
        return False


def comprobar_y_crear_bases_datos(ruta_carpeta_proyecto, ruta_pdf_normativa=None):
    """Sincroniza `./bd_normativas` si hubo cambios e indexa el proyecto actual en `./bd_vectores`."""
    _imprimir("\n🔍 [Pre-vuelo] Comprobando el estado de las bases de datos...")
    script_bd_vectores = os.path.join(DIRECTORIO_BASE, "creador_base_vectores.py")

    env_utf8 = dict(os.environ)
    env_utf8["PYTHONIOENCODING"] = "utf-8"
    env_utf8["PYTHONUTF8"] = "1"

    if ruta_pdf_normativa or not _bd_legal_actualizada(RUTA_BD_NORMATIVAS, CARPETA_NORMATIVAS_PDF):
        _actualizar_bd_legal(ruta_pdf_normativa)
    else:
        _imprimir("   ✅ Base de datos legal lista.")

    if not ruta_carpeta_proyecto or not os.path.isdir(ruta_carpeta_proyecto):
        _imprimir(f"   ⚠️ Carpeta de proyecto no válida o inexistente: {ruta_carpeta_proyecto}")
        return False

    _imprimir(f"   🔄 Procesando la carpeta del proyecto: {ruta_carpeta_proyecto}")
    try:
        subprocess.run(
            [sys.executable, script_bd_vectores, ruta_carpeta_proyecto],
            check=True,
            cwd=DIRECTORIO_BASE,
            env=env_utf8,
        )
        return True
    except Exception as e:
        _imprimir(f"   ❌ Error al procesar el proyecto: {e}")
        return False


def main():
    """Flujo interactivo completo: geolocalización -> bases vectoriales -> Agente 1 -> Agente 2 -> Agente 3."""
    _imprimir("==================================================")
    _imprimir("🚀 INICIANDO ORQUESTADOR DE PROYECTOS URBANÍSTICOS")
    _imprimir("==================================================\n")

    _imprimir("📋 DATOS DEL PROYECTO")
    municipio = _pedir_texto_no_vacio("👉 Introduce el municipio (ej. Málaga): ")

    # --- RESOLUCIÓN GEOGRÁFICA LOCAL CON PERSISTENCIA ---
    datos_geo = obtener_datos_geograficos(municipio)
    if datos_geo:
        comunidad = datos_geo["comunidad"]
        provincia = datos_geo["provincia"]
        _imprimir(f"   📍 Detectado automáticamente: Provincia de {provincia}, {comunidad}.")
    else:
        _imprimir("   ⚠️ Municipio no encontrado en la base de datos local.")
        provincia = _pedir_texto_no_vacio("   👉 Introduce la provincia manualmente: ")
        comunidad = _pedir_texto_no_vacio("   👉 Introduce la Comunidad Autónoma manualmente: ")
        if municipio and provincia and comunidad:
            registrar_municipio(municipio, provincia, comunidad)
            _imprimir(f"   💾 Municipio '{municipio}' ({provincia}, {comunidad}) guardado en 'municipios_espana.json'.")

    codigo_ine = obtener_codigo_ine(municipio, provincia=provincia)

    tipo_proyecto = _pedir_texto_no_vacio("👉 Introduce el tipo de proyecto (ej. PGOM, ED): ").upper()

    entrada_carpeta = _limpiar_ruta(
        _pedir_texto_no_vacio("👉 Introduce la ruta a la CARPETA del proyecto (con todos los PDFs): ")
    )
    pdf_sugerido = ""
    if entrada_carpeta and os.path.isfile(entrada_carpeta) and entrada_carpeta.lower().endswith(".pdf"):
        pdf_sugerido = entrada_carpeta
        ruta_carpeta_proyecto = os.path.dirname(os.path.abspath(entrada_carpeta))
        _imprimir(f"   📂 Se detectó ruta a archivo PDF; usando carpeta contenedora: {ruta_carpeta_proyecto}")
    else:
        ruta_carpeta_proyecto = entrada_carpeta

    # Autodetección automática del documento principal para carátula sin interrumpir al usuario
    if pdf_sugerido:
        ruta_pdf_proyecto = pdf_sugerido
    elif ruta_carpeta_proyecto and os.path.isdir(ruta_carpeta_proyecto):
        ruta_pdf_proyecto = _autodetectar_pdf_principal(ruta_carpeta_proyecto)
    else:
        ruta_pdf_proyecto = ""

    if ruta_pdf_proyecto:
        _imprimir(f"   ✓ Documento principal autodetectado para carátula: {ruta_pdf_proyecto}")

    # Comprobación inicial de boja_base.json anclada al directorio del sistema
    ruta_pdf_normativa = None
    boja_valido = False
    if os.path.exists(RUTA_BOJA_JSON):
        try:
            with open(RUTA_BOJA_JSON, "r", encoding="utf-8") as f:
                d = json.load(f)
                boja_valido = isinstance(d, dict) and isinstance(d.get("proyectos"), dict)
        except Exception:
            boja_valido = False

    if not boja_valido:
        pdfs_boja = [
            os.path.join(CARPETA_NORMATIVAS_PDF, f)
            for f in os.listdir(CARPETA_NORMATIVAS_PDF)
            if f.lower().endswith(".pdf") and any(k in _normalizar(f) for k in ("boja", "boletin", "junta", "autonomic"))
        ] if os.path.isdir(CARPETA_NORMATIVAS_PDF) else []

        if pdfs_boja:
            ruta_pdf_normativa = pdfs_boja[0]
            _imprimir(f"   📄 Detectado PDF del BOJA en carpeta: {ruta_pdf_normativa}")
        else:
            if _normalizar(comunidad) == "andalucia":
                ruta_pdf_normativa = _limpiar_ruta(
                    _leer_input_seguro("👉 [Configuración Inicial - Solo 1ª vez] Introduce la ruta al PDF del BOJA: ")
                )
            else:
                ruta_pdf_normativa = _limpiar_ruta(
                    _leer_input_seguro(f"👉 [Configuración Inicial - Solo 1ª vez] Introduce la ruta al PDF del boletín de {comunidad}: ")
                )

    comprobar_y_crear_bases_datos(ruta_carpeta_proyecto, ruta_pdf_normativa)

    _imprimir("\n==================================================")

    _imprimir("\n⚙️ [Paso 1] Ejecutando Agente 1 (Extractor de Carátula)...")
    if AGENTE_1_DISPONIBLE and extraer_metadatos is not None:
        try:
            datos_caratula = extraer_metadatos(ruta_pdf_proyecto)
        except Exception as e:
            _imprimir(f"⚠️ Error en Agente 1: {e}")
            datos_caratula = {
                "fase_tramitacion": "NO_ENCONTRADA",
                "fecha_aprobacion": "NO_ENCONTRADA",
                "error": "Fallo en la extracción",
            }
    else:
        _imprimir("⚠️ Archivo 'agente_1_extractor.py' no disponible. Usando metadatos por defecto...")
        datos_caratula = {
            "fase_tramitacion": "NO_ENCONTRADA",
            "fecha_aprobacion": "NO_ENCONTRADA",
        }

    _imprimir("\n⚙️ [Paso 2] Ejecutando Agente 2 (Auditor Normativo Local)...")
    reglas_normativas = ejecutar_agente_2(municipio, tipo_proyecto, ruta_boja_pdf=ruta_pdf_normativa)

    # Si no existía boletín autonómico válido, solicitar ruta hasta 5 intentos y actualizar BD legal
    intentos_boja = 0
    while reglas_normativas.get("estado") == "REQUIERE_BOJA_PDF" and intentos_boja < 5:
        intentos_boja += 1
        _imprimir(f"\n⚠️ {reglas_normativas.get('mensaje')}")
        try:
            nueva_ruta = _limpiar_ruta(_input_consola_seguro("👉 Introduce la ruta válida al PDF del BOJA: "))
        except EOFError:
            break
        if nueva_ruta:
            ruta_pdf_normativa = nueva_ruta
            if os.path.isfile(nueva_ruta) and not _bd_legal_actualizada(RUTA_BD_NORMATIVAS, CARPETA_NORMATIVAS_PDF):
                _actualizar_bd_legal(nueva_ruta)
            reglas_normativas = ejecutar_agente_2(municipio, tipo_proyecto, ruta_boja_pdf=ruta_pdf_normativa)
        else:
            _imprimir("❌ La ruta no puede estar vacía.")

    # Si el ayuntamiento aún no tiene límite registrado, solicitarlo una única vez y persistirlo
    if reglas_normativas.get("estado") == "REQUIERE_LIMITE_MANUAL":
        _imprimir(f"\n⚠️ El Ayuntamiento de {municipio} aún no tiene límite registrado en memoria.")
        for _ in range(5):
            try:
                limite_manual = _input_consola_seguro(
                    f"👉 Introduce a mano el límite de peso en MB para {municipio} (se guardará para futuras ejecuciones): "
                ).strip()
            except EOFError:
                break
            valor_mb = _extraer_entero_positivo_usuario(limite_manual)
            if valor_mb is not None:
                reglas_normativas = ejecutar_agente_2(
                    municipio,
                    tipo_proyecto,
                    ruta_boja_pdf=ruta_pdf_normativa,
                    limite_manual_mb=valor_mb,
                )
                break
            _imprimir("❌ Por favor, introduce un número entero mayor que 0 (ej. 25).")

    normativas_salida = dict(reglas_normativas) if isinstance(reglas_normativas, dict) else {}
    estado_normativo = normativas_salida.get("estado")
    if estado_normativo == "COMPLETADO":
        del normativas_salida["estado"]

    # Clasificación integral de archivos del proyecto mediante Agente 1 -> genera JSON para Agente 3
    referencia_especificaciones_ag1 = None
    if (
        estado_normativo == "COMPLETADO"
        and AGENTE_1_DISPONIBLE
        and callable(clasificar_archivos_proyecto)
        and ruta_carpeta_proyecto
        and os.path.isdir(ruta_carpeta_proyecto)
    ):
        try:
            espec_ag1 = clasificar_archivos_proyecto(
                ruta_carpeta_proyecto,
                reglas_identidad=normativas_salida.get("reglas_identidad"),
                metadatos_caratula=datos_caratula,
            )
            if isinstance(espec_ag1, dict) and espec_ag1.get("estado") == "COMPLETADO":
                ruta_json_ag1 = espec_ag1.get("ruta_json_generado")
                referencia_especificaciones_ag1 = (
                    ruta_json_ag1 if (ruta_json_ag1 and os.path.isfile(ruta_json_ag1)) else espec_ag1
                )
        except Exception as e_cls:
            _imprimir(f"⚠️ Aviso al clasificar archivos del proyecto en Agente 1: {e_cls}")

    resultado_final = {
        "municipio": municipio,
        "codigo_ine": codigo_ine,
        "provincia": provincia,
        "comunidad_autonoma": comunidad,
        "tipo_proyecto": tipo_proyecto,
        "carpeta_proyecto": ruta_carpeta_proyecto,
        "archivo_origen": ruta_pdf_proyecto,
        "metadatos_caratula": datos_caratula,
        "normativas_empaquetado": normativas_salida,
    }
    if referencia_especificaciones_ag1 is not None:
        resultado_final["especificaciones_agente_1"] = referencia_especificaciones_ag1

    if estado_normativo == "COMPLETADO" and (
        (ruta_pdf_proyecto and os.path.isfile(ruta_pdf_proyecto))
        or referencia_especificaciones_ag1 is not None
    ):
        _imprimir("\n⚙️ [Paso 3] Ejecutando Agente 3 (Compresión sin pérdida, Fragmentación y Empaquetado BOJA)...")
        resultado_final["procesamiento_pdf"] = ejecutar_agente_3(resultado_final)

    _imprimir("\n==================================================")
    if estado_normativo == "COMPLETADO":
        _imprimir("✅ DATOS CONSOLIDADOS CON ÉXITO")
    else:
        _imprimir("⚠️ PROCESO FINALIZADO CON ADVERTENCIAS EN NORMATIVA")
    _imprimir("==================================================")

    _imprimir(json.dumps(resultado_final, indent=2, ensure_ascii=False))
    return resultado_final


if __name__ == "__main__":
    main()
