"""
Módulo: geo_localizador.py
================================================================================
Propósito general:
    Resuelve y almacena de forma persistente la información geográfica oficial
    de los municipios españoles necesaria para tramitar proyectos urbanísticos,
    de arquitectura e ingeniería:
      1. Provincia y Comunidad Autónoma a la que pertenece cada municipio
         (determina qué boletín oficial autonómico aplica, p. ej. BOJA en Andalucía).
      2. Código municipal INE de 5 dígitos (PP + MMM, p. ej. '29067' para Málaga),
         imprescindible para construir los códigos normativos de carpetas y
         archivos exigidos por las Normas Directoras (plantillas `INE_TIP_...`).

Persistencia y garantías de diseño:
    - Combina una base semilla en memoria (`_DATOS_BASE_MUNICIPIOS` y
      `_CODIGOS_INE_OFICIALES`) con un archivo JSON local persistente
      (`municipios_espana.json`) que aprende nuevos municipios introducidos
      manualmente para no volver a solicitarlos en futuras ejecuciones.
    - Las operaciones de lectura (`cargar_base_datos`, `obtener_datos_geograficos`,
      `obtener_codigo_ine`) son 100 % puras y libres de efectos secundarios en disco.
    - Todas las escrituras se realizan de manera atómica mediante archivo temporal
      + `os.replace` para impedir corrupciones ante cierres inesperados.
================================================================================
"""

import copy
import json
import os
import re
import tempfile
import unicodedata

# Rutas ancladas al directorio real del módulo (independientes del directorio de trabajo actual)
DIRECTORIO_BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO_MUNICIPIOS = os.path.join(DIRECTORIO_BASE, "municipios_espana.json")

# Base de datos semilla en memoria con municipios habituales para resolución inmediata
# de provincia y comunidad autónoma sin requerir conexión a internet.
_DATOS_BASE_MUNICIPIOS = {
    "málaga": {"provincia": "Málaga", "comunidad": "Andalucía"},
    "marbella": {"provincia": "Málaga", "comunidad": "Andalucía"},
    "estepona": {"provincia": "Málaga", "comunidad": "Andalucía"},
    "mijas": {"provincia": "Málaga", "comunidad": "Andalucía"},
    "fuengirola": {"provincia": "Málaga", "comunidad": "Andalucía"},
    "vélez-málaga": {"provincia": "Málaga", "comunidad": "Andalucía"},
    "ronda": {"provincia": "Málaga", "comunidad": "Andalucía"},
    "antequera": {"provincia": "Málaga", "comunidad": "Andalucía"},
    "nerja": {"provincia": "Málaga", "comunidad": "Andalucía"},
    "dos hermanas": {"provincia": "Sevilla", "comunidad": "Andalucía"},
    "sevilla": {"provincia": "Sevilla", "comunidad": "Andalucía"},
    "córdoba": {"provincia": "Córdoba", "comunidad": "Andalucía"},
    "granada": {"provincia": "Granada", "comunidad": "Andalucía"},
    "cádiz": {"provincia": "Cádiz", "comunidad": "Andalucía"},
    "huelva": {"provincia": "Huelva", "comunidad": "Andalucía"},
    "jaén": {"provincia": "Jaén", "comunidad": "Andalucía"},
    "almería": {"provincia": "Almería", "comunidad": "Andalucía"},
    "madrid": {"provincia": "Madrid", "comunidad": "Comunidad de Madrid"},
    "barcelona": {"provincia": "Barcelona", "comunidad": "Cataluña"},
    "valencia": {"provincia": "Valencia", "comunidad": "Comunidad Valenciana"},
}

# Catálogo de códigos municipales INE oficiales (5 dígitos: PP de provincia + MMM de municipio).
# Las claves están pre-normalizadas (minúsculas, sin tildes ni guiones) para búsqueda O(1).
_CODIGOS_INE_OFICIALES = {
    # Málaga (29)
    "malaga": "29067",
    "marbella": "29069",
    "estepona": "29051",
    "mijas": "29070",
    "fuengirola": "29054",
    "velez malaga": "29094",
    "ronda": "29084",
    "antequera": "29015",
    "nerja": "29075",
    "coin": "29042",
    "rincon de la victoria": "29082",
    "benalmadena": "29901",
    "torremolinos": "29902",
    "alhaurin de la torre": "29007",
    "alhaurin el grande": "29008",
    "cartama": "29038",
    "casares": "29041",
    "manilva": "29068",
    "ojen": "29076",
    "benahavis": "29023",
    "canete la real": "29035",
    "torrox": "29091",
    "archidona": "29017",
    # Sevilla (41)
    "sevilla": "41091",
    "dos hermanas": "41038",
    "alcala de guadaira": "41004",
    "utrera": "41095",
    "mairena del aljarafe": "41059",
    "ecija": "41039",
    "la rinconada": "41081",
    "los palacios y villafranca": "41069",
    "coria del rio": "41034",
    "carmona": "41024",
    "moron de la frontera": "41065",
    "lebrija": "41053",
    "camas": "41021",
    "tomares": "41093",
    "bormujos": "41017",
    # Córdoba (14)
    "cordoba": "14021",
    "lucena": "14038",
    "puente genil": "14056",
    "montilla": "14042",
    "priego de cordoba": "14055",
    "palma del rio": "14049",
    "cabra": "14013",
    "baena": "14007",
    # Granada (18)
    "granada": "18087",
    "motril": "18140",
    "almunecar": "18017",
    "armilla": "18021",
    "maracena": "18127",
    "baza": "18023",
    "loja": "18122",
    "las gabias": "18905",
    "guadix": "18089",
    # Cádiz (11)
    "cadiz": "11012",
    "jerez de la frontera": "11020",
    "algeciras": "11004",
    "san fernando": "11031",
    "el puerto de santa maria": "11027",
    "chiclana de la frontera": "11015",
    "sanlucar de barrameda": "11032",
    "la linea de la concepcion": "11022",
    "puerto real": "11028",
    "rota": "11030",
    "san roque": "11033",
    "arcos de la frontera": "11006",
    "tarifa": "11035",
    # Huelva (21)
    "huelva": "21041",
    "lepe": "21044",
    "almonte": "21005",
    "moguer": "21050",
    "aljaraque": "21002",
    "ayamonte": "21010",
    "isla cristina": "21042",
    "cartaya": "21021",
    # Jaén (23)
    "jaen": "23050",
    "linares": "23055",
    "andujar": "23005",
    "ubeda": "23092",
    "martos": "23060",
    "alcala la real": "23002",
    "baeza": "23009",
    # Almería (04)
    "almeria": "04013",
    "el ejido": "04902",
    "roquetas de mar": "04079",
    "nijar": "04066",
    "vikar": "04102",
    "vicar": "04102",
    "adra": "04003",
    "huercal overa": "04053",
    "vera": "04100",
    # Capitales y grandes ciudades resto de España
    "madrid": "28079",
    "barcelona": "08019",
    "valencia": "46250",
    "zaragoza": "50297",
    "murcia": "30030",
    "palma": "07040",
    "las palmas de gran canaria": "35016",
    "bilbao": "48020",
    "alicante": "03014",
    "valladolid": "47186",
    "vigo": "36057",
    "gijon": "33024",
    "oviedo": "33044",
    "santander": "39075",
    "pamplona": "31201",
    "logrono": "26089",
    "toledo": "45168",
    "badajoz": "06015",
    "caceres": "10037",
    "santa cruz de tenerife": "38038",
}

# Prefijos provinciales oficiales del INE (01 Álava .. 52 Melilla).
# Se emplean como respaldo (`PP000`) cuando un municipio menor no figura aún con código completo.
_PREFIJOS_INE_PROVINCIA = {
    "alava": "01", "araba": "01",
    "albacete": "02",
    "alicante": "03", "alacant": "03",
    "almeria": "04",
    "avila": "05",
    "badajoz": "06",
    "baleares": "07", "illes balears": "07", "islas baleares": "07",
    "barcelona": "08",
    "burgos": "09",
    "caceres": "10",
    "cadiz": "11",
    "castellon": "12", "castello": "12",
    "ciudad real": "13",
    "cordoba": "14",
    "a coruna": "15", "la coruna": "15", "coruna": "15",
    "cuenca": "16",
    "girona": "17", "gerona": "17",
    "granada": "18",
    "guadalajara": "19",
    "gipuzkoa": "20", "guipuzcoa": "20",
    "huelva": "21",
    "huesca": "22",
    "jaen": "23",
    "leon": "24",
    "lleida": "25", "lerida": "25",
    "la rioja": "26", "rioja": "26",
    "lugo": "27",
    "madrid": "28",
    "malaga": "29",
    "murcia": "30",
    "navarra": "31",
    "ourense": "32", "orense": "32",
    "asturias": "33",
    "palencia": "34",
    "las palmas": "35",
    "pontevedra": "36",
    "salamanca": "37",
    "santa cruz de tenerife": "38", "tenerife": "38",
    "cantabria": "39",
    "segovia": "40",
    "sevilla": "41",
    "soria": "42",
    "tarragona": "43",
    "teruel": "44",
    "toledo": "45",
    "valencia": "46",
    "valladolid": "47",
    "bizkaia": "48", "vizcaya": "48",
    "zamora": "49",
    "zaragoza": "50",
    "ceuta": "51",
    "melilla": "52",
}


def _normalizar(texto):
    """Normaliza nombres de municipios ignorando mayúsculas, tildes, guiones y signos de puntuación."""
    # Rechazar nulos y booleanos explícitamente (en Python `isinstance(True, int)` pero no es un topónimo)
    if texto is None or isinstance(texto, bool):
        return ""
    texto_str = str(texto).strip().lower()
    if not texto_str:
        return ""
    # Descomposición Unicode NFD para eliminar marcas diacríticas (tildes, diéresis)
    texto_sin_tildes = "".join(
        c for c in unicodedata.normalize("NFD", texto_str)
        if unicodedata.category(c) != "Mn"
    )
    # Sustituir guiones, barras y signos de puntuación por espacios simples
    texto_separado = re.sub(r"[\s\-–—_/.,;:'’‘\"“”()·]+", " ", texto_sin_tildes)
    texto_alfanum = re.sub(r"[^a-z0-9 ]", "", texto_separado)
    resultado = " ".join(texto_alfanum.split())
    # Exigir al menos una letra para descartar entradas puramente numéricas o simbólicas
    if not re.search(r"[a-z]", resultado):
        return ""
    return resultado


def _es_codigo_ine_valido(valor):
    """Valida que un código INE sea exactamente una cadena numérica de 5 dígitos (01001..52999)."""
    if valor is None or isinstance(valor, bool):
        return False
    limpio = str(valor).strip()
    if not re.fullmatch(r"\d{5}", limpio):
        return False
    prefijo = int(limpio[:2])
    return 1 <= prefijo <= 52


def _es_registro_valido(valor):
    """Verifica que el registro geográfico contenga provincia y comunidad no vacías."""
    if not isinstance(valor, dict):
        return False
    provincia = valor.get("provincia")
    comunidad = valor.get("comunidad")
    return (
        isinstance(provincia, str)
        and bool(_normalizar(provincia))
        and isinstance(comunidad, str)
        and bool(_normalizar(comunidad))
    )


def _guardar_json_atomico(ruta_archivo, datos):
    """Escribe un archivo JSON de forma atómica para evitar corrupción ante cortes o fallos de E/S."""
    carpeta = os.path.dirname(os.path.abspath(ruta_archivo))
    os.makedirs(carpeta, exist_ok=True)
    # Se escribe primero en un fichero temporal dentro del mismo directorio y luego se reemplaza atómicamente
    fd, ruta_tmp = tempfile.mkstemp(prefix=".tmp_muni_", suffix=".json", dir=carpeta)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(datos, f, ensure_ascii=False, indent=2)
        os.replace(ruta_tmp, ruta_archivo)
    except Exception:
        if os.path.exists(ruta_tmp):
            try:
                os.unlink(ruta_tmp)
            except OSError:
                pass
        raise


def _leer_codigos_ine_personalizados():
    """Lee posibles códigos INE personalizados guardados en municipios_espana.json sin efectos secundarios."""
    if not os.path.exists(ARCHIVO_MUNICIPIOS):
        return {}
    try:
        with open(ARCHIVO_MUNICIPIOS, "r", encoding="utf-8") as f:
            datos_disco = json.load(f)
        if not isinstance(datos_disco, dict):
            return {}
        codigos = {}
        for clave_bruta, valor in datos_disco.items():
            if not isinstance(clave_bruta, str) or not isinstance(valor, dict):
                continue
            clave_norm = _normalizar(clave_bruta)
            ine_cand = valor.get("codigo_ine")
            if clave_norm and _es_codigo_ine_valido(ine_cand):
                codigos[clave_norm] = str(ine_cand).strip()
        return codigos
    except Exception:
        return {}


def cargar_base_datos():
    """
    Carga y fusiona en memoria el diccionario base de municipios con los registros
    persistidos en `municipios_espana.json`, devolviendo siempre copias limpias
    con esquema `{"provincia": ..., "comunidad": ...}` y sin crear archivos en disco.
    """
    datos_resultado = copy.deepcopy(_DATOS_BASE_MUNICIPIOS)
    indice_norm = {_normalizar(k): k for k in datos_resultado}

    if not os.path.exists(ARCHIVO_MUNICIPIOS):
        return datos_resultado

    try:
        with open(ARCHIVO_MUNICIPIOS, "r", encoding="utf-8") as f:
            datos_disco = json.load(f)
        if isinstance(datos_disco, dict):
            for clave_bruta, valor in datos_disco.items():
                if not isinstance(clave_bruta, str):
                    continue
                clave_norm = _normalizar(clave_bruta)
                if not clave_norm or not _es_registro_valido(valor):
                    continue
                registro_limpio = {
                    "provincia": valor["provincia"].strip(),
                    "comunidad": valor["comunidad"].strip(),
                }
                # Si el municipio ya existía con tilde/guion distinto, unificar sobre la clave canónica
                if clave_norm in indice_norm:
                    clave_canonica = indice_norm[clave_norm]
                    datos_resultado[clave_canonica] = registro_limpio
                else:
                    clave_limpia = " ".join(clave_bruta.strip().lower().split())
                    datos_resultado[clave_limpia] = registro_limpio
                    indice_norm[clave_norm] = clave_limpia
        return datos_resultado
    except Exception:
        # Ante JSON corrupto o ilegible, degradar de forma segura al catálogo base en memoria
        return datos_resultado


def registrar_municipio(nombre_municipio, provincia, comunidad, codigo_ine=None):
    """Guarda permanentemente en municipios_espana.json cualquier municipio nuevo introducido a mano."""
    if (
        nombre_municipio is None or isinstance(nombre_municipio, bool)
        or provincia is None or isinstance(provincia, bool)
        or comunidad is None or isinstance(comunidad, bool)
    ):
        return None
    muni_limpio = " ".join(str(nombre_municipio).strip().lower().split())
    prov_limpia = str(provincia).strip()
    com_limpia = str(comunidad).strip()
    muni_norm = _normalizar(muni_limpio)

    if not muni_norm or not _normalizar(prov_limpia) or not _normalizar(com_limpia):
        return None

    codigos_previos = _leer_codigos_ine_personalizados()
    db = cargar_base_datos()
    registro_publico = {
        "provincia": prov_limpia,
        "comunidad": com_limpia,
    }

    # Evitar duplicados equivalentes por tildes o guiones (ej. 'málaga' vs 'malaga')
    claves_equivalentes = [k for k in list(db.keys()) if _normalizar(k) == muni_norm]
    if claves_equivalentes:
        clave_principal = claves_equivalentes[0]
        for k_extra in claves_equivalentes[1:]:
            del db[k_extra]
        db[clave_principal] = dict(registro_publico)
    else:
        clave_principal = muni_limpio
        db[clave_principal] = dict(registro_publico)

    # Rehidratar códigos INE personalizados al persistir en disco para no perderlos al actualizar
    db_disco = copy.deepcopy(db)
    for k_db, val_db in db_disco.items():
        k_norm = _normalizar(k_db)
        if k_norm in codigos_previos:
            val_db["codigo_ine"] = codigos_previos[k_norm]

    if _es_codigo_ine_valido(codigo_ine):
        db_disco[clave_principal]["codigo_ine"] = str(codigo_ine).strip()

    try:
        _guardar_json_atomico(ARCHIVO_MUNICIPIOS, db_disco)
    except OSError:
        pass
    return dict(registro_publico)


def registrar_codigo_ine(nombre_municipio, codigo_ine):
    """Registra o actualiza el código INE de 5 dígitos de un municipio en la base persistente."""
    muni_norm = _normalizar(nombre_municipio)
    if not muni_norm or not _es_codigo_ine_valido(codigo_ine):
        return None
    ine_str = str(codigo_ine).strip()
    datos_geo = obtener_datos_geograficos(nombre_municipio)
    if datos_geo:
        registrar_municipio(
            nombre_municipio,
            datos_geo["provincia"],
            datos_geo["comunidad"],
            codigo_ine=ine_str,
        )
        return ine_str

    # Si el municipio aún no tiene provincia/comunidad registrada, guardar entrada parcial o conservar en memoria
    codigos_previos = _leer_codigos_ine_personalizados()
    db = cargar_base_datos()
    db_disco = copy.deepcopy(db)
    for k_db, val_db in db_disco.items():
        k_norm = _normalizar(k_db)
        if k_norm in codigos_previos:
            val_db["codigo_ine"] = codigos_previos[k_norm]
    muni_limpio = " ".join(str(nombre_municipio).strip().lower().split())
    db_disco[muni_limpio] = {"codigo_ine": ine_str}
    try:
        _guardar_json_atomico(ARCHIVO_MUNICIPIOS, db_disco)
    except OSError:
        pass
    return ine_str


def obtener_datos_geograficos(nombre_municipio):
    """
    Busca un municipio tolerando diferencias de mayúsculas, tildes o guiones
    y devuelve `{"provincia": ..., "comunidad": ...}` o `None` si no está registrado.
    """
    municipio_norm = _normalizar(nombre_municipio)
    if not municipio_norm:
        return None

    db = cargar_base_datos()
    municipio_limpio = " ".join(str(nombre_municipio).strip().lower().split())

    # 1. Coincidencia directa rápida
    if municipio_limpio in db and _es_registro_valido(db[municipio_limpio]):
        return dict(db[municipio_limpio])

    # 2. Búsqueda normalizada insensible a tildes, guiones y signos
    for clave, valor in db.items():
        if _normalizar(clave) == municipio_norm and _es_registro_valido(valor):
            return dict(valor)

    return None


def obtener_codigo_ine(nombre_municipio, provincia=None):
    """
    Obtiene el código INE de 5 dígitos del municipio consultando:
    1. Si el propio valor ya es un código INE válido de 5 dígitos.
    2. Códigos INE personalizados guardados en municipios_espana.json.
    3. Catálogo oficial INE integrado (_CODIGOS_INE_OFICIALES).
    4. Prefijo provincial INE (PP000) si se conoce la provincia.
    5. '00000' como respaldo seguro.
    """
    if _es_codigo_ine_valido(nombre_municipio):
        return str(nombre_municipio).strip()

    muni_norm = _normalizar(nombre_municipio)
    if muni_norm:
        personalizados = _leer_codigos_ine_personalizados()
        if muni_norm in personalizados:
            return personalizados[muni_norm]
        if muni_norm in _CODIGOS_INE_OFICIALES:
            return _CODIGOS_INE_OFICIALES[muni_norm]
        # Intento sin artículos iniciales ('el ejido' vs 'ejido', 'la linea' vs 'linea')
        muni_sin_art = re.sub(r"^(?:el|la|los|las)\s+", "", muni_norm)
        if muni_sin_art in _CODIGOS_INE_OFICIALES:
            return _CODIGOS_INE_OFICIALES[muni_sin_art]
        for clave_cat, cod_cat in _CODIGOS_INE_OFICIALES.items():
            if re.sub(r"^(?:el|la|los|las)\s+", "", clave_cat) == muni_sin_art and muni_sin_art:
                return cod_cat

    # Respaldo provincial: si conocemos la provincia, devolvemos su código INE provincial + '000'
    prov_busqueda = provincia
    if not prov_busqueda and muni_norm:
        datos_geo = obtener_datos_geograficos(nombre_municipio)
        if datos_geo:
            prov_busqueda = datos_geo.get("provincia")

    prov_norm = _normalizar(prov_busqueda)
    if prov_norm and prov_norm in _PREFIJOS_INE_PROVINCIA:
        return f"{_PREFIJOS_INE_PROVINCIA[prov_norm]}000"

    return "00000"
