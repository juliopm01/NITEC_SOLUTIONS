"""
Módulo: agente_3_procesador.py (Agente 3 — Compresor Sin Pérdida, Fragmentador y Empaquetador)
================================================================================
Propósito general:
    Representa la tercera línea de trabajo del sistema NITEC: recibe el inventario
    clasificado en JSON del Agente 1 (`especificaciones_agente_1.json`) junto con
    los límites de peso municipales y la estructura normativa del Agente 2 para
    construir la carpeta final completa del proyecto lista para su entrega oficial.

Operaciones clave:
    1. Compresión de PDFs 100 % sin pérdida de calidad en imágenes (`comprimir_pdf_sin_perdida`):
       Optimiza tablas XRef, objetos duplicados y flujos Flate mediante `PyMuPDF`
       (`garbage=4, deflate=True, deflate_images=True, deflate_fonts=True, clean=True`)
       y `pypdf` (`compress_content_streams`) sin alterar ni un solo píxel ni los PPP/DPI
       de planos, ortofotos o fotografías. Si la compresión reduce el archivo por debajo
       del límite municipal, evita dividirlo innecesariamente.
    2. Fragmentación exacta por peso (`dividir_pdf_por_peso`):
       Emplea búsqueda exponencial + búsqueda binaria sobre los bytes reales serializados
       por `pypdf` para garantizar que ningún fragmento supere `limite_mb`, numerándolos
       según el patrón normativo (`09_99` -> `_01_03`, `_02_03`, `_03_03`).
    3. Reorganización y codificación oficial (`empaquetar_proyecto_completo`):
       Materializa todas las carpetas del boletín oficial resolviendo dinámicamente
       `INE`, `TIP`/`SIGLAS_DEL_PROYECTO`, `AMB`, `FT` y `AAAAMMDD`, numera series de
       planos, incrementa códigos seriados (`AN01` -> `AN01`, `AN02`), mantiene unidos
       los archivos acompañantes de Shapefile (`.shp`, `.shx`, `.dbf`, `.prj`) y emite
       `<CODIGO_RAIZ>_informe_empaquetado.json` con trazabilidad completa.
================================================================================
"""

import io
import json
import math
import os
import re
import shutil
import stat
import sys
import tempfile

try:
    from pypdf import PdfReader, PdfWriter
    PYPDF_DISPONIBLE = True
except Exception:
    PdfReader = None
    PdfWriter = None
    PYPDF_DISPONIBLE = False

try:
    import fitz  # PyMuPDF para compresión Flate/XRef 100% sin pérdida de calidad de imagen
    PYMUPDF_DISPONIBLE = True
except Exception:
    fitz = None
    PYMUPDF_DISPONIBLE = False

try:
    from geo_localizador import obtener_codigo_ine
except Exception:
    obtener_codigo_ine = None

# Identificadores de carpeta raíz y conjunto de archivos hermanos que componen una capa ESRI Shapefile
_CLAVES_CARPETA_RAIZ = {"_raiz_", "raiz", "_root_", "root", "."}
_EXTENSIONES_COMPANION_SHP = {".shp", ".shx", ".dbf", ".prj", ".cpg", ".qpj", ".sbn", ".sbx"}


def _imprimir(mensaje):
    """Imprime de forma segura en consolas Windows cp1252 o flujos redirigidos."""
    try:
        print(mensaje)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        seguro = str(mensaje).encode(enc, errors="replace").decode(enc, errors="replace")
        print(seguro)


def _limpiar_ruta(ruta):
    """Sanea comillas y espacios extremos de una ruta de sistema rechazando tipos no textuales."""
    if ruta is None or isinstance(ruta, bool) or not isinstance(ruta, (str, os.PathLike)):
        return ""
    return str(ruta).strip().strip('"').strip("'")


def _quitar_extension_pdf(nombre):
    """Elimina únicamente la extensión .pdf final preservando puntos intermedios (ej. 'Sector_1.2')."""
    base = os.path.basename(str(nombre or "").strip())
    return re.sub(r"\.pdf$", "", base, flags=re.IGNORECASE).strip()


def _separar_plantilla_de_descripcion(texto):
    """Separa 'PLANTILLA | Descripción' devolviendo únicamente la plantilla limpia."""
    cadena = str(texto or "").strip()
    if "|" in cadena:
        cadena = cadena.split("|", 1)[0].strip()
    cadena = re.sub(r"\s*_\s*", "_", cadena)
    cadena = re.sub(r"_{2,}", "_", cadena)
    cadena = re.sub(r"^INE_INE_", "INE_", cadena, flags=re.IGNORECASE)
    return cadena.strip()


def _guardar_json_atomico(ruta_archivo, datos):
    """Escribe un informe o especificación JSON en disco de forma atómica (`mkstemp` + `os.replace`)."""
    carpeta = os.path.dirname(os.path.abspath(ruta_archivo))
    os.makedirs(carpeta, exist_ok=True)
    fd, ruta_tmp = tempfile.mkstemp(prefix=".tmp_ag3_", suffix=".json", dir=carpeta)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(datos, f, ensure_ascii=False, indent=2)
        os.replace(ruta_tmp, ruta_archivo)
    except Exception:
        if os.path.exists(ruta_tmp):
            try:
                os.unlink(ruta_tmp)
            except OSError:
                pass
        raise


def _eliminar_directorio_seguro(ruta_dir):
    """Elimina recursivamente un directorio temporal o entrega previa desbloqueando atributos de solo lectura."""
    if not ruta_dir or not os.path.exists(ruta_dir):
        return

    def _desbloquear(func, path, *_):
        try:
            os.chmod(path, stat.S_IWRITE)
            func(path)
        except Exception:
            pass

    if sys.version_info >= (3, 12):
        shutil.rmtree(ruta_dir, onexc=_desbloquear)
    else:
        shutil.rmtree(ruta_dir, onerror=_desbloquear)


def _extraer_limite_mb(limite_mb, por_defecto=20.0):
    """
    Convierte el límite de peso recibido (entero, decimal con punto o coma española, o cadena con 'MB')
    en un `float` positivo estricto, cayendo a `por_defecto` ante valores negativos, cero o inválidos.
    """
    if limite_mb is None or isinstance(limite_mb, bool):
        return float(por_defecto)
    if isinstance(limite_mb, (int, float)):
        if not math.isfinite(limite_mb) or float(limite_mb) <= 0:
            return float(por_defecto)
        return float(limite_mb)

    cadena = str(limite_mb).strip()
    if not cadena:
        return float(por_defecto)

    # Normalizar coma decimal española (ej. "12,5 MB" -> "12.5 MB")
    cadena_punto = re.sub(r"(\d),(\d)", r"\1.\2", cadena)
    if re.match(r"^\s*-\s*\d", cadena_punto):
        return float(por_defecto)

    cadena_positiva = re.sub(r"-\s*\d+(?:\.\d+)?", " ", cadena_punto)
    coincidencia = re.search(r"(?<![-\d.,])(\d+(?:\.\d+)?)", cadena_positiva)
    if coincidencia:
        val = float(coincidencia.group(1))
        if math.isfinite(val) and val > 0:
            return val
    return float(por_defecto)


def _formatear_sufijo_division(indice_parte, total_partes, formato_division="09_99"):
    """
    Genera el sufijo de numeración según el patrón normativo (ej. '09_99' -> '01_03', '009_999' -> '001_003').
    Si el número total de partes supera los dígitos del patrón, expande el ancho automáticamente sin truncar.
    """
    patron = str(formato_division or "09_99").strip()
    grupos = re.findall(r"\d+", patron)
    if len(grupos) >= 2:
        ancho_idx = max(len(grupos[0]), len(str(total_partes)))
        ancho_tot = max(len(grupos[1]), len(str(total_partes)))
        sep_match = re.search(r"\d+([^\d]+)\d+", patron)
        separador = sep_match.group(1) if sep_match else "_"
    else:
        ancho_idx = max(2, len(str(total_partes)))
        ancho_tot = max(2, len(str(total_partes)))
        separador = "_"

    return f"{indice_parte:0{ancho_idx}d}{separador}{total_partes:0{ancho_tot}d}"


def _escribir_bytes_atomico(ruta_destino, datos_bytes):
    """Escribe un archivo binario (PDF) de forma atómica evitando dejar ficheros truncados en disco."""
    carpeta = os.path.dirname(os.path.abspath(ruta_destino))
    os.makedirs(carpeta, exist_ok=True)
    _, ext = os.path.splitext(ruta_destino)
    sufijo_tmp = ext if ext else ".tmp"
    fd, ruta_tmp = tempfile.mkstemp(prefix=".tmp_pdf_", suffix=sufijo_tmp, dir=carpeta)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(datos_bytes)
        os.replace(ruta_tmp, ruta_destino)
    except Exception:
        if os.path.exists(ruta_tmp):
            try:
                os.unlink(ruta_tmp)
            except OSError:
                pass
        raise


def _abrir_lector_pdf_seguro(ruta_limpia):
    """Abre un PDF con pypdf desbloqueando firmas con clave vacía y validando integridad."""
    lector = PdfReader(ruta_limpia)
    if getattr(lector, "is_encrypted", False):
        try:
            lector.decrypt("")
        except Exception:
            pass
    if getattr(lector, "is_encrypted", False):
        raise PermissionError("El archivo PDF está protegido con contraseña.")
    total_paginas = len(lector.pages)
    return lector, total_paginas


def _serializar_rango_paginas(lector, inicio, fin_exclusivo, comprimir=False):
    """Serializa en memoria RAM el subconjunto de páginas `[inicio, fin_exclusivo)` para medir su peso real."""
    escritor = PdfWriter()
    for idx in range(inicio, fin_exclusivo):
        pagina = lector.pages[idx]
        pag_destino = escritor.add_page(pagina)
        if comprimir:
            objetivo = pag_destino if hasattr(pag_destino, "compress_content_streams") else pagina
            if hasattr(objetivo, "compress_content_streams"):
                try:
                    objetivo.compress_content_streams()
                except Exception:
                    pass
    buffer = io.BytesIO()
    escritor.write(buffer)
    return buffer.getvalue()


def comprimir_pdf_sin_perdida(ruta_pdf, ruta_destino=None):
    """
    Comprime un archivo PDF de manera 100% SIN PÉRDIDA (lossless) respetando íntegramente
    la resolución (PPP/DPI) y los píxeles originales de todas las imágenes y planos:
    1. Si PyMuPDF (fitz) está disponible, aplica recolección de objetos duplicados/huérfanos (`garbage=4`)
       y compresión Flate/ZIP sin pérdida sobre flujos e imágenes sin comprimir.
    2. Si pypdf está disponible, aplica compresión sin pérdida sobre flujos de contenido (`compress_content_streams`).
    3. Conserva siempre la variante de menor peso verificando que no se pierda ninguna página ni se infle el tamaño.
    """
    ruta_limpia = _limpiar_ruta(ruta_pdf)
    if not ruta_limpia or not os.path.isfile(ruta_limpia):
        return {"estado": "ERROR", "mensaje": "El archivo PDF no existe."}

    peso_original = os.path.getsize(ruta_limpia)
    if peso_original == 0:
        return {"estado": "ERROR", "mensaje": "El archivo PDF está vacío (0 bytes)."}

    try:
        with open(ruta_limpia, "rb") as f_orig:
            bytes_originales = f_orig.read()
    except Exception as e:
        return {"estado": "ERROR", "mensaje": f"No se pudo leer el archivo PDF: {e}"}

    total_paginas = 0
    lector_pypdf = None
    error_apertura = None

    if PYPDF_DISPONIBLE and PdfReader is not None:
        try:
            lector_pypdf, total_paginas = _abrir_lector_pdf_seguro(ruta_limpia)
        except Exception as e:
            error_apertura = e

    # Partimos siempre de los bytes originales: ningún motor puede empeorar (inflar) el peso final
    mejores_bytes = bytes_originales
    motor_usado = "ORIGINAL"

    # Vía 1: PyMuPDF (fitz) — deduplicación XRef + compresión Flate sin tocar resolución ni JPEG
    if PYMUPDF_DISPONIBLE and fitz is not None:
        doc_fitz = None
        try:
            doc_fitz = fitz.open(ruta_limpia)
            if getattr(doc_fitz, "needs_pass", False):
                if not doc_fitz.authenticate(""):
                    raise PermissionError("El archivo PDF está protegido con contraseña.")
            pags_fitz = len(doc_fitz)
            if pags_fitz > 0:
                total_paginas = max(total_paginas, pags_fitz)
                if hasattr(doc_fitz, "tobytes"):
                    try:
                        cand_fitz = doc_fitz.tobytes(
                            garbage=4,
                            deflate=True,
                            deflate_images=True,
                            deflate_fonts=True,
                            clean=True,
                        )
                    except TypeError:
                        cand_fitz = doc_fitz.tobytes(garbage=4, deflate=True)
                    if cand_fitz and 0 < len(cand_fitz) < len(mejores_bytes):
                        mejores_bytes = cand_fitz
                        motor_usado = "PYMUPDF_LOSSLESS"
        except PermissionError as e_perm:
            error_apertura = e_perm
        except Exception as e_fitz:
            if error_apertura is None:
                error_apertura = e_fitz
        finally:
            if doc_fitz is not None:
                try:
                    doc_fitz.close()
                except Exception:
                    pass

    # Vía 2: pypdf — compresión Flate de flujos de contenido sin alterar imágenes
    if lector_pypdf is not None and total_paginas > 0:
        try:
            cand_pypdf = _serializar_rango_paginas(lector_pypdf, 0, total_paginas, comprimir=True)
            if cand_pypdf and 0 < len(cand_pypdf) < len(mejores_bytes):
                mejores_bytes = cand_pypdf
                motor_usado = "PYPDF_LOSSLESS"
        except Exception:
            pass

    if total_paginas == 0:
        if error_apertura is not None:
            return {"estado": "ERROR", "mensaje": f"PDF corrupto o ilegible: {error_apertura}"}
        return {"estado": "ERROR", "mensaje": "El archivo PDF no contiene páginas."}

    peso_final = len(mejores_bytes)
    ahorro_bytes = max(0, peso_original - peso_final)
    comprimido = ahorro_bytes > 0
    reduccion_pct = round((ahorro_bytes / peso_original) * 100.0, 2) if peso_original > 0 else 0.0

    salida_final = ruta_limpia
    if ruta_destino:
        salida_final = _limpiar_ruta(ruta_destino)
        _escribir_bytes_atomico(salida_final, mejores_bytes)

    return {
        "estado": "COMPRIMIDO" if comprimido else "SIN_CAMBIOS",
        "comprimido": comprimido,
        "motor_compresion": motor_usado,
        "calidad_imagenes_intacta": True,
        "total_paginas": total_paginas,
        "peso_original_bytes": peso_original,
        "peso_final_bytes": peso_final,
        "peso_original_mb": round(peso_original / (1024 * 1024), 4),
        "peso_final_mb": round(peso_final / (1024 * 1024), 4),
        "ahorro_bytes": ahorro_bytes,
        "reduccion_porcentaje": reduccion_pct,
        "ruta_salida": salida_final,
    }


def dividir_pdf_por_peso(
    ruta_pdf,
    limite_mb,
    formato_division="09_99",
    directorio_salida=None,
    nombre_base_salida=None,
    prefijo_parte="_parte_",
):
    """
    Divide un archivo PDF en partes cuyo peso real en disco respeta estrictamente `limite_mb`
    utilizando búsqueda exponencial + binaria sobre el tamaño serializado real de pypdf.
    """
    ruta_limpia = _limpiar_ruta(ruta_pdf)
    if not ruta_limpia or not os.path.isfile(ruta_limpia):
        return {"estado": "ERROR", "mensaje": "El archivo no existe."}

    if os.path.getsize(ruta_limpia) == 0:
        return {"estado": "ERROR", "mensaje": "El archivo PDF está vacío (0 bytes)."}

    if not PYPDF_DISPONIBLE or PdfReader is None or PdfWriter is None:
        return {"estado": "ERROR", "mensaje": "La librería 'pypdf' no está disponible para dividir el PDF."}

    limite_mb_float = _extraer_limite_mb(limite_mb)
    limite_bytes = max(1, int(limite_mb_float * 1024 * 1024))
    peso_origen_bytes = os.path.getsize(ruta_limpia)
    peso_origen_mb = peso_origen_bytes / (1024 * 1024)

    try:
        lector, total_paginas = _abrir_lector_pdf_seguro(ruta_limpia)
    except Exception as e:
        return {"estado": "ERROR", "mensaje": f"PDF corrupto o ilegible: {e}"}

    if total_paginas == 0:
        return {"estado": "ERROR", "mensaje": "El PDF no contiene páginas."}

    carpeta_destino = _limpiar_ruta(directorio_salida) or os.path.dirname(os.path.abspath(ruta_limpia))
    os.makedirs(carpeta_destino, exist_ok=True)

    if nombre_base_salida and str(nombre_base_salida).strip():
        base_limpia = _quitar_extension_pdf(nombre_base_salida)
    else:
        base_limpia = _quitar_extension_pdf(ruta_limpia)

    sep_parte = "_parte_" if prefijo_parte is None else str(prefijo_parte)

    partes_memoria = []
    advertencias = []
    inicio = 0

    while inicio < total_paginas:
        # Caché local por bloque para no re-serializar el mismo rango durante la búsqueda binaria
        cache_rango = {}

        def obtener_bytes(fin_excl, comp=False):
            clave = (fin_excl, comp)
            if clave not in cache_rango:
                cache_rango[clave] = _serializar_rango_paginas(lector, inicio, fin_excl, comprimir=comp)
            return cache_rango[clave]

        bytes_una_pagina = obtener_bytes(inicio + 1, comp=False)
        if len(bytes_una_pagina) > limite_bytes:
            # Intentar compresión sin pérdida de flujos de contenido antes de emitir advertencia de página indivisible
            bytes_comprimida = obtener_bytes(inicio + 1, comp=True)
            if len(bytes_comprimida) < len(bytes_una_pagina):
                bytes_una_pagina = bytes_comprimida

            if len(bytes_una_pagina) > limite_bytes:
                peso_pag_mb = round(len(bytes_una_pagina) / (1024 * 1024), 4)
                advertencias.append(
                    f"La página {inicio + 1} por sí sola pesa {peso_pag_mb} MB y excede el límite de {limite_mb_float} MB."
                )
                partes_memoria.append((inicio, inicio + 1, bytes_una_pagina, True))
                inicio += 1
                continue

        # Búsqueda exponencial del límite superior de páginas que caben en `limite_bytes`
        mejor_fin = inicio + 1
        mejor_bytes = bytes_una_pagina
        paso = 1

        while mejor_fin < total_paginas:
            candidato_fin = min(total_paginas, inicio + paso * 2)
            if candidato_fin == mejor_fin:
                break
            datos_cand = obtener_bytes(candidato_fin)
            if len(datos_cand) <= limite_bytes:
                mejor_fin = candidato_fin
                mejor_bytes = datos_cand
                if mejor_fin == total_paginas:
                    break
                paso *= 2
            else:
                # Búsqueda binaria exacta entre (mejor_fin + 1) y (candidato_fin - 1)
                bajo = mejor_fin + 1
                alto = candidato_fin - 1
                while bajo <= alto:
                    medio = (bajo + alto) // 2
                    datos_med = obtener_bytes(medio)
                    if len(datos_med) <= limite_bytes:
                        mejor_fin = medio
                        mejor_bytes = datos_med
                        bajo = medio + 1
                    else:
                        alto = medio - 1
                break

        partes_memoria.append((inicio, mejor_fin, mejor_bytes, False))
        inicio = mejor_fin

    total_partes = len(partes_memoria)
    archivos_generados = []
    detalle_partes = []

    # Limpiar posibles partes antiguas del mismo archivo base para evitar restos obsoletos (ej. _parte_01_04 previo)
    if sep_parte == "_parte_":
        prefijo_antiguo = f"{base_limpia}_parte_".lower()
        for nombre_existente in os.listdir(carpeta_destino):
            if nombre_existente.lower().startswith(prefijo_antiguo) and nombre_existente.lower().endswith(".pdf"):
                try:
                    os.unlink(os.path.join(carpeta_destino, nombre_existente))
                except OSError:
                    pass

    for idx_parte, (pag_ini, pag_fin, payload_bytes, excede_individual) in enumerate(partes_memoria, start=1):
        sufijo = _formatear_sufijo_division(idx_parte, total_partes, formato_division=formato_division)
        nombre_salida = f"{base_limpia}{sep_parte}{sufijo}.pdf"
        ruta_salida = os.path.join(carpeta_destino, nombre_salida)
        _escribir_bytes_atomico(ruta_salida, payload_bytes)
        archivos_generados.append(ruta_salida)
        detalle_partes.append({
            "archivo": ruta_salida,
            "pagina_inicio": pag_ini + 1,
            "pagina_fin": pag_fin,
            "paginas": pag_fin - pag_ini,
            "peso_mb": round(len(payload_bytes) / (1024 * 1024), 4),
            "excede_por_pagina_unica": excede_individual,
        })

    estado_salida = "ADVERTENCIA_PAGINA_EXCEDE_LIMITE" if advertencias else "DIVIDIDO"
    _imprimir(f"   ✂️ División completada: {total_partes} partes generadas en '{carpeta_destino}'.")
    return {
        "estado": estado_salida,
        "requiere_division": True,
        "peso_mb": round(peso_origen_mb, 2),
        "limite_mb": limite_mb_float,
        "formato_division": str(formato_division or "09_99"),
        "total_paginas": total_paginas,
        "total_partes": total_partes,
        "archivos_generados": archivos_generados,
        "detalle_partes": detalle_partes,
        "advertencias": advertencias,
    }


def procesar_pdf(
    ruta_pdf,
    limite_mb,
    formato_division="09_99",
    directorio_salida=None,
    nombre_base_salida=None,
    comprimir_sin_perdida=False,
    prefijo_parte="_parte_",
):
    """
    Procesa un único archivo PDF validando su integridad, aplicando opcionalmente
    compresión sin pérdida previa y dividiéndolo solo si supera `limite_mb`.
    """
    limite_mb_float = _extraer_limite_mb(limite_mb)
    ruta_limpia = _limpiar_ruta(ruta_pdf)

    if not ruta_limpia or not os.path.isfile(ruta_limpia):
        _imprimir("El archivo no existe.")
        return {"estado": "ERROR", "mensaje": "El archivo no existe."}

    peso_bytes = os.path.getsize(ruta_limpia)
    if peso_bytes == 0:
        _imprimir("El archivo está vacío (0 bytes).")
        return {"estado": "ERROR", "mensaje": "El archivo PDF está vacío (0 bytes)."}

    if PYPDF_DISPONIBLE and PdfReader is not None:
        try:
            _, n_pags = _abrir_lector_pdf_seguro(ruta_limpia)
            if n_pags == 0:
                return {"estado": "ERROR", "mensaje": "El archivo PDF no contiene páginas."}
        except Exception as e:
            return {"estado": "ERROR", "mensaje": f"Archivo PDF corrupto o ilegible: {e}"}

    ruta_trabajo = ruta_limpia
    ruta_tmp_comp = None
    info_compresion = None

    try:
        if comprimir_sin_perdida:
            carpeta_tmp = _limpiar_ruta(directorio_salida) or os.path.dirname(os.path.abspath(ruta_limpia))
            os.makedirs(carpeta_tmp, exist_ok=True)
            fd_c, ruta_tmp_comp = tempfile.mkstemp(prefix=".tmp_lossless_", suffix=".pdf", dir=carpeta_tmp)
            os.close(fd_c)
            res_comp = comprimir_pdf_sin_perdida(ruta_limpia, ruta_destino=ruta_tmp_comp)
            if res_comp.get("estado") in ("COMPRIMIDO", "SIN_CAMBIOS"):
                info_compresion = res_comp
                if res_comp.get("comprimido"):
                    ruta_trabajo = ruta_tmp_comp

        peso_efectivo_bytes = os.path.getsize(ruta_trabajo)
        peso_mb = peso_efectivo_bytes / (1024 * 1024)
        _imprimir(f"El archivo pesa {peso_mb:.2f} MB.")

        if peso_mb > limite_mb_float:
            _imprimir("El archivo supera el límite. Iniciando división con pypdf...")
            res_div = dividir_pdf_por_peso(
                ruta_trabajo,
                limite_mb=limite_mb_float,
                formato_division=formato_division,
                directorio_salida=directorio_salida,
                nombre_base_salida=nombre_base_salida,
                prefijo_parte=prefijo_parte,
            )
            if info_compresion is not None:
                res_div["compresion_sin_perdida"] = {
                    "aplicada": bool(info_compresion.get("comprimido")),
                    "ahorro_bytes": info_compresion.get("ahorro_bytes", 0),
                    "calidad_imagenes_intacta": True,
                }
            return res_div

        _imprimir("El archivo cumple con el peso normativo.")
        ruta_final = ruta_limpia
        if directorio_salida or nombre_base_salida or (info_compresion and info_compresion.get("comprimido")):
            carpeta_dest = _limpiar_ruta(directorio_salida) or os.path.dirname(os.path.abspath(ruta_limpia))
            os.makedirs(carpeta_dest, exist_ok=True)
            base_dest = (
                _quitar_extension_pdf(nombre_base_salida)
                if nombre_base_salida and str(nombre_base_salida).strip()
                else _quitar_extension_pdf(ruta_limpia)
            )
            candidato_dest = os.path.join(carpeta_dest, f"{base_dest}.pdf")
            if os.path.abspath(candidato_dest) != os.path.abspath(ruta_trabajo):
                shutil.copy2(ruta_trabajo, candidato_dest)
            ruta_final = candidato_dest

        salida_ok = {
            "estado": "OK",
            "requiere_division": False,
            "peso_mb": round(peso_mb, 2),
            "limite_mb": limite_mb_float,
            "total_partes": 1,
            "archivos_generados": [ruta_final],
        }
        if info_compresion is not None:
            salida_ok["compresion_sin_perdida"] = {
                "aplicada": bool(info_compresion.get("comprimido")),
                "ahorro_bytes": info_compresion.get("ahorro_bytes", 0),
                "calidad_imagenes_intacta": True,
            }
        return salida_ok
    finally:
        if ruta_tmp_comp and os.path.exists(ruta_tmp_comp):
            try:
                os.unlink(ruta_tmp_comp)
            except OSError:
                pass


def construir_nombre_normativo(
    plantilla_nombre,
    tipo_proyecto,
    metadatos_caratula=None,
    nombre_original=None,
    codigo_ine=None,
):
    """
    Construye un código normativo limpio sustituyendo dinámicamente los marcadores presentes
    en la plantilla (`INE`, `TIP`/`SIGLAS_DEL_PROYECTO`, `AMB`, `FT`, `AAAAMMDD`).
    """
    meta = metadatos_caratula if isinstance(metadatos_caratula, dict) else {}
    fase = str(meta.get("fase_tramitacion") or "").strip()
    fecha = str(meta.get("fecha_aprobacion") or "").strip()
    ambito = str(meta.get("ambito") or "").strip()

    plantilla_limpia = _separar_plantilla_de_descripcion(plantilla_nombre)
    if not plantilla_limpia:
        if nombre_original:
            return _quitar_extension_pdf(nombre_original) or "PROYECTO"
        return str(tipo_proyecto or "PROYECTO").strip()

    # Eliminar extensión documental final (.pdf, .gpkg, .shp, .txt, .xml) al resolver el código base
    nombre = re.sub(r"\.(?:pdf|gpkg|shp|gml|txt|xml|zip)$", "", plantilla_limpia, flags=re.IGNORECASE)

    if codigo_ine and str(codigo_ine).strip():
        ine_str = str(codigo_ine).strip()
        nombre = re.sub(r"[\[\{<]?(?<![A-Za-z0-9])INE(?![A-Za-z0-9])[\]\}>]?", ine_str, nombre)

    if tipo_proyecto and str(tipo_proyecto).strip():
        proy_str = str(tipo_proyecto).strip().upper()
        nombre = re.sub(
            r"[\[\{<]?(?<![A-Za-z0-9])(?:SIGLAS_DEL_PROYECTO|TIP)(?![A-Za-z0-9])[\]\}>]?",
            proy_str,
            nombre,
        )

    if ambito and ambito not in ("NO_ENCONTRADO", "NO_ENCONTRADA"):
        amb_limpio = re.sub(r"[^A-Za-z0-9]", "", ambito).upper()[:6]
        if amb_limpio:
            nombre = re.sub(r"[\[\{<]?(?<![A-Za-z0-9])AMB(?![A-Za-z0-9])[\]\}>]?", amb_limpio, nombre)

    if fase and fase != "NO_ENCONTRADA":
        nombre = re.sub(r"[\[\{<]?(?<![A-Za-z0-9])FT(?![A-Za-z0-9])[\]\}>]?", fase, nombre)

    if fecha and fecha != "NO_ENCONTRADA":
        nombre = re.sub(r"[\[\{<]?(?<![A-Za-z0-9])AAAAMMDD(?![A-Za-z0-9])[\]\}>]?", fecha, nombre)

    # Eliminar caracteres reservados prohibidos en sistemas de archivos Windows/POSIX
    nombre_seguro = re.sub(r'[<>:"/\\|?*]+', "_", nombre).strip(" ._")
    nombre_seguro = re.sub(r"_{2,}", "_", nombre_seguro)
    return nombre_seguro or "PROYECTO"


def _aplicar_indice_seriado(nombre_base, indice_serie):
    """Incrementa el marcador numérico de documentos seriados (ej. AN01 -> AN02, ATUSR_01 -> ATUSR_02)."""
    m_pref = re.search(r"([A-Za-z]{2,})(0+1)(?=_|$)", nombre_base)
    if m_pref:
        ancho = max(len(m_pref.group(2)), len(str(indice_serie)))
        reemplazo = f"{m_pref.group(1)}{indice_serie:0{ancho}d}"
        return nombre_base[: m_pref.start()] + reemplazo + nombre_base[m_pref.end() :]

    m_guion = re.search(r"_(0+1)(?=_|$)", nombre_base)
    if m_guion:
        ancho = max(len(m_guion.group(1)), len(str(indice_serie)))
        reemplazo = f"_{indice_serie:0{ancho}d}"
        return nombre_base[: m_guion.start()] + reemplazo + nombre_base[m_guion.end() :]

    return f"{nombre_base}_{indice_serie:02d}"


def _materializar_arbol_carpetas_normativo(
    estructura_carpetas,
    carpeta_raiz_entrega,
    tipo_proyecto,
    metadatos,
    codigo_ine,
):
    """Crea en disco todas las subcarpetas definidas en la normativa con sus códigos resueltos."""
    carpetas_creadas = [carpeta_raiz_entrega]
    os.makedirs(carpeta_raiz_entrega, exist_ok=True)
    if not isinstance(estructura_carpetas, dict):
        return carpetas_creadas

    def _crear_nivel(nodo, padre_actual):
        if not isinstance(nodo, dict):
            return
        for clave_bruta, subnodo in nodo.items():
            cod_carp = _separar_plantilla_de_descripcion(clave_bruta)
            if not cod_carp or cod_carp.lower() in _CLAVES_CARPETA_RAIZ:
                if isinstance(subnodo, dict) and "codigo" not in subnodo:
                    _crear_nivel(subnodo, padre_actual)
                continue
            nombre_carp = construir_nombre_normativo(
                cod_carp,
                tipo_proyecto,
                metadatos_caratula=metadatos,
                codigo_ine=codigo_ine,
            )
            ruta_sub = os.path.join(padre_actual, nombre_carp)
            os.makedirs(ruta_sub, exist_ok=True)
            if ruta_sub not in carpetas_creadas:
                carpetas_creadas.append(ruta_sub)
            if isinstance(subnodo, dict) and "codigo" not in subnodo:
                _crear_nivel(subnodo, ruta_sub)

    _crear_nivel(estructura_carpetas, carpeta_raiz_entrega)
    return carpetas_creadas


def _cargar_especificaciones_agente_1(especificaciones):
    """Acepta tanto la ruta al archivo JSON devuelto por el Agente 1 como el diccionario en memoria."""
    if isinstance(especificaciones, dict):
        return dict(especificaciones)
    ruta = _limpiar_ruta(especificaciones)
    if ruta and os.path.isfile(ruta):
        with open(ruta, "r", encoding="utf-8") as f:
            datos = json.load(f)
        if isinstance(datos, dict):
            return datos
    raise ValueError("Las especificaciones del Agente 1 deben ser un diccionario válido o una ruta JSON existente.")


def empaquetar_proyecto_completo(
    especificaciones_agente_1,
    normativas_empaquetado,
    municipio=None,
    provincia=None,
    codigo_ine=None,
    tipo_proyecto=None,
    metadatos_caratula=None,
    directorio_entrega_base=None,
    archivo_origen_principal=None,
):
    """
    Núcleo completo del Agente 3:
    Recibe el JSON de clasificación del Agente 1 y las reglas normativas/municipales del Agente 2 para:
    1. Construir la carpeta raíz y toda la estructura de subcarpetas con la codificación oficial del BOJA.
    2. Comprimir sin pérdida de calidad de imagen todos los PDFs (evitando divisiones innecesarias si el peso baja del límite).
    3. Fragmentar los PDFs que sigan superando el límite municipal/autonómico y numerar tanto partes como series de planos con formato `09_99`.
    4. Organizar bases geográficas SIG (.gpkg/.shp) y metadatos (.txt/.xml) en sus carpetas normativas correspondientes.
    """
    try:
        datos_ag1 = _cargar_especificaciones_agente_1(especificaciones_agente_1)
    except Exception as e:
        return {"estado": "ERROR", "mensaje": str(e)}

    normativas = normativas_empaquetado if isinstance(normativas_empaquetado, dict) else {}
    reglas_emp = normativas.get("reglas_empaquetado") if isinstance(normativas.get("reglas_empaquetado"), dict) else {}
    reglas_id = normativas.get("reglas_identidad") if isinstance(normativas.get("reglas_identidad"), dict) else {}

    limite_mb = _extraer_limite_mb(reglas_emp.get("limite_peso_mb"), por_defecto=50.0)
    limite_bytes = max(1, int(limite_mb * 1024 * 1024))
    formato_div = str(reglas_emp.get("formato_division") or "09_99").strip()
    tipo_proy = str(tipo_proyecto or "PROYECTO").strip().upper()

    # Resolver código INE de 5 dígitos si la plantilla lo requiere
    ine_resuelto = str(codigo_ine or "").strip()
    if not ine_resuelto and callable(obtener_codigo_ine) and municipio:
        ine_resuelto = obtener_codigo_ine(municipio, provincia=provincia)

    # Combinar metadatos de carátula y metadatos globales detectados por el Agente 1
    meta_ag1 = datos_ag1.get("metadatos_proyecto") if isinstance(datos_ag1.get("metadatos_proyecto"), dict) else {}
    meta_combinada = {
        "fase_tramitacion": (
            (metadatos_caratula or {}).get("fase_tramitacion")
            if isinstance(metadatos_caratula, dict)
            and (metadatos_caratula.get("fase_tramitacion") or "NO_ENCONTRADA") != "NO_ENCONTRADA"
            else meta_ag1.get("fase_tramitacion", "NO_ENCONTRADA")
        ),
        "fecha_aprobacion": (
            (metadatos_caratula or {}).get("fecha_aprobacion")
            if isinstance(metadatos_caratula, dict)
            and (metadatos_caratula.get("fecha_aprobacion") or "NO_ENCONTRADA") != "NO_ENCONTRADA"
            else meta_ag1.get("fecha_aprobacion", "NO_ENCONTRADA")
        ),
        "ambito": (
            (metadatos_caratula or {}).get("ambito")
            if isinstance(metadatos_caratula, dict)
            and (metadatos_caratula.get("ambito") or "NO_ENCONTRADO") not in ("NO_ENCONTRADO", "NO_ENCONTRADA", "")
            else meta_ag1.get("ambito", "NO_ENCONTRADO")
        ),
    }

    carpeta_proy = _limpiar_ruta(datos_ag1.get("carpeta_proyecto"))
    base_entrega = (
        _limpiar_ruta(directorio_entrega_base)
        or (os.path.join(carpeta_proy, "salida_empaquetada") if carpeta_proy else os.path.abspath("salida_empaquetada"))
    )
    os.makedirs(base_entrega, exist_ok=True)

    plantilla_raiz = reglas_id.get("plantilla_nombre") or f"INE_{tipo_proy}_FT_AAAAMMDD"
    codigo_raiz = construir_nombre_normativo(
        plantilla_raiz,
        tipo_proy,
        metadatos_caratula=meta_combinada,
        codigo_ine=ine_resuelto,
    )
    carpeta_raiz_entrega = os.path.join(base_entrega, codigo_raiz)

    # Limpieza idempotente de entrega previa del mismo instrumento antes de reconstruirla
    if os.path.exists(carpeta_raiz_entrega):
        _eliminar_directorio_seguro(carpeta_raiz_entrega)

    estructura_carpetas = reglas_id.get("estructura_carpetas") if isinstance(reglas_id.get("estructura_carpetas"), dict) else {}
    carpetas_creadas = _materializar_arbol_carpetas_normativo(
        estructura_carpetas,
        carpeta_raiz_entrega,
        tipo_proy,
        meta_combinada,
        ine_resuelto,
    )

    lista_archivos = datos_ag1.get("archivos") if isinstance(datos_ag1.get("archivos"), list) else []
    origen_principal_abs = (
        os.path.normcase(os.path.abspath(archivo_origen_principal))
        if archivo_origen_principal and os.path.exists(str(archivo_origen_principal))
        else ""
    )

    grupos_destino = {}
    orden_grupos = []
    advertencias = []
    archivos_omitidos = []

    # Agrupar los archivos clasificados por su destino normativo resuelto
    for item in lista_archivos:
        if not isinstance(item, dict):
            continue
        ruta_src = _limpiar_ruta(item.get("ruta_origen"))
        estado_lec = item.get("estado_lectura", "OK")
        if not ruta_src or not os.path.isfile(ruta_src) or estado_lec in ("VACIO", "INEXISTENTE", "ERROR_LECTURA"):
            motivo = f"Archivo omitido ({estado_lec}): {item.get('nombre_original', ruta_src)}"
            advertencias.append(motivo)
            archivos_omitidos.append({"archivo": ruta_src, "estado": estado_lec})
            continue

        cls_info = item.get("clasificacion") if isinstance(item.get("clasificacion"), dict) else {}
        en_raiz = bool(cls_info.get("en_raiz", True))
        segmentos_plantilla = cls_info.get("ruta_carpetas_plantilla") or []

        if en_raiz or not segmentos_plantilla:
            carpeta_dest = carpeta_raiz_entrega
        else:
            partes_resueltas = [
                construir_nombre_normativo(seg, tipo_proy, metadatos_caratula=meta_combinada, codigo_ine=ine_resuelto)
                for seg in segmentos_plantilla
                if _separar_plantilla_de_descripcion(seg)
            ]
            carpeta_dest = os.path.join(carpeta_raiz_entrega, *partes_resueltas) if partes_resueltas else carpeta_raiz_entrega

        os.makedirs(carpeta_dest, exist_ok=True)
        if carpeta_dest not in carpetas_creadas:
            carpetas_creadas.append(carpeta_dest)

        plantilla_arch = cls_info.get("plantilla_archivo") or os.path.splitext(item.get("nombre_original", "DOC"))[0]
        # Si no hay catálogo normativo y la plantilla raíz sí existe para el archivo único, usar plantilla raíz
        if cls_info.get("id_destino") == "SIN_CATALOGO" and not estructura_carpetas and len(lista_archivos) == 1:
            plantilla_arch = plantilla_raiz

        codigo_arch_base = construir_nombre_normativo(
            plantilla_arch,
            tipo_proy,
            metadatos_caratula=meta_combinada,
            nombre_original=ruta_src,
            codigo_ine=ine_resuelto,
        )
        es_seriado = bool(cls_info.get("es_seriado", False))
        es_pdf = str(item.get("extension", "")).lower() == ".pdf"

        clave_grupo = (os.path.normcase(carpeta_dest), codigo_arch_base.upper(), es_seriado, es_pdf)
        if clave_grupo not in grupos_destino:
            grupos_destino[clave_grupo] = {
                "carpeta_dest": carpeta_dest,
                "codigo_base": codigo_arch_base,
                "es_seriado": es_seriado,
                "es_pdf": es_pdf,
                "items": [],
            }
            orden_grupos.append(clave_grupo)
        grupos_destino[clave_grupo]["items"].append(item)

    archivos_generados = []
    detalle_empaquetado = []
    archivos_comprimidos_count = 0
    ahorro_total_bytes = 0
    hubo_division_global = False
    hubo_exceso_pagina_unica = False
    partes_archivo_principal = None

    # Directorio temporal de preparación (staging) que se elimina siempre al finalizar
    dir_staging = tempfile.mkdtemp(prefix=".tmp_stage_ag3_", dir=base_entrega)
    try:
        for clave_g in orden_grupos:
            grupo = grupos_destino[clave_g]
            carpeta_dest = grupo["carpeta_dest"]
            codigo_base = grupo["codigo_base"]
            es_seriado = grupo["es_seriado"]
            es_pdf = grupo["es_pdf"]
            items = grupo["items"]

            if es_pdf:
                if es_seriado:
                    # Documentos seriados independientes (ej. AN01, AN02...): cada documento incrementa el contador seriado
                    for idx_doc, item in enumerate(items, start=1):
                        ruta_src = _limpiar_ruta(item["ruta_origen"])
                        cod_serie = _aplicar_indice_seriado(codigo_base, idx_doc)
                        tmp_comp = os.path.join(dir_staging, f"s_{idx_doc}.pdf")
                        res_comp = comprimir_pdf_sin_perdida(ruta_src, ruta_destino=tmp_comp)
                        fue_comp = bool(res_comp.get("comprimido"))
                        if fue_comp:
                            archivos_comprimidos_count += 1
                            ahorro_total_bytes += int(res_comp.get("ahorro_bytes", 0))

                        fuente_efectiva = tmp_comp if res_comp.get("estado") in ("COMPRIMIDO", "SIN_CAMBIOS") else ruta_src
                        peso_post = os.path.getsize(fuente_efectiva)

                        if peso_post <= limite_bytes:
                            ruta_out = os.path.join(carpeta_dest, f"{cod_serie}.pdf")
                            shutil.copy2(fuente_efectiva, ruta_out)
                            salidas_item = [ruta_out]
                            dividido_item = False
                        else:
                            res_div = dividir_pdf_por_peso(
                                fuente_efectiva,
                                limite_mb=limite_mb,
                                formato_division=formato_div,
                                directorio_salida=carpeta_dest,
                                nombre_base_salida=cod_serie,
                                prefijo_parte="_",
                            )
                            if res_div.get("estado") == "ERROR":
                                advertencias.append(f"Error al dividir {item.get('nombre_original')}: {res_div.get('mensaje')}")
                                continue
                            salidas_item = res_div["archivos_generados"]
                            dividido_item = True
                            hubo_division_global = True
                            if res_div.get("estado") == "ADVERTENCIA_PAGINA_EXCEDE_LIMITE":
                                hubo_exceso_pagina_unica = True
                                advertencias.extend(res_div.get("advertencias") or [])

                        archivos_generados.extend(salidas_item)
                        if origen_principal_abs and os.path.normcase(os.path.abspath(ruta_src)) == origen_principal_abs:
                            partes_archivo_principal = len(salidas_item)
                        detalle_empaquetado.append({
                            "nombre_original": item.get("nombre_original"),
                            "ruta_origen": ruta_src,
                            "categoria_tecnica": (item.get("clasificacion") or {}).get("categoria_tecnica"),
                            "carpeta_destino": carpeta_dest,
                            "comprimido_sin_perdida": fue_comp,
                            "ahorro_bytes": int(res_comp.get("ahorro_bytes", 0)) if fue_comp else 0,
                            "dividido_por_peso": dividido_item,
                            "archivos_finales": salidas_item,
                        })
                else:
                    # Documento único o serie de planos/mapas bajo un mismo código documental (ej. CO -> _01_03, _02_03, _03_03)
                    unidades_preparadas = []
                    traza_por_item = []

                    for idx_item, item in enumerate(items, start=1):
                        ruta_src = _limpiar_ruta(item["ruta_origen"])
                        tmp_comp = os.path.join(dir_staging, f"g_{ abs(hash(clave_g)) % 100000 }_{idx_item}.pdf")
                        res_comp = comprimir_pdf_sin_perdida(ruta_src, ruta_destino=tmp_comp)
                        fue_comp = bool(res_comp.get("comprimido"))
                        ahorro_item = int(res_comp.get("ahorro_bytes", 0)) if fue_comp else 0
                        if fue_comp:
                            archivos_comprimidos_count += 1
                            ahorro_total_bytes += ahorro_item

                        fuente_efectiva = tmp_comp if res_comp.get("estado") in ("COMPRIMIDO", "SIN_CAMBIOS") else ruta_src
                        peso_post = os.path.getsize(fuente_efectiva)

                        if peso_post <= limite_bytes:
                            unidades_preparadas.append((idx_item - 1, fuente_efectiva))
                            traza_por_item.append({
                                "item": item,
                                "ruta_src": ruta_src,
                                "fue_comp": fue_comp,
                                "ahorro": ahorro_item,
                                "dividido": False,
                                "salidas": [],
                            })
                        else:
                            sub_stage = os.path.join(dir_staging, f"split_{idx_item}")
                            os.makedirs(sub_stage, exist_ok=True)
                            res_div = dividir_pdf_por_peso(
                                fuente_efectiva,
                                limite_mb=limite_mb,
                                formato_division=formato_div,
                                directorio_salida=sub_stage,
                                nombre_base_salida=f"parte_tmp_{idx_item}",
                                prefijo_parte="_",
                            )
                            if res_div.get("estado") == "ERROR":
                                advertencias.append(f"Error al dividir {item.get('nombre_original')}: {res_div.get('mensaje')}")
                                continue
                            hubo_division_global = True
                            if res_div.get("estado") == "ADVERTENCIA_PAGINA_EXCEDE_LIMITE":
                                hubo_exceso_pagina_unica = True
                                advertencias.extend(res_div.get("advertencias") or [])

                            for p_gen in res_div["archivos_generados"]:
                                unidades_preparadas.append((idx_item - 1, p_gen))
                            traza_por_item.append({
                                "item": item,
                                "ruta_src": ruta_src,
                                "fue_comp": fue_comp,
                                "ahorro": ahorro_item,
                                "dividido": True,
                                "salidas": [],
                            })

                    total_unidades = len(unidades_preparadas)
                    for num_orden, (pos_traza, ruta_payload) in enumerate(unidades_preparadas, start=1):
                        if total_unidades == 1:
                            nombre_def = f"{codigo_base}.pdf"
                        else:
                            suf = _formatear_sufijo_division(num_orden, total_unidades, formato_division=formato_div)
                            nombre_def = f"{codigo_base}_{suf}.pdf"
                        ruta_out = os.path.join(carpeta_dest, nombre_def)
                        shutil.copy2(ruta_payload, ruta_out)
                        archivos_generados.append(ruta_out)
                        traza_por_item[pos_traza]["salidas"].append(ruta_out)

                    for tr in traza_por_item:
                        if origen_principal_abs and os.path.normcase(os.path.abspath(tr["ruta_src"])) == origen_principal_abs:
                            partes_archivo_principal = len(tr["salidas"])
                        detalle_empaquetado.append({
                            "nombre_original": tr["item"].get("nombre_original"),
                            "ruta_origen": tr["ruta_src"],
                            "categoria_tecnica": (tr["item"].get("clasificacion") or {}).get("categoria_tecnica"),
                            "carpeta_destino": carpeta_dest,
                            "comprimido_sin_perdida": tr["fue_comp"],
                            "ahorro_bytes": tr["ahorro"],
                            "dividido_por_peso": tr["dividido"],
                            "archivos_finales": tr["salidas"],
                        })
            else:
                # Archivos no PDF: bases vectoriales SIG (.gpkg, conjunto .shp/.shx/.dbf/.prj), metadatos (.txt, .xml), CAD o imágenes
                tallos_shp = {}
                contador_capas = 0
                usados_en_carpeta = set()

                for item in items:
                    ruta_src = _limpiar_ruta(item["ruta_origen"])
                    ext_orig = str(item.get("extension") or os.path.splitext(ruta_src)[1]).lower()
                    dir_orig = os.path.normcase(os.path.dirname(os.path.abspath(ruta_src)))
                    stem_orig = os.path.splitext(os.path.basename(ruta_src))[0].lower()

                    # Mantener idéntico nombre base para todos los archivos acompañantes de un mismo Shapefile
                    if ext_orig in _EXTENSIONES_COMPANION_SHP:
                        clave_capa = (dir_orig, stem_orig)
                        if clave_capa not in tallos_shp:
                            contador_capas += 1
                            tallos_shp[clave_capa] = (
                                codigo_base if contador_capas == 1 else f"{codigo_base}_{contador_capas:02d}"
                            )
                        base_final = tallos_shp[clave_capa]
                    else:
                        base_final = codigo_base
                        idx_colision = 1
                        while f"{base_final}{ext_orig}".lower() in usados_en_carpeta:
                            idx_colision += 1
                            base_final = f"{codigo_base}_{idx_colision:02d}"

                    nombre_out = f"{base_final}{ext_orig}"
                    usados_en_carpeta.add(nombre_out.lower())
                    ruta_out = os.path.join(carpeta_dest, nombre_out)
                    shutil.copy2(ruta_src, ruta_out)

                    peso_bin = os.path.getsize(ruta_out)
                    if peso_bin > limite_bytes:
                        advertencias.append(
                            f"El archivo no-PDF '{nombre_out}' pesa {round(peso_bin / (1024 * 1024), 2)} MB y supera {limite_mb} MB."
                        )

                    archivos_generados.append(ruta_out)
                    detalle_empaquetado.append({
                        "nombre_original": item.get("nombre_original"),
                        "ruta_origen": ruta_src,
                        "categoria_tecnica": (item.get("clasificacion") or {}).get("categoria_tecnica"),
                        "carpeta_destino": carpeta_dest,
                        "comprimido_sin_perdida": False,
                        "ahorro_bytes": 0,
                        "dividido_por_peso": False,
                        "archivos_finales": [ruta_out],
                    })
    finally:
        _eliminar_directorio_seguro(dir_staging)

    if hubo_exceso_pagina_unica:
        estado_final = "ADVERTENCIA_PAGINA_EXCEDE_LIMITE"
    elif hubo_division_global:
        estado_final = "DIVIDIDO"
    else:
        estado_final = "OK"

    total_partes_reportadas = (
        partes_archivo_principal
        if partes_archivo_principal is not None
        else len(archivos_generados)
    )

    # Guardar el informe de trazabilidad FUERA de `<carpeta_raiz_entrega>` para no contaminar la carpeta oficial entregable
    ruta_informe = os.path.join(base_entrega, f"{codigo_raiz}_informe_empaquetado.json")
    informe_datos = {
        "estado": estado_final,
        "codigo_raiz": codigo_raiz,
        "carpeta_raiz_entrega": carpeta_raiz_entrega,
        "limite_peso_mb": limite_mb,
        "formato_division": formato_div,
        "carpetas_creadas": carpetas_creadas,
        "total_archivos_generados": len(archivos_generados),
        "archivos_comprimidos_sin_perdida": archivos_comprimidos_count,
        "ahorro_compresion_bytes": ahorro_total_bytes,
        "detalle_empaquetado": detalle_empaquetado,
        "archivos_omitidos": archivos_omitidos,
        "advertencias": advertencias,
    }
    try:
        _guardar_json_atomico(ruta_informe, informe_datos)
    except OSError:
        pass

    _imprimir(
        f"   📦 [Agente 3] Proyecto empaquetado en '{carpeta_raiz_entrega}' "
        f"({len(carpetas_creadas)} carpetas, {len(archivos_generados)} archivos generados)."
    )

    return {
        "estado": estado_final,
        "requiere_division": hubo_division_global,
        "limite_mb": limite_mb,
        "formato_division": formato_div,
        "codigo_raiz": codigo_raiz,
        "carpeta_raiz_entrega": carpeta_raiz_entrega,
        "carpetas_creadas": carpetas_creadas,
        "total_partes": total_partes_reportadas,
        "archivos_generados": archivos_generados,
        "archivos_comprimidos_sin_perdida": archivos_comprimidos_count,
        "ahorro_compresion_bytes": ahorro_total_bytes,
        "informe_empaquetado": ruta_informe,
        "detalle_empaquetado": detalle_empaquetado,
        "advertencias": advertencias,
    }


def ejecutar_agente_3(datos_consolidados, directorio_salida=None):
    """
    Punto de entrada de alto nivel del Agente 3:
    - Si `datos_consolidados` incluye `especificaciones_agente_1` (ruta JSON o diccionario con inventario clasificado),
      construye la carpeta final completa del proyecto según la estructura BOJA, comprimiendo sin pérdida,
      fragmentando por peso municipal y renombrando normativamente todos los archivos.
    - Si se invoca en modo individual clásico (únicamente con `archivo_origen`), procesa ese PDF directamente.
    """
    if not isinstance(datos_consolidados, dict):
        return {"estado": "ERROR", "mensaje": "Se esperaba un diccionario de datos consolidados."}

    normativas = datos_consolidados.get("normativas_empaquetado") or {}
    especificaciones_ag1 = datos_consolidados.get("especificaciones_agente_1")
    archivo_origen = _limpiar_ruta(datos_consolidados.get("archivo_origen"))

    if especificaciones_ag1 is not None:
        return empaquetar_proyecto_completo(
            especificaciones_agente_1=especificaciones_ag1,
            normativas_empaquetado=normativas,
            municipio=datos_consolidados.get("municipio"),
            provincia=datos_consolidados.get("provincia"),
            codigo_ine=datos_consolidados.get("codigo_ine"),
            tipo_proyecto=datos_consolidados.get("tipo_proyecto"),
            metadatos_caratula=datos_consolidados.get("metadatos_caratula"),
            directorio_entrega_base=directorio_salida,
            archivo_origen_principal=archivo_origen,
        )

    if not archivo_origen:
        return {"estado": "OMITIDO", "mensaje": "No se especificó archivo PDF principal ni inventario del Agente 1 para procesar."}

    reglas_emp = normativas.get("reglas_empaquetado") if isinstance(normativas, dict) else {}
    reglas_id = normativas.get("reglas_identidad") if isinstance(normativas, dict) else {}

    limite_mb = (reglas_emp or {}).get("limite_peso_mb", 50)
    formato_div = (reglas_emp or {}).get("formato_division", "09_99")
    plantilla = (reglas_id or {}).get("plantilla_nombre")

    nombre_base = None
    if directorio_salida and plantilla:
        nombre_base = construir_nombre_normativo(
            plantilla,
            datos_consolidados.get("tipo_proyecto"),
            datos_consolidados.get("metadatos_caratula"),
            nombre_original=archivo_origen,
            codigo_ine=datos_consolidados.get("codigo_ine"),
        )

    return procesar_pdf(
        archivo_origen,
        limite_mb=limite_mb,
        formato_division=formato_div,
        directorio_salida=directorio_salida,
        nombre_base_salida=nombre_base,
    )
